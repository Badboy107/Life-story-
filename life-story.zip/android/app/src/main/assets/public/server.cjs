var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
var app = (0, import_express.default)();
var PORT = 3e3;
var apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.warn("WARNING: GEMINI_API_KEY environment variable is not set. Recommendation features will fail gracefully.");
}
var aiClient = null;
function getGeminiClient() {
  if (!aiClient) {
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY model deployment variable is missing.");
    }
    aiClient = new import_genai.GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return aiClient;
}
app.use(import_express.default.json({ limit: "2mb" }));
app.post("/api/suggested-stories", async (req, res) => {
  try {
    const { likedAndSaved, availableStories } = req.body;
    if (!likedAndSaved || !availableStories || !Array.isArray(availableStories)) {
      return res.status(400).json({ error: "Missing required likedAndSaved or availableStories arrays." });
    }
    if (availableStories.length === 0) {
      return res.json({ recommendedIds: [] });
    }
    if (!likedAndSaved || likedAndSaved.length === 0) {
      return res.json({
        recommendedIds: availableStories.slice(0, 5).map((s) => s.id),
        explanation: "Like or save stories to unlock personalized suggestions custom-tailored to your style."
      });
    }
    const ai = getGeminiClient();
    const prompt = `You are an expert personalized content recommendation engine.
Analyze the user's previously liked/saved stories list to understand their interests, preferred themes, genres, and narrative categories:
${JSON.stringify(likedAndSaved)}

Based on these themes, select and prioritize up to 4 of the most relevant and appealing stories from the following available catalog of stories:
${JSON.stringify(availableStories)}

Rank your choices in descending order of recommendation strength (highest fit first). Also write a short, friendly explanation (max 12 words) explaining why these match them.`;
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: import_genai.Type.OBJECT,
          properties: {
            recommendedIds: {
              type: import_genai.Type.ARRAY,
              items: {
                type: import_genai.Type.STRING
              },
              description: "List of recommended story IDs matched based on interest compatibility."
            },
            explanation: {
              type: import_genai.Type.STRING,
              description: "A super brief, friendly personalized description of what matches, under 12 words."
            }
          },
          required: ["recommendedIds", "explanation"]
        }
      }
    });
    const textOutput = response.text;
    if (!textOutput) {
      console.warn("Empty response from Gemini.");
      return res.json({ recommendedIds: [], explanation: "" });
    }
    try {
      const parsed = JSON.parse(textOutput.trim());
      if (parsed && Array.isArray(parsed.recommendedIds)) {
        return res.json({
          recommendedIds: parsed.recommendedIds,
          explanation: parsed.explanation || "Recommended based on your reading history"
        });
      }
    } catch (e) {
      console.error("Failed to parse recommendation JSON output:", textOutput, e);
    }
    res.json({ recommendedIds: [], explanation: "" });
  } catch (err) {
    console.error("Gemini suggestion server error:", err);
    res.status(500).json({ error: err.message || "Failed to generate story recommendations." });
  }
});
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Life Story Server] Fullstack backend listening on http://localhost:${PORT}`);
  });
}
start().catch((err) => {
  console.error("Failed to bootstrap application:", err);
});
//# sourceMappingURL=server.cjs.map
