import React, { useState, useEffect, useRef } from 'react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  serverTimestamp, 
  doc, 
  deleteDoc,
  Timestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { Plus, X, Trash2, ChevronLeft, ChevronRight, Loader2, Sparkles, Image as ImageIcon, Check } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { cn, handleFirestoreError, uploadImage } from '../lib/utils';

export interface EphemeralStory {
  id: string;
  userId: string;
  userName: string;
  userPhotoURL: string | null;
  text?: string;
  mediaUrl?: string;
  backgroundColor?: string;
  createdAt: any;
}

interface GroupedStory {
  userId: string;
  userName: string;
  userPhotoURL: string | null;
  stories: EphemeralStory[];
}

const GRADIENTS = [
  'bg-gradient-to-tr from-purple-600 via-pink-600 to-red-500',
  'bg-gradient-to-tr from-blue-600 via-indigo-600 to-violet-600',
  'bg-gradient-to-tr from-amber-500 via-rose-500 to-red-600',
  'bg-gradient-to-tr from-emerald-500 via-teal-600 to-cyan-600',
  'bg-gradient-to-tr from-zinc-800 to-zinc-950',
  'bg-gradient-to-tr from-fuchsia-600 to-purple-800',
];

export default function StoriesSection({ myProfile }: { myProfile?: any }) {
  const { currentUser } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [rawStories, setRawStories] = useState<EphemeralStory[]>([]);
  const [groupedStories, setGroupedStories] = useState<GroupedStory[]>([]);
  
  // Create Story Modal
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [storyText, setStoryText] = useState('');
  const [selectedGradient, setSelectedGradient] = useState(GRADIENTS[0]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');

  // Active Story Viewer
  const [activeGroupIndex, setActiveGroupIndex] = useState<number | null>(null);
  const [activeStoryIndex, setActiveStoryIndex] = useState<number>(0);
  const [storyProgress, setStoryProgress] = useState(0);

  // Monitor loading
  const progressTimerRef = useRef<any>(null);

  // 1. Fetch real-time active stories from the last 24 hours
  useEffect(() => {
    if (!currentUser) return;

    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const q = query(
      collection(db, 'ephemeral_stories'),
      where('createdAt', '>=', twentyFourHoursAgo)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      })) as EphemeralStory[];

      // Sort by creation date ascending so that the user's stories run chronologically
      list.sort((a, b) => {
        const timeA = a.createdAt?.toMillis?.() || a.createdAt?.seconds * 1000 || Date.now();
        const timeB = b.createdAt?.toMillis?.() || b.createdAt?.seconds * 1000 || Date.now();
        return timeA - timeB;
      });

      setRawStories(list);
    }, (err) => {
      console.error("Failed fetching stories:", err);
      handleFirestoreError(err, 'list', 'ephemeral_stories', currentUser);
    });

    return () => unsubscribe();
  }, [currentUser]);

  // 2. Group stories by user (putting current user first if they have any)
  useEffect(() => {
    if (!currentUser) return;

    const groupsMap = new Map<string, GroupedStory>();

    rawStories.forEach((story) => {
      const existingGrp = groupsMap.get(story.userId);
      if (existingGrp) {
        existingGrp.stories.push(story);
      } else {
        groupsMap.set(story.userId, {
          userId: story.userId,
          userName: story.userName,
          userPhotoURL: story.userPhotoURL,
          stories: [story]
        });
      }
    });

    const list = Array.from(groupsMap.values());
    
    // Sort so currentUser's group is second to none (always first in custom scroll)
    list.sort((a, b) => {
      if (a.userId === currentUser.uid) return -1;
      if (b.userId === currentUser.uid) return 1;
      return 0;
    });

    setGroupedStories(list);
  }, [rawStories, currentUser]);

  // Handle file input changes
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setUploadError("Image must be smaller than 5MB");
        return;
      }
      setMediaFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setMediaPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setUploadError("");
    }
  };

  const handleCreateStory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!storyText.trim() && !mediaFile) {
      setUploadError("Write some text or submit an image first!");
      return;
    }

    setIsUploading(true);
    setUploadError("");

    try {
      let mediaUrl = "";

      // Upload if any file selected
      if (mediaFile) {
        mediaUrl = await uploadImage(mediaFile);
      }

      await addDoc(collection(db, 'ephemeral_stories'), {
        userId: currentUser.uid,
        userName: myProfile?.displayName || currentUser.displayName || 'Anonymous Storyteller',
        userPhotoURL: myProfile?.photoURL || currentUser.photoURL || null,
        text: storyText.trim(),
        mediaUrl: mediaUrl || null,
        backgroundColor: mediaUrl ? null : selectedGradient,
        createdAt: serverTimestamp()
      });

      // Cleanup & close
      setStoryText("");
      setMediaFile(null);
      setMediaPreview(null);
      setIsSubmitModalOpen(false);

    } catch (err: any) {
      console.error(err);
      setUploadError(err.message || "Failed uploading story. Verify connection.");
    } finally {
      setIsUploading(false);
    }
  };

  // 4. Timer/Playback engine for Active Story modal
  useEffect(() => {
    if (activeGroupIndex === null) {
      setStoryProgress(0);
      return;
    }

    const currentGroup = groupedStories[activeGroupIndex];
    if (!currentGroup) return;

    // Reset progress on activeStoryIndex changes
    setStoryProgress(0);

    const stepMs = 50; 
    const totalDurationMs = 5000;
    const progressStepValue = (stepMs / totalDurationMs) * 100;

    progressTimerRef.current = setInterval(() => {
      setStoryProgress(prev => {
        if (prev >= 100) {
          // Time to advance!
          handleNextStory();
          return 0;
        }
        return prev + progressStepValue;
      });
    }, stepMs);

    return () => {
      if (progressTimerRef.current) clearInterval(progressTimerRef.current);
    };
  }, [activeGroupIndex, activeStoryIndex]);

  const handleNextStory = () => {
    if (activeGroupIndex === null) return;
    const currentGroup = groupedStories[activeGroupIndex];
    
    if (activeStoryIndex < currentGroup.stories.length - 1) {
      // Go to next story in current group
      setActiveStoryIndex(prev => prev + 1);
    } else {
      // Go to next user group
      if (activeGroupIndex < groupedStories.length - 1) {
        setActiveGroupIndex(activeGroupIndex + 1);
        setActiveStoryIndex(0);
      } else {
        // Wrap up/close loop
        closeStoryViewer();
      }
    }
  };

  const handlePrevStory = () => {
    if (activeGroupIndex === null) return;
    
    if (activeStoryIndex > 0) {
      // Go to previous story in group
      setActiveStoryIndex(prev => prev - 1);
    } else {
      // Go to previous user group
      if (activeGroupIndex > 0) {
        const prevGroupIdx = activeGroupIndex - 1;
        const prevGroup = groupedStories[prevGroupIdx];
        setActiveGroupIndex(prevGroupIdx);
        // Play the last story of the previous user
        setActiveStoryIndex(prevGroup.stories.length - 1);
      } else {
        // Just replay from the beginning of first story
        setStoryProgress(0);
      }
    }
  };

  const closeStoryViewer = () => {
    if (progressTimerRef.current) clearInterval(progressTimerRef.current);
    setActiveGroupIndex(null);
    setActiveStoryIndex(0);
    setStoryProgress(0);
  };

  const handleDeleteStory = async (storyId: string) => {
    if (confirm("Permanently delete this story?")) {
      try {
        if (progressTimerRef.current) clearInterval(progressTimerRef.current);
        await deleteDoc(doc(db, 'ephemeral_stories', storyId));
        // If it was the only story, close viewer, else adjust pointers
        const grp = groupedStories[activeGroupIndex!];
        if (grp.stories.length <= 1) {
          closeStoryViewer();
        } else {
          setActiveStoryIndex(prev => Math.max(0, prev - 1));
        }
      } catch (err) {
        console.error("Failed to delete story:", err);
      }
    }
  };

  const getActiveGroup = () => {
    if (activeGroupIndex === null) return null;
    return groupedStories[activeGroupIndex];
  };

  const getActiveStory = () => {
    const gr= getActiveGroup();
    if (!gr) return null;
    return gr.stories[activeStoryIndex];
  };

  const hasMyStory = groupedStories.some(g => g.userId === currentUser?.uid);

  return (
    <div className="w-full mb-6">
      <div className="flex items-center space-x-2 px-1 mb-3">
        <span className="text-indigo-600 dark:text-indigo-400 text-sm">✦</span>
        <h3 className="font-extrabold text-[13px] uppercase tracking-widest text-zinc-500">
          Stories ({rawStories.length})
        </h3>
      </div>

      {/* The Scrollable Horizontal Circle List */}
      <div className="flex space-x-4 overflow-x-auto pb-4 pt-1 snap-x scrollbar-none select-none">
        
        {/* Your Story button card */}
        <div 
          onClick={() => setIsSubmitModalOpen(true)}
          className="flex-shrink-0 flex flex-col items-center justify-center space-y-1.5 focus:outline-none cursor-pointer group"
        >
          <div className="relative w-16 h-16 rounded-full border border-zinc-200 dark:border-zinc-800 flex items-center justify-center p-0.5 group-hover:border-indigo-500 transition-colors bg-white dark:bg-zinc-950 shadow-sm">
            {(myProfile?.photoURL || currentUser?.photoURL) ? (
              <img src={myProfile?.photoURL || currentUser?.photoURL} alt="Me" className="w-full h-full rounded-full object-cover grayscale-[30%] group-hover:scale-105 transition" />
            ) : (
              <div className="w-full h-full rounded-full bg-zinc-100 dark:bg-zinc-900 flex items-center justify-center text-zinc-500 font-extrabold">
                +
              </div>
            )}
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-indigo-600 border-[3px] border-white dark:border-black flex items-center justify-center text-white scale-100 group-active:scale-90 transition">
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            </div>
          </div>
          <span className="text-[11px] font-black tracking-tight text-gray-500 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
            Your Story
          </span>
        </div>

        {/* Existing Grouped Stories */}
        {groupedStories.map((grp, gId) => {
          const isMe = grp.userId === currentUser?.uid;
          const displayPhoto = grp.userPhotoURL;
          const displayLabel = isMe ? "Your active story" : grp.userName.split(' ')[0];

          return (
            <div 
              key={grp.userId}
              onClick={() => {
                setActiveGroupIndex(gId);
                setActiveStoryIndex(0);
              }}
              className="flex-shrink-0 flex flex-col items-center space-y-1.5 cursor-pointer select-none group"
            >
              <div className="relative p-0.5 rounded-full border-2 border-indigo-600 dark:border-indigo-400 group-hover:scale-102 group-active:scale-95 transition-all bg-white dark:bg-black shadow-sm flex items-center justify-center">
                {displayPhoto ? (
                  <img src={displayPhoto} alt="" className="w-14 h-14 rounded-full object-cover" />
                ) : (
                  <div className="w-14 h-14 rounded-full bg-indigo-100 dark:bg-zinc-900 flex items-center justify-center text-indigo-600 font-bold">
                    {grp.userName.charAt(0)}
                  </div>
                )}
                {/* Micro active circle decoration */}
                <div className="absolute ring-4 ring-white dark:ring-black bottom-0 right-0 w-3.5 h-3.5 bg-green-500 rounded-full" />
              </div>
              <span className="text-[11px] font-extrabold text-gray-700 dark:text-zinc-300 group-hover:text-indigo-600 truncate w-16 text-center leading-none">
                {displayLabel}
              </span>
            </div>
          )
        })}
      </div>

      {/* CREATE STORY SLIDE IN MODAL OVERLAY */}
      <AnimatePresence>
        {isSubmitModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-md flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="bg-white dark:bg-zinc-950 rounded-3xl overflow-hidden w-full max-w-md border border-gray-100 dark:border-zinc-900 shadow-2xl"
            >
              <div className="p-4 border-b border-gray-100 dark:border-zinc-900 flex items-center justify-between">
                <h3 className="font-extrabold text-[17px] tracking-tight text-gray-900 dark:text-white flex items-center space-x-2">
                  <Sparkles className="w-5 h-5 text-indigo-600 animate-pulse" />
                  <span>Create 24h Story</span>
                </h3>
                <button 
                  onClick={() => setIsSubmitModalOpen(false)}
                  className="p-1.5 hover:bg-gray-100 dark:hover:bg-zinc-900 rounded-full transition text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateStory} className="p-5 space-y-5">
                {uploadError && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/20 rounded-xl text-xs font-bold text-red-600 dark:text-red-400 border border-red-200/40">
                    {uploadError}
                  </div>
                )}

                {/* Media Selector */}
                {!mediaPreview ? (
                  <div className="space-y-3">
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-zinc-200 dark:border-zinc-900 rounded-2xl py-8 px-4 flex flex-col items-center justify-center cursor-pointer bg-gray-50/50 dark:bg-zinc-900/35 hover:bg-gray-100 transition shadow-inner"
                    >
                      <input 
                        type="file" 
                        ref={fileInputRef}
                        accept="image/*"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                      <ImageIcon className="w-8 h-8 text-zinc-400 mb-2" />
                      <span className="text-xs font-black text-zinc-700 dark:text-zinc-300">Choose Image Background</span>
                      <span className="text-[10px] text-zinc-400 mt-1 uppercase tracking-widest">or make text-only story below</span>
                    </div>

                    {/* Gradients selector for text-only option */}
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400 block mb-1">Pick Color Canvas</span>
                      <div className="flex space-x-2 overflow-x-auto py-1 scrollbar-none">
                        {GRADIENTS.map((grad, idx) => (
                          <div 
                            key={idx}
                            onClick={() => setSelectedGradient(grad)}
                            className={cn(
                              "w-8 h-8 rounded-full cursor-pointer flex-shrink-0 transition-all shadow-inner relative flex items-center justify-center border-2 border-transparent",
                              grad,
                              selectedGradient === grad ? 'scale-110 border-indigo-600' : 'hover:scale-105'
                            )}
                          >
                            {selectedGradient === grad && <Check className="w-4 h-4 text-white" />}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="relative rounded-2xl overflow-hidden aspect-video bg-zinc-800 border border-gray-100 dark:border-zinc-900 shadow shadow-inner">
                    <img src={mediaPreview} alt="Story Background Preview" className="w-full h-full object-cover" />
                    <button 
                      type="button" 
                      onClick={() => {
                        setMediaFile(null);
                        setMediaPreview(null);
                      }}
                      className="absolute top-2 right-2 p-1.5 bg-black/70 hover:bg-black/90 text-white rounded-full transition"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}

                {/* Overlaid overlay text */}
                <div className="space-y-1">
                  <label className="block text-xs font-black text-zinc-400 uppercase tracking-widest select-none">Overlay Story Text</label>
                  <textarea
                    rows={4}
                    value={storyText}
                    onChange={(e) => setStoryText(e.target.value)}
                    placeholder="Aa... type anything to overlay over story"
                    className="w-full px-4 py-3 border border-gray-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 text-gray-900 dark:text-white rounded-xl placeholder-zinc-400 focus:ring-2 focus:ring-indigo-500 outline-none transition text-sm leading-relaxed shadow-sm font-semibold"
                  />
                </div>

                <div className="flex space-x-3 pt-2">
                  <button 
                    type="submit"
                    disabled={isUploading}
                    className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-[13px] font-black rounded-xl cursor-pointer uppercase tracking-wider transition shadow-lg shadow-indigo-600/20 flex items-center justify-center space-x-2"
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Uploading...</span>
                      </>
                    ) : (
                      <span>Share to Story</span>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FULL-SCREEN IMMERSIVE STORY VIEWER */}
      <AnimatePresence>
        {activeGroupIndex !== null && getActiveGroup() && getActiveStory() && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[120] bg-black bg-opacity-95 flex flex-col items-center justify-center select-none"
          >
            {/* Story Viewer Panel (Aspect ratio centered container) */}
            <div className="relative w-full h-full max-w-lg md:h-[90vh] md:my-auto md:rounded-3xl overflow-hidden bg-zinc-950 shadow-2xl flex flex-col justify-between">
              
              {/* Header Overlay */}
              <div className="absolute top-0 inset-x-0 z-20 p-4 bg-gradient-to-b from-black/80 to-transparent flex flex-col space-y-3">
                
                {/* Horizontal Progress Bars */}
                <div className="flex space-x-1.5 w-full">
                  {getActiveGroup()!.stories.map((s, idx) => {
                    let fill = "0%";
                    if (idx < activeStoryIndex) fill = "100%";
                    else if (idx === activeStoryIndex) fill = `${storyProgress}%`;

                    return (
                      <div key={idx} className="h-1 bg-white/20 rounded-full flex-1 overflow-hidden">
                        <div 
                          className="h-full bg-white transition-all duration-[50ms]" 
                          style={{ width: fill }}
                        />
                      </div>
                    );
                  })}
                </div>

                {/* User Card Metadata */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-white bg-indigo-600 flex items-center justify-center">
                      {getActiveGroup()?.userPhotoURL ? (
                        <img src={getActiveGroup()?.userPhotoURL || ''} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-white font-bold">{getActiveGroup()?.userName.charAt(0)}</span>
                      )}
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm text-white">{getActiveGroup()?.userName}</h4>
                      <p className="text-[10px] font-bold text-gray-300">
                        {getActiveStory()?.createdAt ? formatDistanceToNow(
                          getActiveStory()?.createdAt instanceof Timestamp 
                          ? getActiveStory()?.createdAt.toDate() 
                          : getActiveStory()?.createdAt?.toDate?.() || new Date(), 
                          { addSuffix: true }
                        ) : 'Just now'}
                      </p>
                    </div>
                  </div>

                  {/* Top action buttons (Delete & Close) */}
                  <div className="flex items-center space-x-1.5">
                    {getActiveGroup()?.userId === currentUser?.uid && (
                      <button 
                        onClick={() => handleDeleteStory(getActiveStory()!.id)}
                        className="p-2 hover:bg-white/10 rounded-full transition text-red-400 hover:text-red-500"
                        title="Delete Story"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    )}
                    <button 
                      onClick={closeStoryViewer}
                      className="p-2 hover:bg-white/10 rounded-full transition text-white"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Taps Navigation layer */}
              <div className="absolute inset-0 z-10 flex">
                <div onClick={handlePrevStory} className="w-[30%] h-full cursor-pointer" />
                <div className="flex-1 h-full" />
                <div onClick={handleNextStory} className="w-[30%] h-full cursor-pointer" />
              </div>

              {/* Central Content */}
              <div className={cn(
                "w-full h-full flex flex-col items-center justify-center relative",
                !getActiveStory()?.mediaUrl ? getActiveStory()?.backgroundColor || GRADIENTS[0] : "bg-black"
              )}>
                {getActiveStory()?.mediaUrl && (
                  <img src={getActiveStory()?.mediaUrl} alt="" className="absolute inset-0 w-full h-full object-contain z-0" />
                )}

                {/* Text Content Overlay */}
                {getActiveStory()?.text && (
                  <div className="relative z-10 px-6 py-4 text-center max-w-sm">
                    <p className={cn(
                      "font-black tracking-tight drop-shadow-md break-words",
                      getActiveStory()?.mediaUrl 
                        ? "text-xl text-white bg-black/60 rounded-2xl px-5 py-4 border border-white/10 shadow blur-backdrop" 
                        : "text-2xl text-white leading-relaxed"
                    )}>
                      {getActiveStory()?.text}
                    </p>
                  </div>
                )}
              </div>

              {/* Horizontal Group Switching Controls (Bottom Overlay) */}
              <div className="absolute bottom-6 inset-x-0 z-20 flex items-center justify-between px-6 bg-gradient-to-t from-black/60 to-transparent pt-6">
                <button 
                  onClick={handlePrevStory}
                  disabled={activeGroupIndex === 0 && activeStoryIndex === 0}
                  className="p-2.5 bg-black/40 hover:bg-black/60 text-white rounded-full transition disabled:opacity-30 cursor-pointer"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <span className="text-[11px] font-black tracking-widest uppercase text-white/50">
                  {activeStoryIndex + 1} of {getActiveGroup()?.stories.length}
                </span>
                <button 
                  onClick={handleNextStory}
                  className="p-2.5 bg-black/40 hover:bg-black/60 text-white rounded-full transition cursor-pointer"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
