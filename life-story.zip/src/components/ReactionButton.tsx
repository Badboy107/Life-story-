import React, { useState, useEffect, useRef } from 'react';
import { doc, setDoc, deleteDoc, updateDoc, increment, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { createNotification } from '../lib/notifications';
import { handleFirestoreError } from '../lib/utils';
import { Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ReactionButtonProps {
  storyId: string;
  storyTitle: string;
  authorId: string;
  initialReaction: string | null;
  initialLikesCount: number;
  onReactionUpdate?: (newReaction: string | null, newLikesCount: number) => void;
  isFeedMode?: boolean;
}

export const REACTION_TYPES = [
  { type: 'heart', label: 'Love', emoji: '❤️', color: 'text-red-500 hover:scale-125' },
  { type: 'like', label: 'Like', emoji: '👍', color: 'text-blue-500 hover:scale-125' },
  { type: 'insight', label: 'Insight', emoji: '💡', color: 'text-yellow-400 hover:scale-125' },
  { type: 'haha', label: 'Haha', emoji: '😂', color: 'text-yellow-500 hover:scale-125' },
  { type: 'wow', label: 'Wow', emoji: '😮', color: 'text-yellow-500 hover:scale-125' },
  { type: 'sad', label: 'Sad', emoji: '😢', color: 'text-blue-400 hover:scale-125' },
  { type: 'fire', label: 'Fire', emoji: '🔥', color: 'text-orange-500 hover:scale-125' }
];

export default function ReactionButton({
  storyId,
  storyTitle,
  authorId,
  initialReaction,
  initialLikesCount,
  onReactionUpdate,
  isFeedMode = false
}: ReactionButtonProps) {
  const { currentUser } = useAuth();
  const [currentReaction, setCurrentReaction] = useState<string | null>(initialReaction);
  const [likesCount, setLikesCount] = useState<number>(initialLikesCount);
  const [showPanel, setShowPanel] = useState(false);
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const longPressTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  // Sync state with props when changed by parent refresh
  useEffect(() => {
    setCurrentReaction(initialReaction);
  }, [initialReaction]);

  useEffect(() => {
    setLikesCount(initialLikesCount);
  }, [initialLikesCount]);

  // Handle clicking outside to close panel
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        setShowPanel(false);
      }
    };
    if (showPanel) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showPanel]);

  const handleReactionSelect = async (reactionType: string | null, e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (!currentUser) return;

    setShowPanel(false);

    const prevReaction = currentReaction;
    const prevLikesCount = likesCount;

    // Determine counts and types
    let newLikesCount = prevLikesCount;
    if (reactionType !== null && prevReaction === null) {
      newLikesCount = prevLikesCount + 1;
    } else if (reactionType === null && prevReaction !== null) {
      newLikesCount = Math.max(0, prevLikesCount - 1);
    }

    // Optimistically update local state
    setCurrentReaction(reactionType);
    setLikesCount(newLikesCount);

    if (onReactionUpdate) {
      onReactionUpdate(reactionType, newLikesCount);
    }

    try {
      const storyRef = doc(db, 'stories', storyId);
      const likeRef = doc(db, 'stories', storyId, 'likes', currentUser.uid);

      if (reactionType === null) {
        // Delete reaction
        await deleteDoc(likeRef);
        await updateDoc(storyRef, { likesCount: increment(-1) });
      } else {
        // Set/Update reaction document
        await setDoc(likeRef, {
          userId: currentUser.uid,
          type: reactionType,
          createdAt: serverTimestamp()
        });

        // Update likesCount on story
        if (prevReaction === null) {
          await updateDoc(storyRef, { likesCount: increment(1) });

          // Send notification only when first reacting (not updating)
          if (authorId !== currentUser.uid) {
            const rxObj = REACTION_TYPES.find(r => r.type === reactionType);
            const actionText = rxObj ? `reacted with ${rxObj.emoji}` : 'liked';
            await createNotification(
              authorId,
              currentUser.uid,
              'like',
              `${currentUser.displayName} ${actionText} your story: "${storyTitle}"`,
              `/story/${storyId}`
            );
          }
        }
      }
    } catch (error) {
      // Revert on error
      setCurrentReaction(prevReaction);
      setLikesCount(prevLikesCount);
      if (onReactionUpdate) {
        onReactionUpdate(prevReaction, prevLikesCount);
      }
      handleFirestoreError(error, 'like', `stories/${storyId}/likes`, currentUser);
    }
  };

  const toggleDefault = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (currentReaction !== null) {
      // If already has reaction, clicking of button clears it
      handleReactionSelect(null);
    } else {
      // Clicking empty button defaults to Love ❤️ reaction
      handleReactionSelect('heart');
    }
  };

  // Hover panel controls for Desktop
  const handleMouseEnter = () => {
    if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    hoverTimeoutRef.current = setTimeout(() => {
      setShowPanel(true);
    }, 200); // Small delay to avoid accidental triggering
  };

  const handleMouseLeave = () => {
    if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    hoverTimeoutRef.current = setTimeout(() => {
      setShowPanel(false);
    }, 450); // Provide window to hover onto popover
  };

  // Touch triggers for Mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    if (longPressTimeoutRef.current) clearTimeout(longPressTimeoutRef.current);
    longPressTimeoutRef.current = setTimeout(() => {
      setShowPanel(true);
      if (navigator.vibrate) {
        navigator.vibrate(50); // Haptic feedback on mobile if supported
      }
    }, 450); // 450ms long press duration
  };

  const handleTouchEnd = () => {
    if (longPressTimeoutRef.current) clearTimeout(longPressTimeoutRef.current);
  };

  // Find info about current chosen reaction
  const activeReactionInfo = REACTION_TYPES.find(r => r.type === currentReaction);

  return (
    <div 
      className="relative flex-1"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <AnimatePresence>
        {showPanel && (
          <motion.div 
            ref={panelRef}
            initial={{ opacity: 0, y: 15, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 15, scale: 0.9 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="absolute -top-16 left-1/2 -translate-x-1/2 z-40 flex items-center gap-3.5 bg-white/95 dark:bg-zinc-950/95 backdrop-blur-md px-3.5 py-2.5 rounded-full shadow-xl border border-gray-100 dark:border-zinc-800"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
          >
            {REACTION_TYPES.map((rx) => (
              <motion.button
                key={rx.type}
                type="button"
                whileHover={{ scale: 1.35 }}
                whileTap={{ scale: 0.9 }}
                className="text-[25px] flex items-center justify-center p-0.5 focus:outline-none transition-transform"
                onClick={(e) => handleReactionSelect(rx.type, e)}
                title={rx.label}
              >
                {rx.emoji}
              </motion.button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        type="button"
        onClick={toggleDefault}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.92 }}
        transition={{ type: 'spring', stiffness: 450, damping: 15 }}
        className="w-full h-10 flex items-center justify-center space-x-2 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-zinc-900 transition-colors cursor-pointer select-none"
        id={`react-btn-${storyId}`}
      >
        {activeReactionInfo ? (
          <motion.div 
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="flex items-center space-x-1.5"
          >
            <span className="text-[19px]">{activeReactionInfo.emoji}</span>
            <span className="text-[15px] font-bold text-indigo-600 dark:text-indigo-400 capitalize">
              {activeReactionInfo.label} {likesCount > 0 && <span className="ml-1 opacity-80">({likesCount})</span>}
            </span>
          </motion.div>
        ) : (
          <div className="flex items-center space-x-1.5">
            <Heart className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            <span className="text-[15px] font-semibold text-gray-600 dark:text-gray-400">
              Like {likesCount > 0 && <span className="ml-1">({likesCount})</span>}
            </span>
          </div>
        )}
      </motion.button>
    </div>
  );
}
