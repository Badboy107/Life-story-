import React from 'react';
import { MessageCircle } from 'lucide-react';

export default function AdminSupport() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white dark:bg-zinc-950 rounded-[2.5rem] p-8 border border-gray-100 dark:border-zinc-800 shadow-sm space-y-8">
        <div>
          <h2 className="text-xl font-black text-gray-900 dark:text-white tracking-tight mb-2">Support & Assistance</h2>
          <p className="text-sm font-medium text-gray-500 leading-relaxed max-w-2xl">
            If you face any issues with your account, need help with the platform, or have questions about the monetization program, feel free to contact the administrator.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          <a 
            href="mailto:starbad366@gmail.com"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white font-bold rounded-xl text-sm transition hover:bg-indigo-700 hover:shadow-lg hover:shadow-indigo-500/20 active:scale-95 shadow-md"
          >
            <MessageCircle className="w-5 h-5" />
            Contact Admin
          </a>
          <div className="px-6 py-3 bg-gray-50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-sm font-bold text-gray-600 dark:text-zinc-300 flex items-center justify-center">
            starbad366@gmail.com
          </div>
        </div>
      </div>
    </div>
  );
}
