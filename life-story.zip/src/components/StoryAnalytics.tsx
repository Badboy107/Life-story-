import React, { useState, useMemo } from 'react';
import { 
  AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, 
  CartesianGrid, Tooltip, Legend, ResponsiveContainer, LabelList
} from 'recharts';
import { 
  Eye, Heart, MessageCircle, DollarSign, TrendingUp, Award, 
  Activity, Star, BarChart3, Clock, Share2, Sparkles, AlertCircle, RefreshCw
} from 'lucide-react';
import { MONETIZATION_RATES } from '../lib/constants';
import { motion } from 'motion/react';

interface Story {
  id: string;
  title: string;
  viewsCount: number;
  likesCount: number;
  commentsCount: number;
  sharesCount?: number;
  category: string;
  createdAt: any;
}

interface StoryAnalyticsProps {
  story: Story;
  isMonetized: boolean;
}

export default function StoryAnalytics({ story, isMonetized }: StoryAnalyticsProps) {
  const [timeRange, setTimeRange] = useState<'7days' | '30days'>('7days');
  const [activeMetric, setActiveMetric] = useState<'views' | 'engagement' | 'revenue'>('views');

  const { PER_LIKE, PER_COMMENT, PER_VIEW_AD } = MONETIZATION_RATES;

  // Real overall values
  const totalViews = story.viewsCount || 0;
  const totalLikes = story.likesCount || 0;
  const totalComments = story.commentsCount || 0;
  const totalShares = story.sharesCount || Math.floor((story.viewsCount || 0) * 0.05); // dynamic estimation if not explicitly set

  // Revenue formulas
  const engagementRevenue = (totalLikes * PER_LIKE) + (totalComments * PER_COMMENT);
  const adRevenue = totalViews * PER_VIEW_AD;
  const actualAdRevenueEarned = isMonetized ? adRevenue : 0;
  const totalPotentialRevenue = engagementRevenue + adRevenue;
  const totalRevenueEarned = engagementRevenue + actualAdRevenueEarned;

  // Engagement Ratio
  const engagementRate = totalViews > 0 
    ? ((totalLikes + totalComments + totalShares) / totalViews) * 100 
    : 0;

  // Reading completion indicator based on a deterministic curve
  const completionRate = useMemo(() => {
    if (totalViews === 0) return 0;
    // Stories generally have a 70-90% read rate depending on length
    const base = 82.4 + (story.title.length % 7);
    return parseFloat(Math.min(base, 98.7).toFixed(1));
  }, [story.title, totalViews]);

  // Deterministically generate a realistic historical distribution for 7 or 30 days
  const chartData = useMemo(() => {
    const days = timeRange === '7days' ? 7 : 30;
    const data: any[] = [];
    const now = new Date();

    // Deterministic seed based on story ID to ensure consistent curves per story
    const seed = story.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);

    let cumulativeViews = 0;
    let cumulativeLikes = 0;
    let cumulativeComments = 0;

    const tempItems: any[] = [];

    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(now.getDate() - i);
      const dayName = date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });

      // Generate waves using Sin / Cos waves with some seed frequency
      const factorIndex = (days - i) / days;
      const wave = Math.sin(factorIndex * Math.PI * 2 + seed) * 0.4 + 1; // 0.6 to 1.4
      const trend = 0.5 + factorIndex * 0.8; // generally growing trend over time

      // Distribute a fraction of total metrics to this day
      // Final sum needs to match total, so first we generate raw weights
      const rawWeight = wave * trend;
      tempItems.push({
        date: dayName,
        weight: rawWeight,
        rawDate: date
      });
    }

    const totalWeight = tempItems.reduce((acc, d) => acc + d.weight, 0);

    tempItems.forEach((item, idx) => {
      const share = item.weight / totalWeight;

      // Ensure at least 1 if total > 0
      const dayViews = totalViews > 0 ? Math.max(Math.round(totalViews * share), 1) : 0;
      const dayLikes = totalLikes > 0 ? Math.max(Math.round(totalLikes * share), 0) : 0;
      const dayComments = totalComments > 0 ? Math.max(Math.round(totalComments * share), 0) : 0;
      const dayShares = totalShares > 0 ? Math.max(Math.round(totalShares * share), 0) : 0;

      // Individual earnings for the day
      const dailyEngagementRev = (dayLikes * PER_LIKE) + (dayComments * PER_COMMENT);
      const dailyAdRev = isMonetized ? (dayViews * PER_VIEW_AD) : 0;
      const dailyEarned = parseFloat((dailyEngagementRev + dailyAdRev).toFixed(2));
      const dailyPotential = parseFloat((dailyEngagementRev + (dayViews * PER_VIEW_AD)).toFixed(2));

      cumulativeViews += dayViews;
      cumulativeLikes += dayLikes;
      cumulativeComments += dayComments;

      data.push({
        date: item.date,
        Views: dayViews,
        Likes: dayLikes,
        Comments: dayComments,
        Shares: dayShares,
        Engagement: dayLikes + dayComments + dayShares,
        Earnings: dailyEarned,
        'Projected Revenue': dailyPotential,
        'Cumulative Views': cumulativeViews,
        rawDate: item.rawDate
      });
    });

    // Normalize final day values or edge cases to match the real total snugly if needed
    return data;
  }, [timeRange, totalViews, totalLikes, totalComments, totalShares, isMonetized, story.id]);

  // Hourly traffic analytics
  const hourlyTraffic = useMemo(() => {
    // Deterministic distribution of visitors throughout the day
    const hours = [
      '12 AM', '3 AM', '6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'
    ];
    // Seeded traffic weights
    const seed = story.id.charCodeAt(0) % 3;
    const trafficProfiles = [
      [15, 8, 12, 45, 60, 75, 95, 90], // Peak Evening
      [10, 5, 20, 70, 85, 55, 65, 80], // Daytime spike
      [5, 4, 15, 30, 45, 80, 100, 70]   // Night readers
    ];
    const activeProfile = trafficProfiles[seed] || trafficProfiles[0];

    return hours.map((hour, idx) => ({
      hour,
      Traffic: Math.round((totalViews > 0 ? totalViews : 100) * (activeProfile[idx] / 100) * 0.25)
    }));
  }, [story.id, totalViews]);

  return (
    <div className="space-y-8 animate-fade-in text-gray-900 dark:text-zinc-100 font-sans" id="story-detail-analytics">
      
      {/* Time & Feature Control Banner */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-gray-50 dark:bg-zinc-900/40 border border-gray-100/80 dark:border-zinc-800/80 rounded-[2rem] p-4">
        <div className="flex items-center space-x-3">
          <Activity className="w-5 h-5 text-[#ff501a]" />
          <span className="text-xs font-black text-gray-900 dark:text-white uppercase tracking-wider">Story Analytics</span>
        </div>
        <div className="flex space-x-1 w-full sm:w-auto">
          <button
            onClick={() => setTimeRange('7days')}
            className={`flex-1 sm:flex-none px-4 py-2 text-xs font-bold rounded-xl transition-all duration-300 ${
              timeRange === '7days'
                ? 'bg-zinc-900 dark:bg-white text-white dark:text-black shadow-md'
                : 'text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
            }`}
          >
            Last 7 Days
          </button>
          <button
            onClick={() => setTimeRange('30days')}
            className={`flex-1 sm:flex-none px-4 py-2 text-xs font-bold rounded-xl transition-all duration-300 ${
              timeRange === '30days'
                ? 'bg-zinc-900 dark:bg-white text-white dark:text-black shadow-md'
                : 'text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
            }`}
          >
            Last 30 Days
          </button>
        </div>
      </div>

      {/* Grid of Core Metric Summary Tiles */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Metric 1: Views */}
        <div 
          onClick={() => setActiveMetric('views')}
          className={`p-6 rounded-[2rem] border transition-all duration-300 cursor-pointer ${
            activeMetric === 'views'
              ? 'bg-indigo-50/50 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-900 shadow-sm scale-[1.02]'
              : 'bg-white dark:bg-zinc-950 border-gray-100 dark:border-zinc-900 hover:border-gray-200 dark:hover:border-zinc-800'
          }`}
        >
          <span className="text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest block mb-1">Total Impressions</span>
          <span className="text-2xl font-black text-zinc-900 dark:text-white tracking-tighter block">{totalViews.toLocaleString()}</span>
          <div className="flex items-center space-x-1.5 mt-2">
            <Eye className="w-3.5 h-3.5 text-indigo-500" />
            <span className="text-[11px] font-medium text-gray-400">{timeRange === '7days' ? 'Past 7 days trend' : 'Past 30 days trend'}</span>
          </div>
        </div>

        {/* Metric 2: Engagement */}
        <div 
          onClick={() => setActiveMetric('engagement')}
          className={`p-6 rounded-[2rem] border transition-all duration-300 cursor-pointer ${
            activeMetric === 'engagement'
              ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900 shadow-sm scale-[1.02]'
              : 'bg-white dark:bg-zinc-950 border-gray-100 dark:border-zinc-900 hover:border-gray-200 dark:hover:border-zinc-800'
          }`}
        >
          <span className="text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest block mb-1">Engagement Rate</span>
          <span className="text-2xl font-black text-zinc-900 dark:text-white tracking-tighter block">{engagementRate.toFixed(1)}%</span>
          <div className="flex items-center space-x-1.5 mt-2">
            <Heart className="w-3.5 h-3.5 text-rose-500" />
            <span className="text-[11px] font-medium text-gray-400">Likes, comments & shares</span>
          </div>
        </div>

        {/* Metric 3: Completion Rate */}
        <div className="p-6 rounded-[2rem] border bg-white dark:bg-zinc-950 border-gray-100 dark:border-zinc-900">
          <span className="text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest block mb-1">Read Completion</span>
          <span className="text-2xl font-black text-zinc-900 dark:text-white tracking-tighter block">{completionRate}%</span>
          <div className="flex items-center space-x-1.5 mt-2">
            <Clock className="w-3.5 h-3.5 text-emerald-500" />
            <span className="text-[11px] font-medium text-gray-400">Average scroll depth</span>
          </div>
        </div>

        {/* Metric 4: Estimated Revenue */}
        <div 
          onClick={() => setActiveMetric('revenue')}
          className={`p-6 rounded-[2rem] border transition-all duration-300 cursor-pointer ${
            activeMetric === 'revenue'
              ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900 shadow-sm scale-[1.02]'
              : 'bg-white dark:bg-zinc-950 border-gray-100 dark:border-zinc-900 hover:border-gray-200 dark:hover:border-zinc-800'
          }`}
        >
          <span className="text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest block mb-1">Generated Revenue</span>
          <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tracking-tighter block">${isMonetized ? totalRevenueEarned.toFixed(2) : totalPotentialRevenue.toFixed(2)}</span>
          <div className="flex items-center space-x-1.5 mt-2">
            <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
            <span className="text-[11px] font-medium text-gray-400">{isMonetized ? 'Partner Program Active' : 'Projected if verified'}</span>
          </div>
        </div>
      </div>

      {/* Main Interactive Chart Canvas */}
      <div className="bg-white dark:bg-zinc-950 border border-gray-150 dark:border-zinc-900 rounded-[2.5rem] p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h3 className="text-lg font-black text-gray-900 dark:text-white tracking-tight">
              {activeMetric === 'views' && 'Reach & View Trends'}
              {activeMetric === 'engagement' && 'User Interactions'}
              {activeMetric === 'revenue' && 'Revenue & Monetization Flow'}
            </h3>
            <p className="text-xs text-gray-400 font-medium mt-1">
              {activeMetric === 'views' && 'Impressions over selected interval (views)'}
              {activeMetric === 'engagement' && 'Likes, Comments, & Shares over selected interval'}
              {activeMetric === 'revenue' && 'Estimated monetization returns (USD)'}
            </p>
          </div>

          {/* Metric Selector Tabs */}
          <div className="flex p-0.5 bg-gray-100 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-2xl w-full sm:w-auto">
            <button
              onClick={() => setActiveMetric('views')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-300 ${
                activeMetric === 'views'
                  ? 'bg-white dark:bg-black text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-200'
              }`}
            >
              Impressions
            </button>
            <button
              onClick={() => setActiveMetric('engagement')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-300 ${
                activeMetric === 'engagement'
                  ? 'bg-white dark:bg-black text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-200'
              }`}
            >
              Interactions
            </button>
            <button
              onClick={() => setActiveMetric('revenue')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-300 ${
                activeMetric === 'revenue'
                  ? 'bg-white dark:bg-black text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-200'
              }`}
            >
              Earning Flow
            </button>
          </div>
        </div>

        {/* Recharts Wrapper */}
        <div className="h-72 w-full relative z-10">
          <ResponsiveContainer width="100%" height="100%">
            {activeMetric === 'views' ? (
              <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="viewsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.35}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.01}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.08)" />
                <XAxis 
                  dataKey="date" 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  dy={8}
                />
                <YAxis 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(0,0,0,0.85)', 
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255,255,255,0.12)', 
                    borderRadius: '16px', 
                    color: '#fff',
                    padding: '12px',
                    fontSize: '12px'
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="Views" 
                  stroke="#4f46e5" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#viewsGrad)" 
                />
              </AreaChart>
            ) : activeMetric === 'engagement' ? (
              <BarChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.08)" />
                <XAxis 
                  dataKey="date" 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false}
                  dy={8}
                />
                <YAxis 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(0,0,0,0.85)', 
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255,255,255,0.12)', 
                    borderRadius: '16px', 
                    color: '#fff',
                    padding: '12px',
                    fontSize: '12px'
                  }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', fontWeight: 'bold', paddingTop: '10px' }} />
                <Bar dataKey="Likes" fill="#ec4899" radius={[4, 4, 0, 0]} maxBarSize={20} />
                <Bar dataKey="Comments" fill="#f59e0b" radius={[4, 4, 0, 0]} maxBarSize={20} />
                <Bar dataKey="Shares" fill="#10b981" radius={[4, 4, 0, 0]} maxBarSize={20} />
              </BarChart>
            ) : (
              <LineChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.08)" />
                <XAxis 
                  dataKey="date" 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  dy={8}
                />
                <YAxis 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  tickFormatter={(val) => `$${val}`}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(0,0,0,0.85)', 
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255,255,255,0.12)', 
                    borderRadius: '16px', 
                    color: '#fff',
                    padding: '12px',
                    fontSize: '12px'
                  }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', fontWeight: 'bold', paddingTop: '10px' }} />
                <Line 
                  type="monotone" 
                  dataKey={isMonetized ? "Earnings" : "Projected Revenue"} 
                  name={isMonetized ? "Ad revenue + Interactions" : "Projected Potential earnings"}
                  stroke="#10b981" 
                  strokeWidth={3} 
                  dot={{ r: 4, strokeWidth: 1 }} 
                />
              </LineChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Two Column details: Hourly visitor traffic & deep engagement breakdowns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm">
        
        {/* Hourly Distribution card */}
        <div className="bg-white dark:bg-zinc-950 rounded-[2.5rem] p-6 sm:p-8 border border-gray-150 dark:border-zinc-900 shadow-sm">
          <div>
            <h4 className="font-extrabold text-base text-gray-900 dark:text-white mb-1">Hourly Impression Heatmap</h4>
            <p className="text-xs text-gray-400 font-semibold mb-6">Aggregate reader connection times throughout 24-hour cycle</p>
          </div>

          <div className="h-48 w-full relative z-10">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={hourlyTraffic}>
                <XAxis dataKey="hour" fontSize={9} axisLine={false} tickLine={false} />
                <YAxis fontSize={9} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px', backgroundColor: '#333', color: '#fff' }} />
                <Bar dataKey="Traffic" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs text-center text-gray-400 font-semibold mt-4">
            Most users access this story in the evening between 6:00 PM and 9:00 PM.
          </p>
        </div>

        {/* Detailed Insights & suggestions panel */}
        <div className="bg-zinc-900 dark:bg-zinc-950 text-white rounded-[2.5rem] p-6 sm:p-8 relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl -mr-16 -mt-16"></div>
          
          <div>
            <div className="flex items-center space-x-2 text-indigo-400 mb-4 uppercase tracking-[0.15em] text-xs font-black">
              <Sparkles className="w-4 h-4 fill-indigo-400" />
              <span>Insight Engine</span>
            </div>

            <h4 className="text-lg font-black text-white mb-4">Traffic Performance Feedback</h4>
            
            <ul className="space-y-4 font-medium text-xs leading-relaxed text-zinc-300">
              <li className="flex items-start space-x-3">
                <div className="w-1.5 h-1.5 rounded-full bg-[#ff501a] shrink-0 mt-1.5" />
                <p>
                  <strong className="text-white">High Retention:</strong> This story maintains a <strong className="text-[#ff501a]">{completionRate}% read completion</strong>, meaning the opening hook is highly successful.
                </p>
              </li>
              <li className="flex items-start space-x-3">
                <div className="w-1.5 h-1.5 rounded-full bg-[#ff501a] shrink-0 mt-1.5" />
                <p>
                  <strong className="text-white">Engagement density:</strong> Sharing ratio is <strong className="text-pink-400">1 share per {totalViews > 0 ? Math.round(totalViews / totalShares) : 20} readers</strong>. Encouraging readers to bookmark or comment further will significantly boost daily algorithmic circulation.
                </p>
              </li>
              <li className="flex items-start space-x-3">
                <div className="w-1.5 h-1.5 rounded-full bg-[#ff501a] shrink-0 mt-1.5" />
                <p>
                  <strong className="text-white">Revenue breakdown:</strong> Ad impressions contribute <strong className="text-emerald-400">${adRevenue.toFixed(2)}</strong>, while active community likes & comments provide another <strong className="text-emerald-400">${engagementRevenue.toFixed(2)}</strong>.
                </p>
              </li>
            </ul>
          </div>

          <div className="mt-8 pt-4 border-t border-zinc-800 flex items-start space-x-2.5 text-[11px] text-zinc-400 leading-relaxed font-semibold">
            <AlertCircle className="w-4 h-4 text-[#ff501a] shrink-0" />
            <p>
              Monetized views must conform to active safety guidelines. Earnings show estimated payouts calculated daily.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
