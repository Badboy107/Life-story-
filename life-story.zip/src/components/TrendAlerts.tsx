import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TrendingUp, Sparkles, X, Eye, Heart, MessageCircle, ArrowUpRight, Award, Bell, HelpCircle, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '../lib/utils';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

interface Story {
  id: string;
  title: string;
  viewsCount?: number;
  likesCount?: number;
  commentsCount?: number;
  createdAt?: any;
  category?: string;
}

export interface TrendAlert {
  id: string; // unique key e.g. storyId-metric
  storyId: string;
  storyTitle: string;
  metric: 'views' | 'likes' | 'comments' | 'engagement';
  currentValue: number;
  averageValue: number;
  percentageIncrease: number;
  tip: string;
}

interface TrendAlertsProps {
  stories: Story[];
  userId: string;
}

export default function TrendAlerts({ stories, userId }: TrendAlertsProps) {
  const [alerts, setAlerts] = useState<TrendAlert[]>([]);
  const [dismissedAlerts, setDismissedAlerts] = useState<string[]>([]);
  const [activeToast, setActiveToast] = useState<TrendAlert | null>(null);
  const [metricsChecked, setMetricsChecked] = useState(false);

  // Load dismissed alert keys from localStorage
  useEffect(() => {
    const cached = localStorage.getItem(`trend-alerts-dismissed-${userId}`);
    if (cached) {
      try {
        setDismissedAlerts(JSON.parse(cached));
      } catch (e) {
        console.error(e);
      }
    }
  }, [userId]);

  // Analyze stories for spikes
  useEffect(() => {
    if (stories.length < 2) {
      setAlerts([]);
      return;
    }

    // 1. Calculate totals and averages
    let totalViews = 0;
    let totalLikes = 0;
    let totalComments = 0;
    const n = stories.length;

    stories.forEach(story => {
      totalViews += story.viewsCount || 0;
      totalLikes += story.likesCount || 0;
      totalComments += story.commentsCount || 0;
    });

    const avgViews = totalViews / n;
    const avgLikes = totalLikes / n;
    const avgComments = totalComments / n;

    const detectedAlerts: TrendAlert[] = [];

    stories.forEach(story => {
      // Avoid checking stories with negligible activity to prevent false positive alerts
      const views = story.viewsCount || 0;
      const likes = story.likesCount || 0;
      const comments = story.commentsCount || 0;

      // Views Spike (Limit: > 15 views and > 50% above average)
      if (views > 15 && avgViews > 0 && views > avgViews * 1.5) {
        const percentage = Math.round(((views - avgViews) / avgViews) * 100);
        detectedAlerts.push({
          id: `${story.id}-views`,
          storyId: story.id,
          storyTitle: story.title,
          metric: 'views',
          currentValue: views,
          averageValue: Math.round(avgViews * 10) / 10,
          percentageIncrease: percentage,
          tip: "Reader interest is surging! Consider adding an engaging visual or writing a follow-up chapter to hook these visitors."
        });
      }

      // Likes Spike (Limit: > 5 likes and > 60% above average)
      if (likes > 5 && avgLikes > 0 && likes > avgLikes * 1.6) {
        const percentage = Math.round(((likes - avgLikes) / avgLikes) * 100);
        detectedAlerts.push({
          id: `${story.id}-likes`,
          storyId: story.id,
          storyTitle: story.title,
          metric: 'likes',
          currentValue: likes,
          averageValue: Math.round(avgLikes * 10) / 10,
          percentageIncrease: percentage,
          tip: "High appreciation rate! Share this story to your social media circles, as readers are highly receptive to its content."
        });
      }

      // Comments Spike (Limit: > 3 comments and > 70% above average)
      if (comments > 3 && avgComments > 0 && comments > avgComments * 1.7) {
        const percentage = Math.round(((comments - avgComments) / avgComments) * 100);
        detectedAlerts.push({
          id: `${story.id}-comments`,
          storyId: story.id,
          storyTitle: story.title,
          metric: 'comments',
          currentValue: comments,
          averageValue: Math.round(avgComments * 10) / 10,
          percentageIncrease: percentage,
          tip: "An active discussion is breeding in the comments! Jump in and reply to your readers to boost community engagement further."
        });
      }
    });

    // Sort alerts by highest percentage spike
    detectedAlerts.sort((a, b) => b.percentageIncrease - a.percentageIncrease);
    setAlerts(detectedAlerts);
    setMetricsChecked(true);

    // Trigger toast alert for the most significant alert if not seen/dismissed before
    const unseenAlert = detectedAlerts.find(a => {
      const isDismissed = dismissedAlerts.includes(a.id);
      const isToastSeen = localStorage.getItem(`trend-toast-seen-${userId}-${a.id}`);
      return !isDismissed && !isToastSeen;
    });

    if (unseenAlert) {
      setActiveToast(unseenAlert);
      localStorage.setItem(`trend-toast-seen-${userId}-${unseenAlert.id}`, 'true');
      
      // Attempt to save a silent trend notification in Firestore under recipient's collection
      saveFirestoreTrendNotification(unseenAlert);
    }
  }, [stories, userId, dismissedAlerts]);

  // Helper to persist trend alerts inside user's notifications collection
  const saveFirestoreTrendNotification = async (alert: TrendAlert) => {
    try {
      const metricLabel = alert.metric === 'views' ? 'views' : alert.metric === 'likes' ? 'likes' : 'comments';
      await addDoc(collection(db, 'notifications'), {
        recipientId: userId,
        senderId: userId, // Rule allows creating notifications where senderId === auth.uid
        type: 'view', // 'view' is allowed in firestore.rules data.type
        body: `Trend Alert! "${alert.storyTitle}" engagement spiked with ${alert.percentageIncrease}% higher ${metricLabel} than your average!`,
        isRead: false,
        link: `/stories/${alert.storyId}`,
        createdAt: serverTimestamp()
      });
    } catch (err) {
      console.warn("Failed to save Firestore trend notification:", err);
    }
  };

  const handleDismiss = (alertId: string) => {
    const updated = [...dismissedAlerts, alertId];
    setDismissedAlerts(updated);
    localStorage.setItem(`trend-alerts-dismissed-${userId}`, JSON.stringify(updated));
    if (activeToast?.id === alertId) {
      setActiveToast(null);
    }
  };

  const visibleAlerts = alerts.filter(a => !dismissedAlerts.includes(a.id));

  const getMetricIcon = (metric: 'views' | 'likes' | 'comments' | 'engagement') => {
    switch (metric) {
      case 'views':
        return <Eye className="w-5 h-5 text-indigo-500" />;
      case 'likes':
        return <Heart className="w-5 h-5 text-rose-500 fill-current" />;
      case 'comments':
        return <MessageCircle className="w-5 h-5 text-orange-500" />;
      default:
        return <TrendingUp className="w-5 h-5 text-indigo-500" />;
    }
  };

  const getMetricColorLabel = (metric: string) => {
    switch (metric) {
      case 'views': return 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/10 border-indigo-100 dark:border-indigo-900/20';
      case 'likes': return 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-900/10 border-rose-100 dark:border-rose-900/20';
      case 'comments': return 'text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-900/10 border-orange-100 dark:border-orange-900/20';
      default: return 'text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-zinc-900/10 border-gray-100 dark:border-zinc-800';
    }
  };

  return (
    <div className="w-full space-y-6">
      {/* Dynamic Toast Alert (Triggered on trend discovery) */}
      <AnimatePresence>
        {activeToast && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="fixed bottom-6 right-6 z-50 max-w-sm w-full bg-white dark:bg-zinc-950 rounded-2xl border border-indigo-500/30 shadow-2xl p-5 backdrop-blur-md relative overflow-hidden ring-1 ring-black/5"
            id="trend-toast-alert"
          >
            {/* Visual background gradient pulse */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 dark:bg-indigo-400/5 rounded-full blur-2xl -mr-16 -mt-16 pointer-events-none" />
            
            <div className="flex items-start space-x-3.5 relative z-10">
              <div className="p-2.5 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl flex-shrink-0 animate-bounce">
                <TrendingUp className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2">
                  <span className="px-2 py-0.5 bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 text-[10px] uppercase font-black tracking-widest rounded-full">Trend Spike</span>
                  <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                </div>
                <h4 className="text-[14px] font-black text-gray-900 dark:text-white tracking-tight mt-1 truncate">
                  {activeToast.storyTitle}
                </h4>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1.5 font-medium leading-relaxed">
                  Staging a massive growth spike! This story is performing <span className="font-bold text-gray-900 dark:text-white underline underline-offset-2 decoration-indigo-400">{activeToast.percentageIncrease}% higher</span> than your average benchmark.
                </p>
                <div className="flex items-center space-x-3 mt-4">
                  <Link
                    to={`/stories/${activeToast.storyId}`}
                    onClick={() => setActiveToast(null)}
                    className="inline-flex items-center text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                  >
                    View Analytics <ArrowUpRight className="w-3.5 h-3.5 ml-0.5" />
                  </Link>
                  <button
                    onClick={() => handleDismiss(activeToast.id)}
                    className="text-xs font-bold text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
              <button
                onClick={() => setActiveToast(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 p-0.5 hover:bg-gray-100 dark:hover:bg-zinc-900 rounded-lg transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Panel displayed in Dashboard */}
      <div 
        className="bg-white dark:bg-zinc-950 rounded-[2.5rem] p-8 border border-gray-100 dark:border-zinc-800 shadow-sm relative overflow-hidden group"
        id="trend-intelligence-panel"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 dark:bg-emerald-400/5 rounded-full blur-3xl opacity-60 -mr-32 -mt-32 pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 relative z-10">
          <div>
            <div className="flex items-center space-x-2.5">
              <Sparkles className="w-5 h-5 text-amber-500 animate-pulse" />
              <h2 className="text-xl font-black text-gray-900 dark:text-white tracking-tight">Trend Intelligence</h2>
            </div>
            <p className="text-xs text-gray-400 font-medium mt-1">Algorithmic baseline analysis of your story engagement spikes.</p>
          </div>
          {visibleAlerts.length > 0 && (
            <span className="px-3 py-1 bg-amber-500/10 text-amber-600 dark:text-amber-400 text-[10px] font-black uppercase tracking-widest rounded-full border border-amber-500/20 animate-pulse w-fit">
              {visibleAlerts.length} Active Spikes
            </span>
          )}
        </div>

        {/* Stories Baseline Benchmark Status */}
        {stories.length < 2 ? (
          <div className="py-10 text-center flex flex-col items-center justify-center relative z-10 border border-dashed border-gray-100 dark:border-zinc-800/80 rounded-3xl p-6 bg-gray-50/30 dark:bg-zinc-900/10">
            <HelpCircle className="w-12 h-12 text-gray-300 dark:text-zinc-800 mb-3" />
            <span className="text-sm font-bold text-gray-900 dark:text-white">Baseline Pending</span>
            <p className="text-xs text-gray-400 max-w-xs mt-1.5 font-medium leading-relaxed">
              We require at least 2 published stories to establish your historical baseline and initiate engagement trend alerts.
            </p>
          </div>
        ) : visibleAlerts.length === 0 ? (
          <div className="py-10 text-center flex flex-col items-center justify-center relative z-10 border border-solid border-gray-50 dark:border-zinc-900/50 rounded-3xl p-6 bg-gray-50/30 dark:bg-zinc-900/10">
            <CheckCircle2 className="w-12 h-12 text-green-500/70 mb-3" />
            <span className="text-sm font-bold text-gray-900 dark:text-white">Metrics Stable</span>
            <p className="text-xs text-gray-400 max-w-xs mt-1.5 font-medium leading-relaxed">
              Your stories are performing healthily and aligning around your current average benchmarks. We'll alert you the moment a new spike strikes!
            </p>
          </div>
        ) : (
          <div className="space-y-4 relative z-10">
            <AnimatePresence initial={false}>
              {visibleAlerts.map((alert) => (
                <motion.div
                  key={alert.id}
                  initial={{ opacity: 0, height: 0, marginBottom: 0 }}
                  animate={{ opacity: 1, height: 'auto', marginBottom: 16 }}
                  exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                  className="overflow-hidden"
                >
                  <div className="p-5 rounded-2xl border border-gray-100 dark:border-zinc-800/60 bg-gray-50/40 dark:bg-zinc-900/30 hover:border-indigo-500/20 hover:bg-white dark:hover:bg-zinc-900/60 transition-all duration-300 flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                    <div className={cn("p-3 rounded-xl border flex-shrink-0", getMetricColorLabel(alert.metric))}>
                      {getMetricIcon(alert.metric)}
                    </div>
                    
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-[15px] font-black text-gray-900 dark:text-white truncate max-w-xs sm:max-w-md">
                          {alert.storyTitle}
                        </h4>
                        <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[10px] font-black uppercase tracking-wider rounded-lg border border-emerald-500/25">
                          +{alert.percentageIncrease}% Spike
                        </span>
                      </div>
                      <p className="text-[13px] text-gray-500 dark:text-gray-400 font-medium">
                        Has accumulated <span className="font-bold text-gray-700 dark:text-gray-300">{alert.currentValue} {alert.metric}</span>, soaring above your baseline average of <span className="font-semibold text-gray-400">{alert.averageValue}</span>.
                      </p>
                      <p className="text-xs text-indigo-500/80 dark:text-indigo-400/70 font-semibold italic mt-1 leading-relaxed">
                        {alert.tip}
                      </p>
                    </div>

                    <div className="flex items-center space-x-3 w-full sm:w-auto justify-end flex-shrink-0">
                      <Link
                        to={`/stories/${alert.storyId}`}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-black uppercase tracking-wider rounded-xl transition duration-200 active:scale-95 inline-flex items-center space-x-1"
                      >
                        <span>Analyze</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </Link>
                      <button
                        onClick={() => handleDismiss(alert.id)}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-900 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-xl transition"
                        title="Dismiss alert"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
