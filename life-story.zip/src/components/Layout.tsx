import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { 
  BookOpen, Home, Plus, User, LayoutDashboard, Search as SearchIcon, 
  Bell, MessageCircle, Wallet, Bookmark, Menu, X, LogOut, Sun, Moon, 
  Settings, ChevronRight, HelpCircle, Shield, WifiOff, PenSquare, Award, Sparkles, BookCheck, Play, ShoppingBag
} from 'lucide-react';
import NotificationBell from './NotificationBell';
import MessageBadge from './MessageBadge';
import CallInterface from './CallInterface';
import { collection, query, where, onSnapshot, orderBy, Timestamp, Timestamp as FirestoreTimestamp, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export default function Layout() {
  const { currentUser, logout } = useAuth();
  const { isDarkMode, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isFormPage = location.pathname === '/add' || location.pathname.startsWith('/edit/') || location.pathname.startsWith('/edit-draft/');
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [profile, setProfile] = useState<any>(null);
  const [permissionError, setPermissionError] = useState<any>(null);
  const [showRulesHint, setShowRulesHint] = useState(false);

  useEffect(() => {
    const handlePermErr = (e: any) => {
      setPermissionError(e.detail || true);
    };
    window.addEventListener('firestore-permission-error', handlePermErr);
    return () => window.removeEventListener('firestore-permission-error', handlePermErr);
  }, []);

  useEffect(() => {
    if (!currentUser) {
      setProfile(null);
      return;
    }
    const userRef = doc(db, 'users', currentUser.uid);
    const unsubscribe = onSnapshot(userRef, (snapshot) => {
      if (snapshot.exists()) {
        setProfile(snapshot.data());
      }
    }, (error) => {
      console.warn("Error subscribing to profile in Layout:", error);
    });
    return () => unsubscribe();
  }, [currentUser]);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    // Close menu on route change
    setIsMenuOpen(false);
  }, [location.pathname]);

  if (!currentUser) {
    return <Outlet />; 
  }

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (err) {
      console.error("Logout failed", err);
    }
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-black text-white' : 'bg-gray-100 text-gray-900'} font-sans`}>
      {/* Side Menu Drawer */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 lg:hidden"
            />
            {/* Drawer */}
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-[280px] sm:w-[320px] bg-white dark:bg-zinc-950 z-50 border-r border-gray-200 dark:border-zinc-800 shadow-2xl overflow-y-auto"
            >
              <div className="p-4 flex items-center justify-between border-b border-gray-100 dark:border-zinc-900">
                <div className="flex items-center space-x-2">
                  <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-black text-xl">
                    L
                  </div>
                  <span className="font-bold text-xl dark:text-white">Life Story</span>
                </div>
                <button 
                  onClick={() => setIsMenuOpen(false)}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-900 rounded-full transition"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-4 space-y-6">
                {/* User Section */}
                <div className="space-y-3">
                  <div 
                    onClick={() => navigate(`/profile/${currentUser.uid}`)}
                    className="flex items-center space-x-3 p-2.5 bg-gray-50/50 dark:bg-zinc-900/20 hover:bg-gray-100 dark:hover:bg-zinc-900 rounded-2xl cursor-pointer transition border border-gray-100 dark:border-zinc-900"
                  >
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200 dark:bg-zinc-800 shrink-0">
                      {(profile?.photoURL || currentUser.photoURL) ? (
                        <img src={profile?.photoURL || currentUser.photoURL} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-400">
                          <User className="w-6 h-6" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-extrabold text-sm text-gray-900 dark:text-white truncate">
                        {profile?.displayName || currentUser.displayName || 'Me'}
                      </p>
                      <div className="flex items-center space-x-1 mt-0.5">
                        <Award className="w-3 h-3 text-indigo-500" />
                        <span className="text-[9px] uppercase tracking-wider font-extrabold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 px-1.5 py-0.5 rounded">
                          {(profile?.followersCount || 0) >= 20 ? 'Elite Novelist' : (profile?.followersCount || 0) >= 5 ? 'Rising Star' : 'Wordsmith'}
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400 shrink-0" />
                  </div>

                  {/* Profile Quick Stats Bento */}
                  <div className="grid grid-cols-2 gap-2 text-center">
                    <div 
                      onClick={() => {
                        setIsMenuOpen(false);
                        navigate(`/profile/${currentUser.uid}?tab=followers`);
                      }}
                      className="p-2 rounded-xl bg-gray-50/20 dark:bg-zinc-900/10 border border-gray-100/60 dark:border-zinc-900/40 hover:bg-gray-100/60 dark:hover:bg-zinc-900/30 transition cursor-pointer"
                    >
                      <div className="text-sm font-black text-gray-900 dark:text-white">{profile?.followersCount || 0}</div>
                      <div className="text-[9px] uppercase tracking-wider font-bold text-gray-400">Followers</div>
                    </div>
                    <div 
                      onClick={() => {
                        setIsMenuOpen(false);
                        navigate(`/profile/${currentUser.uid}?tab=following`);
                      }}
                      className="p-2 rounded-xl bg-gray-50/20 dark:bg-zinc-900/10 border border-gray-100/60 dark:border-zinc-900/40 hover:bg-gray-100/60 dark:hover:bg-zinc-900/30 transition cursor-pointer"
                    >
                      <div className="text-sm font-black text-gray-900 dark:text-white">{profile?.followingCount || 0}</div>
                      <div className="text-[9px] uppercase tracking-wider font-bold text-gray-400">Following</div>
                    </div>
                  </div>
                </div>

                {/* Milestones / Streaks Card */}
                <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-500/5 to-purple-500/5 dark:from-indigo-500/10 dark:to-purple-500/10 border border-indigo-100/40 dark:border-indigo-950/40 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-1.5">
                      <Sparkles className="w-4 h-4 text-indigo-500 animate-pulse" />
                      <span className="text-[11px] uppercase tracking-wider font-extrabold text-indigo-600 dark:text-indigo-400">Writer Milestone</span>
                    </div>
                    <span className="text-[10px] font-black text-gray-400 dark:text-zinc-500">
                      {Math.min(100, Math.round(((profile?.followersCount || 0) / 20) * 100))}%
                    </span>
                  </div>
                  
                  {/* Compact progress bar */}
                  <div className="w-full h-1.5 bg-gray-100 dark:bg-zinc-900 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300"
                      style={{ width: `${Math.min(100, Math.max(8, ((profile?.followersCount || 0) / 20) * 100))}%` }}
                    />
                  </div>
                  
                  <p className="text-[11px] text-gray-500 dark:text-zinc-400 leading-normal">
                    {(profile?.followersCount || 0) >= 20 
                      ? "🎉 Elite Novelist! You have achieved the ultimate storytelling tier." 
                      : (profile?.followersCount || 0) >= 5 
                      ? `Get ${20 - (profile?.followersCount || 0)} more followers to unlock Elite Novelist rank.`
                      : `Get ${5 - (profile?.followersCount || 0)} more followers to unlock Rising Star rank.`}
                  </p>
                </div>

                {/* Main Links */}
                <div className="space-y-1">
                  <MenuLink to="/" icon={Home} label="Home Feed" />
                  <MenuLink to="/dashboard" icon={LayoutDashboard} label="Professional Dashboard" />
                  <MenuLink to={`/profile/${currentUser.uid}?tab=drafts`} icon={PenSquare} label="My Story Drafts" />
                  <MenuLink to="/saved" icon={Bookmark} label="Saved Content" />
                  <MenuLink to="/payouts" icon={Wallet} label="Payments & Wallet" />
                  <MenuLink to="/shop" icon={ShoppingBag} label="Code & Game Shop" />
                  <MenuLink to="/add" icon={Plus} label="Create New Story" />
                  <MenuLink to="/search" icon={SearchIcon} label="Search Stories" />
                  <MenuLink to="/messenger" icon={MessageCircle} label="Messenger Chats" />
                  {(currentUser?.email === 'msojib724@gmail.com' || currentUser?.email === 'Starbad366@gmail.com') && (
                    <MenuLink to="/admin" icon={Shield} label="Admin Portal" />
                  )}
                </div>

                {/* Settings & Support */}
                <div className="pt-4 border-t border-gray-100 dark:border-zinc-900 space-y-1">
                  <h3 className="px-3 text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Settings & Support</h3>
                  <button 
                    onClick={toggleTheme}
                    className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-zinc-900 rounded-xl transition text-left"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="bg-gray-100 dark:bg-zinc-900 p-2 rounded-lg">
                        {isDarkMode ? <Sun className="w-5 h-5 text-yellow-500" /> : <Moon className="w-5 h-5 text-indigo-600" />}
                      </div>
                      <span className="font-medium text-[15px]">{isDarkMode ? 'Light Mode' : 'Dark Mode'}</span>
                    </div>
                  </button>
                  <MenuLink to="/notifications" icon={Settings} label="Notification Settings" />
                  <button className="w-full flex items-center space-x-3 p-3 hover:bg-gray-50 dark:hover:bg-zinc-900 rounded-xl transition text-left">
                    <div className="bg-gray-100 dark:bg-zinc-900 p-2 rounded-lg"><HelpCircle className="w-5 h-5 text-gray-500" /></div>
                    <span className="font-medium text-[15px]">Help & Support</span>
                  </button>
                  <button className="w-full flex items-center space-x-3 p-3 hover:bg-gray-50 dark:hover:bg-zinc-900 rounded-xl transition text-left">
                    <div className="bg-gray-100 dark:bg-zinc-900 p-2 rounded-lg"><Shield className="w-5 h-5 text-gray-500" /></div>
                    <span className="font-medium text-[15px]">Privacy Policy</span>
                  </button>
                </div>

                {/* Footer Action */}
                <button 
                  onClick={async () => {
                    if (confirm("DELETE ACCOUNT? \n\nThis will permanently delete your profile. This action cannot be undone.")) {
                      try {
                        await deleteDoc(doc(db, 'users', currentUser.uid));
                        await logout();
                        navigate('/login');
                      } catch (err) {
                        console.error("Delete failed", err);
                        alert("Could not delete account. Try again later.");
                      }
                    }
                  }}
                  className="w-full flex items-center space-x-3 p-3 text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/10 rounded-xl transition text-left font-medium text-xs uppercase tracking-widest opacity-60 hover:opacity-100"
                >
                  <div className="bg-red-50 dark:bg-red-950/20 p-2 rounded-lg"><X className="w-4 h-4" /></div>
                  <span>Delete Account</span>
                </button>

                <button 
                  onClick={handleLogout}
                  className="w-full flex items-center space-x-3 p-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20 rounded-xl transition text-left font-bold"
                >
                  <div className="bg-red-100 dark:bg-red-950/30 p-2 rounded-lg"><LogOut className="w-5 h-5" /></div>
                  <span className="text-[15px]">Log Out</span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {!isFormPage && (
        <header className="sticky top-0 z-20 bg-white dark:bg-black border-b border-gray-200 dark:border-zinc-800 shadow-sm">
        <div className="max-w-4xl mx-auto px-4">
          
          {/* Top Row: Menu, Logo and FB-Style Action Icons */}
          <div className="flex items-center justify-between h-14">
            
            <div className="flex items-center space-x-3">
              <button 
                onClick={() => setIsMenuOpen(true)}
                className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-900 rounded-full transition"
                title="Main Menu"
              >
                <Menu className="w-6 h-6 text-gray-900 dark:text-white" />
              </button>
              
              <NavLink to="/" className="flex items-center space-x-0.5 text-indigo-600 dark:text-white">
                <span className="font-black text-2xl sm:text-3xl tracking-tight lowercase">life story</span>
              </NavLink>
            </div>

            {/* Right Side Icons (FB Style) */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              <NavLink 
                to="/payouts" 
                className={({isActive}) => `hidden sm:flex p-2.5 rounded-full transition-colors ${isActive ? 'bg-indigo-100 dark:bg-zinc-900 text-indigo-600 dark:text-white' : 'bg-gray-100 dark:bg-zinc-900 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-zinc-800'}`}
                title="Wallet & Payouts"
              >
                <Wallet className="w-5 h-5" />
              </NavLink>

              <NavLink 
                to="/add" 
                className={({isActive}) => `flex p-2 rounded-full transition-colors ${isActive ? 'bg-indigo-100 dark:bg-zinc-900 text-indigo-600 dark:text-white' : 'bg-gray-100 dark:bg-zinc-900 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-zinc-800'}`}
                title="Create Story"
              >
                <div className="border-2 border-current rounded-lg p-0.5">
                  <Plus className="w-5 h-5" />
                </div>
              </NavLink>

              <NavLink 
                to="/search" 
                className={({isActive}) => `flex p-2.5 rounded-full transition-colors ${isActive ? 'bg-indigo-100 dark:bg-zinc-900 text-indigo-600 dark:text-white' : 'bg-gray-100 dark:bg-zinc-900 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-zinc-800'}`}
                title="Search"
              >
                <SearchIcon className="w-5 h-5" />
              </NavLink>

              <NavLink 
                to="/messenger" 
                className={({isActive}) => `flex p-2.5 rounded-full transition-colors relative ${isActive ? 'bg-indigo-100 dark:bg-zinc-900 text-indigo-600 dark:text-white' : 'bg-gray-100 dark:bg-zinc-900 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-zinc-800'}`}
                title="Messenger"
              >
                <MessageBadge />
              </NavLink>
            </div>
          </div>

          {/* Secondary Row: Navigation Tabs */}
          <div className="flex items-center justify-between mt-1 sm:mt-0 px-2 sm:px-0">
            <NavLink to="/" className={({isActive}) => `flex-1 py-3 flex justify-center border-b-[3px] transition-colors ${isActive ? 'border-indigo-600 text-indigo-600 dark:border-white dark:text-white' : 'border-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-zinc-900'}`}>
              <Home className={`w-[26px] h-[26px] ${location.pathname === '/' ? 'fill-current' : ''}`} />
            </NavLink>
            
            <NavLink to="/notifications" className={({isActive}) => `flex-1 py-3 flex justify-center border-b-[3px] transition-colors ${isActive ? 'border-indigo-600 text-indigo-600 dark:border-white dark:text-white' : 'border-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-zinc-900'}`}>
              <NotificationBell />
            </NavLink>

            <NavLink to="/dashboard" className={({isActive}) => `flex-1 py-3 flex justify-center border-b-[3px] transition-colors ${isActive ? 'border-indigo-600 text-indigo-600 dark:border-white dark:text-white' : 'border-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-zinc-900'}`}>
              <LayoutDashboard className={`w-[26px] h-[26px] ${location.pathname === '/dashboard' ? 'fill-current' : ''}`} />
            </NavLink>

            <NavLink to="/saved" className={({isActive}) => `flex-1 py-3 flex justify-center border-b-[3px] transition-colors ${isActive ? 'border-indigo-600 text-indigo-600 dark:border-white dark:text-white' : 'border-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-zinc-900'}`}>
              <Bookmark className={`w-[26px] h-[26px] ${location.pathname === '/saved' ? 'fill-current' : ''}`} />
            </NavLink>

            <NavLink to={`/profile/${currentUser.uid}`} className={({isActive}) => `flex-1 py-3 flex justify-center border-b-[3px] transition-colors ${isActive ? 'border-indigo-600 text-indigo-600 dark:border-white dark:text-white' : 'border-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-zinc-900'}`}>
              <User className={`w-[26px] h-[26px] ${location.pathname.startsWith('/profile') ? 'fill-current' : ''}`} />
            </NavLink>
          </div>

        </div>
      </header>
      )}

      <main className={isFormPage ? "min-h-screen" : "max-w-4xl mx-auto px-0 sm:px-4 py-4 sm:py-6"}>
        <AnimatePresence>
          {isOffline && (
            <motion.div 
              initial={{ opacity: 0, y: -12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              className="mx-4 sm:mx-0 mb-4 p-3 bg-amber-500/10 border border-amber-500/20 dark:border-amber-500/10 rounded-2xl flex items-center justify-between text-amber-700 dark:text-amber-400 text-xs font-bold shadow-sm"
            >
              <div className="flex items-center space-x-2">
                <WifiOff className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Offline Mode Active • Content remains readable from local storage cache</span>
              </div>
              <span className="bg-amber-500/15 text-[10px] uppercase px-2 py-0.5 rounded-lg shrink-0">Offline</span>
            </motion.div>
          )}

          {permissionError && (
            <motion.div
              initial={{ opacity: 0, y: -12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              className="mx-4 sm:mx-0 mb-4 p-4 sm:p-5 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 rounded-2xl shadow-sm text-sm"
              id="firestore-permission-warning"
            >
              <div className="flex items-start space-x-3">
                <div className="bg-red-100 dark:bg-red-900/40 p-2.5 rounded-xl shrink-0 text-red-600 dark:text-red-400">
                  <Shield className="w-5 h-5 animate-pulse" />
                </div>
                <div className="flex-1 space-y-2">
                  <h4 className="font-extrabold text-[15px] text-red-800 dark:text-red-300">
                    Firestore Security Rules Update Required
                  </h4>
                  <p className="text-xs text-red-700/80 dark:text-red-400/80 leading-relaxed font-semibold">
                    Your application is connected to your private Firebase project (<code className="bg-red-100/50 dark:bg-red-950/50 px-1.5 py-0.5 rounded font-mono text-[11px] text-red-900 dark:text-red-300">life-story-b1df0</code>), but reads or writes are being rejected. This is because your Firestore Security Rules on the Firebase Console need to be updated.
                  </p>
                  
                  <div className="flex flex-wrap gap-2 pt-1">
                    <a
                      href="https://console.firebase.google.com/project/life-story-b1df0/firestore/rules"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition inline-flex items-center space-x-1"
                    >
                      <span>Open Firebase Rules Console</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </a>
                    
                    <button
                      onClick={() => setShowRulesHint(!showRulesHint)}
                      className="bg-gray-100 hover:bg-gray-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-gray-700 dark:text-zinc-300 text-xs font-bold px-3 py-1.5 rounded-lg transition"
                    >
                      {showRulesHint ? 'Hide Instructions' : 'View Instructions'}
                    </button>
                    
                    <button
                      onClick={() => setPermissionError(null)}
                      className="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 text-xs font-extrabold px-3 py-1.5 border border-red-200 dark:border-red-900/40 rounded-lg hover:bg-red-100/30 transition"
                    >
                      Dismiss
                    </button>
                  </div>

                  <AnimatePresence>
                    {showRulesHint && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mt-4 pt-3.5 border-t border-red-200/50 dark:border-red-900/30 space-y-3 overflow-hidden text-xs text-gray-750 dark:text-zinc-305"
                      >
                        <h5 className="font-extrabold uppercase text-[10px] tracking-wider text-red-800 dark:text-red-300">How to Fix This:</h5>
                        <ol className="list-decimal list-inside space-y-2 font-medium">
                          <li>Click the <strong>Open Firebase Rules Console</strong> button above (takes you to your Firestore dashboard).</li>
                          <li>Open the file named <span className="underline font-bold font-mono">firestore.rules</span> in your project directory at the root level.</li>
                          <li>Copy its entire content (<kbd className="bg-gray-100 dark:bg-zinc-800 px-1 py-0.5 rounded font-mono shadow text-[10px]">Ctrl+A</kbd> then <kbd className="bg-gray-100 dark:bg-zinc-800 px-1 py-0.5 rounded font-mono shadow text-[10px]">Ctrl+C</kbd>).</li>
                          <li>In the Firebase Console Rules editor, delete any existing default rules, paste the new ruleset, and click <strong>Publish</strong>.</li>
                        </ol>
                        <p className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/20 p-2.5 rounded-xl border border-indigo-100/40 dark:border-indigo-950/40">
                          💡 Once published, the app's feed rank, story reading, creator following, and chats will start functioning flawlessly and securely instantly!
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <Outlet />
      </main>
      <CallInterface />
    </div>
  );
}

function MenuLink({ to, icon: Icon, label }: { to: string, icon: any, label: string }) {
  let iconBg = 'bg-gray-100 dark:bg-zinc-900 text-gray-500 dark:text-zinc-400';
  if (to === '/') iconBg = 'bg-amber-100 dark:bg-amber-900/30 text-amber-500';
  else if (to === '/dashboard') iconBg = 'bg-blue-100 dark:bg-blue-900/10 text-blue-500';
  else if (to === '/saved') iconBg = 'bg-pink-100 dark:bg-pink-900/10 text-pink-500';
  else if (to === '/payouts') iconBg = 'bg-emerald-100 dark:bg-emerald-900/10 text-emerald-500';
  else if (to === '/shop') iconBg = 'bg-amber-100 dark:bg-amber-900/20 text-amber-500';
  else if (to === '/add') iconBg = 'bg-violet-100 dark:bg-violet-900/10 text-violet-500';
  else if (to.includes('tab=drafts')) iconBg = 'bg-rose-100 dark:bg-rose-900/10 text-rose-500';
  else if (to === '/search') iconBg = 'bg-teal-100 dark:bg-teal-900/10 text-teal-500';
  else if (to === '/messenger') iconBg = 'bg-purple-100 dark:bg-purple-900/10 text-purple-500';
  else if (to === '/notifications') iconBg = 'bg-orange-100 dark:bg-orange-900/10 text-orange-500';
  else if (to === '/admin') iconBg = 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-500';

  return (
    <NavLink 
      to={to} 
      className={({isActive}) => `flex items-center space-x-3 p-3 rounded-xl transition ${isActive ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-zinc-900'}`}
    >
      <div className={`p-2 rounded-lg ${iconBg}`}>
        <Icon className="w-5 h-5" />
      </div>
      <span className="font-semibold text-[15px]">{label}</span>
    </NavLink>
  );
}
