import React, { useState, useMemo } from 'react';
import { 
  AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, 
  CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, 
  PolarAngleAxis, PolarRadiusAxis, Radar, ComposedChart
} from 'recharts';
import { 
  TrendingUp, Eye, Heart, MessageCircle, DollarSign, Award, 
  Activity, Star, BarChart3, HelpCircle, Calendar, Sparkles, AlertCircle
} from 'lucide-react';
import { MONETIZATION_RATES, STORY_CATEGORIES } from '../lib/constants';

interface AnalyticsProps {
  stories: any[];
  stats: {
    totalStories: number;
    totalLikes: number;
    totalComments: number;
    totalViews: number;
  };
}

export default function Analytics({ stories, stats }: AnalyticsProps) {
  const [timeRange, setTimeRange] = useState<'all' | '30days' | '7days'>('all');
  const [chartType, setChartType] = useState<'views' | 'engagement' | 'earnings'>('views');

  const { LIKES_REQUIREMENT, STORIES_REQUIREMENT, PER_LIKE, PER_COMMENT, PER_VIEW_AD } = MONETIZATION_RATES;
  const isEligible = stats.totalLikes >= LIKES_REQUIREMENT && stats.totalStories >= STORIES_REQUIREMENT;

  // 1. Process Stories and sort them Chronologically (Oldest to Newest)
  const processedStories = useMemo(() => {
    return [...stories]
      .map(story => {
        const timestamp = story.createdAt;
        const date = timestamp?.toDate 
          ? timestamp.toDate() 
          : (timestamp?.seconds 
              ? new Date(timestamp.seconds * 1000) 
              : new Date());
        
        const likes = story.likesCount || 0;
        const comments = story.commentsCount || 0;
        const views = story.viewsCount || 0;
        
        // Monetization estimation
        const storyEarnings = (likes * PER_LIKE) + (comments * PER_COMMENT) + (isEligible ? (views * PER_VIEW_AD) : 0);

        return {
          id: story.id,
          title: story.title,
          category: story.category || 'general',
          views,
          likes,
          comments,
          engagement: likes + comments,
          earnings: parseFloat(storyEarnings.toFixed(2)),
          date,
          formattedDate: date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
          rawTimestamp: date.getTime()
        };
      })
      .sort((a, b) => a.rawTimestamp - b.rawTimestamp); // Chronological
  }, [stories, isEligible, PER_LIKE, PER_COMMENT, PER_VIEW_AD]);

  // Apply filters for time range if needed
  const filteredData = useMemo(() => {
    if (timeRange === 'all') return processedStories;
    const now = Date.now();
    const daysLimit = timeRange === '7days' ? 7 : 30;
    const cutoffTime = now - daysLimit * 24 * 60 * 60 * 1000;
    return processedStories.filter(story => story.rawTimestamp >= cutoffTime);
  }, [processedStories, timeRange]);

  // Aggregate stats over filtered range
  const filteredStats = useMemo(() => {
    let views = 0;
    let likes = 0;
    let comments = 0;
    let earnings = 0;

    filteredData.forEach(story => {
      views += story.views;
      likes += story.likes;
      comments += story.comments;
      earnings += story.earnings;
    });

    return { views, likes, comments, earnings };
  }, [filteredData]);

  // Category Analytics (views, engagement density per category)
  const categoryAnalytics = useMemo(() => {
    const categoriesMap: Record<string, { category: string; views: number; likes: number; comments: number; count: number }> = {};
    STORY_CATEGORIES.forEach(cat => {
      categoriesMap[cat] = {
        category: cat.charAt(0).toUpperCase() + cat.slice(1),
        views: 0,
        likes: 0,
        comments: 0,
        count: 0
      };
    });

    processedStories.forEach(s => {
      const catKey = s.category.toLowerCase();
      if (categoriesMap[catKey]) {
        categoriesMap[catKey].views += s.views;
        categoriesMap[catKey].likes += s.likes;
        categoriesMap[catKey].comments += s.comments;
        categoriesMap[catKey].count += 1;
      }
    });

    return Object.values(categoriesMap).filter(item => item.count > 0);
  }, [processedStories]);

  // Empty state handling
  if (stories.length === 0) {
    return (
      <div className="bg-white dark:bg-zinc-950 rounded-[2.5rem] border border-gray-100 dark:border-zinc-800 p-12 text-center max-w-2xl mx-auto shadow-sm my-10">
        <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <BarChart3 className="w-8 h-8" />
        </div>
        <h3 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight mb-2">No Analytics Collected Yet</h3>
        <p className="text-gray-500 dark:text-gray-400 text-sm max-w-sm mx-auto leading-relaxed mb-6">
          Once you create your first life story and other users interact with it, deep engagement trends, view times, and earnings graphs will appear here.
        </p>
      </div>
    );
  }

  // Get cumulative stats for charting earnings projection
  const finalChartData = filteredData.map((d, index) => {
    // Generate simple cumulative earnings trend
    const chunkBefore = filteredData.slice(0, index + 1);
    const cumulativeEarnings = chunkBefore.reduce((acc, curr) => acc + curr.earnings, 0);

    return {
      ...d,
      "Cumulative Earnings": parseFloat(cumulativeEarnings.toFixed(2)),
      "Story Views": d.views,
      "Likes Interaction": d.likes,
      "Comments Discussion": d.comments,
      "Engagement Index": d.likes * 3 + d.comments * 5
    };
  });

  return (
    <div className="space-y-10" id="analytics-component">
      {/* Top filter control bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-gray-50 dark:bg-zinc-900/40 border border-gray-100/80 dark:border-zinc-800/80 rounded-[2rem] p-4">
        <div className="flex items-center space-x-3">
          <Activity className="w-5 h-5 text-indigo-500" />
          <span className="text-sm font-black text-gray-900 dark:text-white tracking-tight uppercase">Metric Framework</span>
        </div>
        <div className="flex space-x-1 w-full sm:w-auto">
          {(['all', '30days', '7days'] as const).map(range => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`flex-1 sm:flex-none px-4 py-2 text-xs font-bold rounded-xl transition-all duration-300 capitalize ${
                timeRange === range
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                  : 'text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
              }`}
            >
              {range === 'all' ? 'All Time' : range === '30days' ? 'Last 30 Days' : 'Last 7 Days'}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of micro cards detailing filtered range results */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-zinc-950 p-6 rounded-[2rem] border border-gray-100 dark:border-zinc-800 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-2xl -mr-12 -mt-12"></div>
          <span className="text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest block mb-1">Range Views</span>
          <span className="text-2xl font-black text-zinc-900 dark:text-white tracking-tighter block">{filteredStats.views.toLocaleString()}</span>
          <div className="flex items-center space-x-1.5 mt-2">
            <Eye className="w-3.5 h-3.5 text-indigo-500" />
            <span className="text-[11px] font-bold text-gray-400">Total verified reach</span>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-950 p-6 rounded-[2rem] border border-gray-100 dark:border-zinc-800 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-rose-500/5 rounded-full blur-2xl -mr-12 -mt-12"></div>
          <span className="text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest block mb-1">Range Likes</span>
          <span className="text-2xl font-black text-zinc-900 dark:text-white tracking-tighter block">{filteredStats.likes.toLocaleString()}</span>
          <div className="flex items-center space-x-1.5 mt-2">
            <Heart className="w-3.5 h-3.5 text-rose-500" />
            <span className="text-[11px] font-bold text-gray-400">Audience appreciation</span>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-950 p-6 rounded-[2rem] border border-gray-100 dark:border-zinc-800 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl -mr-12 -mt-12"></div>
          <span className="text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest block mb-1">Range Comments</span>
          <span className="text-2xl font-black text-zinc-900 dark:text-white tracking-tighter block">{filteredStats.comments.toLocaleString()}</span>
          <div className="flex items-center space-x-1.5 mt-2">
            <MessageCircle className="w-3.5 h-3.5 text-amber-500" />
            <span className="text-[11px] font-bold text-gray-400">Community discussions</span>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-950 p-6 rounded-[2rem] border border-gray-100 dark:border-zinc-800 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl -mr-12 -mt-12"></div>
          <span className="text-[10px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-widest block mb-1">Estimated earnings</span>
          <span className="text-2xl font-black text-zinc-900 dark:text-white tracking-tighter block">${filteredStats.earnings.toFixed(2)}</span>
          <div className="flex items-center space-x-1.5 mt-2">
            <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
            <span className="text-[11px] font-bold text-gray-400">{isEligible ? "Partner pool active" : "Projected if eligible"}</span>
          </div>
        </div>
      </div>

      {/* Main Graph Card with state selectors */}
      <div className="bg-white dark:bg-zinc-950 border border-gray-100 dark:border-zinc-800 rounded-[2.5rem] p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h2 className="text-xl font-black text-gray-900 dark:text-white tracking-tight">Interactive Trend Center</h2>
            <p className="text-xs text-gray-400 font-medium mt-1">Visualize content engagement parameters chronologically</p>
          </div>

          {/* Tab selector for Chart types */}
          <div className="flex p-0.5 bg-gray-100 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-2xl w-full sm:w-auto">
            <button
              onClick={() => setChartType('views')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-300 ${
                chartType === 'views'
                  ? 'bg-white dark:bg-black text-gray-900 dark:text-white shadow-md'
                  : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-200'
              }`}
            >
              Reach
            </button>
            <button
              onClick={() => setChartType('engagement')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-300 ${
                chartType === 'engagement'
                  ? 'bg-white dark:bg-black text-gray-900 dark:text-white shadow-md'
                  : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-200'
              }`}
            >
              Interactions
            </button>
            <button
              onClick={() => setChartType('earnings')}
              className={`flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-300 ${
                chartType === 'earnings'
                  ? 'bg-white dark:bg-black text-gray-900 dark:text-white shadow-md'
                  : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-200'
              }`}
            >
              Earnings
            </button>
          </div>
        </div>

        {/* Real Recharts Visualizations */}
        <div className="h-80 w-full relative z-10">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'views' ? (
              <AreaChart data={finalChartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="viewGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.01}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.1)" />
                <XAxis 
                  dataKey="formattedDate" 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  dy={8}
                />
                <YAxis 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(0,0,0,0.85)', 
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255,255,255,0.12)', 
                    borderRadius: '20px', 
                    color: '#fff',
                    padding: '12px',
                    fontSize: '12px',
                    boxShadow: '0 10px 25px -5px rgba(0,0,0,0.3)'
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="Story Views" 
                  stroke="#4f46e5" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#viewGrad)" 
                />
              </AreaChart>
            ) : chartType === 'engagement' ? (
              <ComposedChart data={finalChartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="commentsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.8}/>
                    <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.1)" />
                <XAxis 
                  dataKey="formattedDate" 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false}
                  dy={8}
                />
                <YAxis 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(0,0,0,0.85)', 
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255,255,255,0.12)', 
                    borderRadius: '20px', 
                    color: '#fff',
                    padding: '12px',
                    fontSize: '12px',
                    boxShadow: '0 10px 25px -5px rgba(0,0,0,0.3)'
                  }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', fontWeight: 'bold', paddingTop: '10px' }} />
                <Bar dataKey="Comments Discussion" fill="url(#commentsGrad)" radius={[6, 6, 0, 0]} barSize={16} />
                <Line type="monotone" dataKey="Likes Interaction" stroke="#ec4899" strokeWidth={3} dot={{ stroke: '#ec4899', strokeWidth: 2, r: 4 }} />
              </ComposedChart>
            ) : (
              <AreaChart data={finalChartData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="earnGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.01}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(120, 120, 120, 0.1)" />
                <XAxis 
                  dataKey="formattedDate" 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  dy={8}
                />
                <YAxis 
                  stroke="#888" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  tickFormatter={(val) => `$${val}`}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(0,0,0,0.85)', 
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255,255,255,0.12)', 
                    borderRadius: '20px', 
                    color: '#fff',
                    padding: '12px',
                    fontSize: '12px',
                    boxShadow: '0 10px 25px -5px rgba(0,0,0,0.3)'
                  }}
                  formatter={(value: any) => [`$${value}`, 'Cumulative USD']}
                />
                <Area 
                  type="monotone" 
                  dataKey="Cumulative Earnings" 
                  stroke="#10b981" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#earnGrad)" 
                />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Two-Column split details layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Category Performance Matrix (Left Column) */}
        <div className="lg:col-span-7 bg-white dark:bg-zinc-950 border border-gray-100 dark:border-zinc-800 rounded-[2.5rem] p-8 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-black text-gray-900 dark:text-white tracking-tight">Segment Profile</h3>
              <p className="text-xs text-gray-400 font-medium">Metric density grouped by category tags</p>
            </div>
            <Sparkles className="w-5 h-5 text-violet-500" />
          </div>

          {categoryAnalytics.length > 0 ? (
            <div className="space-y-5">
              {categoryAnalytics.map((cat, i) => {
                const maxViews = Math.max(...categoryAnalytics.map(c => c.views), 1);
                const percentViews = (cat.views / maxViews) * 100;
                
                return (
                  <div key={i} className="group p-4 bg-gray-50/50 dark:bg-zinc-900/20 rounded-2xl border border-gray-100/50 dark:border-zinc-900/50 hover:scale-[1.01] transition-all">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-black uppercase text-gray-800 dark:text-gray-300 tracking-tight">{cat.category}</span>
                      <span className="text-[10px] font-bold text-gray-400">{cat.count} {cat.count === 1 ? 'story' : 'stories'} match</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-[11px] font-bold text-gray-400 mb-2">
                      <div>Views: <span className="text-gray-900 dark:text-white">{cat.views.toLocaleString()}</span></div>
                      <div>Likes: <span className="text-rose-500">{cat.likes.toLocaleString()}</span></div>
                      <div>Comments: <span className="text-amber-500">{cat.comments.toLocaleString()}</span></div>
                    </div>
                    <div className="w-full bg-gray-100 dark:bg-zinc-900 h-1.5 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${percentViews}%` }}></div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-12 text-center text-gray-400 text-xs font-medium">
              No categories mapped sufficiently yet.
            </div>
          )}
        </div>

        {/* Content Spotlight & Insights (Right Column) */}
        <div className="lg:col-span-5 flex flex-col justify-between bg-zinc-900 dark:bg-zinc-950 border border-zinc-800 dark:border-zinc-800 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-sm">
          <div className="absolute top-0 right-0 w-48 h-48 bg-violet-600/10 rounded-full blur-3xl opacity-50 -mr-24 -mt-24"></div>
          <div>
            <div className="flex items-center space-x-2 text-violet-400 mb-6 font-bold uppercase tracking-wider text-xs">
              <Star className="w-4 h-4 fill-violet-400" />
              <span>Performance Spotlight</span>
            </div>

            {(() => {
              const topStoryByViews = [...processedStories].sort((a,b) => b.views - a.views)[0];
              if (!topStoryByViews) return <p className="text-sm font-medium text-zinc-400">Write high-reach content to unlock Spotlight awards!</p>;
              
              return (
                <div className="space-y-4">
                  <h4 className="text-xl font-black tracking-tight text-white leading-snug line-clamp-2">
                    {topStoryByViews.title}
                  </h4>
                  <p className="text-xs text-zinc-400 leading-relaxed font-medium">
                    This story achieved your highest verified user reach of <span className="text-white font-bold">{topStoryByViews.views.toLocaleString()} views</span>. 
                    It generated an interactive coefficient of <span className="text-rose-400 font-bold">{topStoryByViews.likes} likes</span> and <span className="text-amber-400 font-bold">{topStoryByViews.comments} comments</span>.
                  </p>
                  
                  <div className="grid grid-cols-2 gap-3 pt-4">
                    <div className="bg-zinc-800/50 rounded-2xl p-4 border border-zinc-700/30">
                      <span className="text-[10px] text-zinc-400 uppercase tracking-widest block font-bold mb-1">Spotlight Category</span>
                      <span className="text-sm font-black capitalize text-violet-300">{topStoryByViews.category}</span>
                    </div>
                    <div className="bg-zinc-800/50 rounded-2xl p-4 border border-zinc-700/30">
                      <span className="text-[10px] text-zinc-400 uppercase tracking-widest block font-bold mb-1">Estimated Return</span>
                      <span className="text-sm font-black text-emerald-400">${topStoryByViews.earnings.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>

          <div className="mt-8 pt-6 border-t border-zinc-800 flex items-start space-x-3 text-xs text-zinc-404">
            <AlertCircle className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <p className="text-zinc-400 leading-relaxed font-medium">
              Daily earnings calculation is subject to platform-wide monetization requirements. Verify payouts and program terms under the <span className="text-indigo-400 font-bold">Monetization</span> tab.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
