import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, getDocs, doc, getDoc, updateDoc, increment, setDoc, deleteDoc, serverTimestamp, where, writeBatch } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { formatDistanceToNow } from 'date-fns';
import { Heart, MessageCircle, User, BookOpen, Share2, Plus, Loader2, Eye, Clock, Bookmark, Sparkles, UserPlus, UserCheck, Check } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { handleFirestoreError, calculateReadingTime } from '../lib/utils';
import StoryComments from '../components/StoryComments';
import ReactionButton from '../components/ReactionButton';
import { motion, AnimatePresence } from 'motion/react';
import StoriesSection from '../components/StoriesSection';
import { createNotification } from '../lib/notifications';
import { STORY_CATEGORIES } from '../lib/constants';

interface Story {
  id: string;
  authorId: string;
  title: string;
  content: string;
  category: string;
  likesCount: number;
  commentsCount: number;
  createdAt: any;
  updatedAt: any;
  imageUrl?: string;
  authorProfile?: any;
  isLikedByMe?: boolean;
  myReaction?: string | null;
  viewsCount: number;
  isSavedByMe?: boolean;
}

export default function Home() {
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'following'>('all');
  const [expandedComments, setExpandedComments] = useState<Set<string>>(new Set());
  const [expandedStories, setExpandedStories] = useState<Set<string>>(new Set());
  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  const [followingIds, setFollowingIds] = useState<Set<string>>(new Set());
  const [recommendedCreators, setRecommendedCreators] = useState<any[]>([]);
  const [loadingRecommendations, setLoadingRecommendations] = useState(false);
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const [suggestedStories, setSuggestedStories] = useState<Story[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [suggestionsExplanation, setSuggestionsExplanation] = useState<string | null>(null);

  const fetchSuggestedStories = async (currentStoriesList: Story[]) => {
    if (!currentUser || currentStoriesList.length === 0) return;
    setLoadingSuggestions(true);
    try {
      const likedAndSaved = currentStoriesList.filter(s => s.isLikedByMe || s.isSavedByMe).map(s => ({
        id: s.id,
        title: s.title,
        category: s.category
      }));

      const availableStories = currentStoriesList.filter(s => !s.isLikedByMe && !s.isSavedByMe).map(s => ({
        id: s.id,
        title: s.title,
        category: s.category
      }));

      const response = await fetch('/api/suggested-stories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ likedAndSaved, availableStories })
      });

      if (!response.ok) {
        throw new Error("Failed to fetch suggestions from backend");
      }

      const data = await response.json();
      if (data && Array.isArray(data.recommendedIds)) {
        const recommendedList = data.recommendedIds
          .map((id: string) => currentStoriesList.find(s => s.id === id))
          .filter(Boolean) as Story[];
        setSuggestedStories(recommendedList);
        setSuggestionsExplanation(data.explanation || null);
      }
    } catch (err) {
      console.error("Error loaded dynamic feed recommendations:", err);
    } finally {
      setLoadingSuggestions(false);
    }
  };

  useEffect(() => {
    if (stories.length > 0 && suggestedStories.length === 0 && currentUser && !loading) {
      fetchSuggestedStories(stories);
    }
  }, [stories, currentUser, loading]);

  const [myProfile, setMyProfile] = useState<any>(null);

  useEffect(() => {
    if (currentUser) {
      fetchRecommendedCreators();
      // Fetch user profile to get up-to-date photo and name
      const fetchMyProfile = async () => {
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists()) {
            setMyProfile(userDoc.data());
          } else {
            setMyProfile({
              displayName: currentUser.displayName || 'Wordsmith',
              email: currentUser.email || '',
              photoURL: currentUser.photoURL || '',
              bio: ''
            });
          }
        } catch (error: any) {
          console.warn("Could not fetch user profile (possibly offline):", error);
          // Set a fallback user profile so the app handles offline states gracefully
          setMyProfile({
            displayName: currentUser.displayName || 'Wordsmith',
            email: currentUser.email || '',
            photoURL: currentUser.photoURL || '',
            bio: 'Offline Reader'
          });
        }
      };
      fetchMyProfile();
    }
  }, [currentUser, followingIds]);

  const fetchRecommendedCreators = async () => {
    if (!currentUser) return;
    setLoadingRecommendations(true);
    try {
      const q = query(collection(db, 'users'), limit(15));
      const snap = await getDocs(q);
      const creators = snap.docs
        .map(d => ({ uid: d.id, ...d.data() }))
        .filter(u => u.uid !== currentUser.uid && !followingIds.has(u.uid));
      setRecommendedCreators(creators.slice(0, 3));
    } catch (err) {
      console.error("Error fetching recommended creators:", err);
    } finally {
      setLoadingRecommendations(false);
    }
  };

  const followCreator = async (creatorId: string, creatorName: string) => {
    if (!currentUser) return;
    
    // Optimistic state update
    setFollowingIds(prev => {
      const next = new Set(prev);
      next.add(creatorId);
      return next;
    });

    try {
      const followerRef = doc(db, `users/${creatorId}/followers`, currentUser.uid);
      const followingRef = doc(db, `users/${currentUser.uid}/following`, creatorId);
      const followedUserRef = doc(db, 'users', creatorId);
      const currentUserRef = doc(db, 'users', currentUser.uid);

      const batch = writeBatch(db);
      const followData = {
        followerId: currentUser.uid,
        followedId: creatorId,
        createdAt: serverTimestamp()
      };
      
      batch.set(followerRef, followData);
      batch.set(followingRef, followData);
      batch.update(followedUserRef, { followersCount: increment(1) });
      batch.update(currentUserRef, { followingCount: increment(1) });
      
      await batch.commit();

      try {
        await createNotification(
          creatorId,
          currentUser.uid,
          'follow',
          `${currentUser.displayName} followed you!`,
          `/profile/${currentUser.uid}`
        );
      } catch (notifErr) {
        console.warn("Could not create notification:", notifErr);
      }
    } catch (error) {
      console.error("Error following creator:", error);
      // Revert optimism
      setFollowingIds(prev => {
        const next = new Set(prev);
        next.delete(creatorId);
        return next;
      });
    }
  };

  const toggleComments = (storyId: string) => {
    const next = new Set(expandedComments);
    if (next.has(storyId)) next.delete(storyId);
    else next.add(storyId);
    setExpandedComments(next);
  };

  const toggleStoryExpand = (storyId: string) => {
    const next = new Set(expandedStories);
    if (next.has(storyId)) next.delete(storyId);
    else next.add(storyId);
    setExpandedStories(next);
  };

  const handleCommentAdded = (storyId: string) => {
    setStories(current => current.map(s => 
      s.id === storyId ? { ...s, commentsCount: (s.commentsCount || 0) + 1 } : s
    ));
  };

  // Fetch followed user ID list for O(1) relationship affinity matching
  useEffect(() => {
    if (!currentUser) {
      setFollowingIds(new Set());
      return;
    }
    const loadFollowingList = async () => {
      try {
        const followingSnap = await getDocs(collection(db, 'users', currentUser.uid, 'following'));
        const ids = new Set(followingSnap.docs.map(doc => doc.id));
        setFollowingIds(ids);
      } catch (err) {
        console.error("Error loaded following ids for feed rank:", err);
      }
    };
    loadFollowingList();
  }, [currentUser]);

  useEffect(() => {
    if (activeTab === 'all') {
      fetchStories();
    } else {
      fetchFollowingStories();
    }
  }, [currentUser, activeTab, followingIds]); 

  const fetchStories = async () => {
    setLoading(true);
    try {
      // Fetch larger set of stories (50 instead of 20) to rank dynamically
      const q = query(collection(db, 'stories'), orderBy('createdAt', 'desc'), limit(50));
      const snapshot = await getDocs(q);
      await processStories(snapshot.docs);
    } catch (error) {
      console.error("Error fetching stories:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchFollowingStories = async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const followingSnap = await getDocs(collection(db, 'users', currentUser.uid, 'following'));
      const followingIdsList = followingSnap.docs.map(doc => doc.id);
      
      if (followingIdsList.length === 0) {
        setStories([]);
        setLoading(false);
        return;
      }

      // Limit to 30 for Firestore 'in' query
      const chunkedIds = followingIdsList.slice(0, 30);
      const q = query(
        collection(db, 'stories'), 
        where('authorId', 'in', chunkedIds),
        orderBy('createdAt', 'desc'),
        limit(40)
      );
      const snapshot = await getDocs(q);
      await processStories(snapshot.docs);
    } catch (error) {
      console.error("Error fetching following stories:", error);
    } finally {
      setLoading(false);
    }
  };

  const processStories = async (docs: any[]) => {
    const storiesData: Story[] = [];
    for (const document of docs) {
      const data = document.data() as Omit<Story, 'id'>;
      let authorProfile = null;
      let isLikedByMe = false;

      // Fetch author profile
      if (data.authorId) {
        const authorDoc = await getDoc(doc(db, 'users', data.authorId));
        if (authorDoc.exists()) {
          authorProfile = authorDoc.data();
        }
      }
      
      // Check if I liked it
      let myReaction = null;
      if (currentUser) {
        const likeDoc = await getDoc(doc(db, 'stories', document.id, 'likes', currentUser.uid));
        isLikedByMe = likeDoc.exists();
        if (isLikedByMe) {
          myReaction = likeDoc.data()?.type || 'heart';
        }
      }

      // Check if I saved it
      let isSavedByMe = false;
      if (currentUser) {
        const savedDoc = await getDoc(doc(db, `users/${currentUser.uid}/savedStories`, document.id));
        isSavedByMe = savedDoc.exists();
      }

      storiesData.push({
        ...data,
        id: document.id,
        authorProfile,
        isLikedByMe,
        myReaction,
        viewsCount: data.viewsCount || 0,
        isSavedByMe
      });
    }

    // ==== FACEBOOK FEED RECOMMENDATION & EDGE RANKING ALGORITHM ====
    // 1. RELATIONSHIP/AFFINITY: Boost creators standard users are following (+500 points)
    // 2. WEIGHTED ENGAGEMENT: Views count (x1), Likes count (x15), Comments count (x40) representing progressive high intent
    // 3. RECENCY DECAY: Decay divisor Score / (AgeInHours + 2)^1.4 to keep content fresh, vibrant yet viral-capable
    const rankedStories = storiesData.map(story => {
      const views = story.viewsCount || 0;
      const likes = story.likesCount || 0;
      const comments = story.commentsCount || 0;
      
      const engagementWeight = (views * 1) + (likes * 15) + (comments * 40);
      
      const isCreatorFollowed = followingIds.has(story.authorId);
      const affinityBoost = isCreatorFollowed ? 500 : 0;
      
      const storyDate = story.createdAt?.toMillis?.() || story.createdAt?.seconds * 1000 || Date.now();
      const ageInHours = (Date.now() - storyDate) / (1000 * 60 * 60);
      const gravity = 1.4;
      const decayMultiplier = 1 / Math.pow(ageInHours + 2, gravity);
      
      const fbScore = (20 + engagementWeight + affinityBoost) * decayMultiplier;
      
      return {
        ...story,
        fbScore: fbScore
      };
    });

    // Sort descending based on calculated EdgeRank score for Algorithmic tab
    if (activeTab === 'all') {
      rankedStories.sort((a, b) => (b.fbScore || 0) - (a.fbScore || 0));
    }

    setStories(rankedStories);
  };

  const handleShare = async (storyId: string, title: string) => {
    const url = `${window.location.origin}/story/${storyId}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: `Check out this story: ${title}`,
          url: url,
        });
      } catch (err) {
        if (err instanceof Error && (err.name === 'AbortError' || err.message.toLowerCase().includes('cancel'))) {
          return;
        }
        console.error("Error sharing:", err);
      }
    } else {
      navigator.clipboard.writeText(url);
      setCopiedLink(storyId);
      setTimeout(() => setCopiedLink(null), 2000);
    }
  };

  const handleToggleSave = async (storyId: string, currentlySaved: boolean) => {
    if (!currentUser) return;
    
    setStories(current => current.map(s => 
      s.id === storyId ? { ...s, isSavedByMe: !currentlySaved } : s
    ));

    try {
      const savedRef = doc(db, `users/${currentUser.uid}/savedStories`, storyId);
      if (currentlySaved) {
        await deleteDoc(savedRef);
      } else {
        await setDoc(savedRef, {
          storyId: storyId,
          savedAt: serverTimestamp()
        });
      }
    } catch (error) {
      setStories(current => current.map(s => 
        s.id === storyId ? { ...s, isSavedByMe: currentlySaved } : s
      ));
      handleFirestoreError(error, 'save', `users/${currentUser.uid}/savedStories`, currentUser);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mb-4" />
        <p className="text-gray-500 font-medium">Loading your reading feed...</p>
      </div>
    );
  }

  return (
    <div className="max-w-[720px] mx-auto px-4 pb-20">
      
      {/* Elegant Greeting & Writer Draft Block */}
      <div className="bg-white dark:bg-zinc-950 rounded-2xl p-6 border border-gray-100 dark:border-zinc-900 shadow-sm relative overflow-hidden mb-8">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex items-center space-x-4 mb-4">
          {(myProfile?.photoURL || currentUser?.photoURL) ? (
            <img src={myProfile?.photoURL || currentUser?.photoURL} alt="Me" className="w-11 h-11 rounded-full object-cover ring-2 ring-indigo-500/10" />
          ) : (
            <div className="w-11 h-11 rounded-full bg-indigo-50 dark:bg-zinc-900 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold">
              <User className="w-5 h-5" />
            </div>
          )}
          <div>
            <h2 className="text-base font-bold tracking-tight text-gray-900 dark:text-white">
              Welcome, {(myProfile?.displayName || currentUser?.displayName)?.split(' ')[0] || 'Storyteller'}!
            </h2>
            <p className="text-xs text-gray-500 dark:text-zinc-500 font-medium">
              Every day is another blank page. What are you sharing today?
            </p>
          </div>
        </div>

        <div 
          onClick={() => navigate('/add')}
          className="flex items-center justify-between bg-gray-50 dark:bg-zinc-900/50 hover:bg-gray-100/80 dark:hover:bg-zinc-900 rounded-xl px-5 py-3.5 cursor-pointer transition-all duration-200 group border border-gray-100/80 dark:border-zinc-900"
        >
          <span className="text-[14px] font-medium text-gray-400 dark:text-zinc-500 group-hover:text-gray-600 dark:group-hover:text-zinc-400">
            Write a new story or draft...
          </span>
          <div className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-400">
            <span className="text-xs font-bold uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity duration-200">New Story</span>
            <div className="p-1.5 bg-indigo-50 dark:bg-indigo-900/40 rounded-lg group-hover:bg-indigo-600 group-hover:text-white transition-all duration-200">
              <Plus className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* 24-Hour Stories Bar */}
      <StoriesSection myProfile={myProfile} />

      {/* Suggested Stories Section (AI Recommendations) */}
      {currentUser && (
        <div className="bg-indigo-50/15 dark:bg-zinc-950/40 rounded-[2rem] p-6 border border-indigo-100/50 dark:border-zinc-900 shadow-sm relative overflow-hidden mt-2 mb-8 font-sans">
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-xl pointer-events-none" />
          
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-indigo-500 animate-pulse" />
              <h3 className="font-extrabold text-sm text-gray-950 dark:text-white tracking-tight">
                Suggested Stories
              </h3>
              <span className="text-[9px] uppercase font-black px-1.5 py-0.5 bg-indigo-50 text-indigo-600 dark:bg-indigo-900/40 dark:text-indigo-400 rounded-md tracking-wider">
                Gemini AI
              </span>
            </div>
            
            <button
              onClick={() => fetchSuggestedStories(stories)}
              disabled={loadingSuggestions || stories.length === 0}
              className="text-xs font-black uppercase tracking-wider text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-350 flex items-center space-x-1.5 disabled:opacity-50 cursor-pointer transition"
            >
              <Clock className={`w-3.5 h-3.5 ${loadingSuggestions ? 'animate-spin' : ''}`} />
              <span>{loadingSuggestions ? 'Refining...' : 'Recalculate'}</span>
            </button>
          </div>

          {loadingSuggestions ? (
            <div className="flex space-x-3 overflow-x-auto pb-2 scrollbar-none">
              {[1, 2, 3].map((n) => (
                <div key={n} className="flex-shrink-0 w-[240px] h-[140px] bg-gray-50/50 dark:bg-zinc-900/40 rounded-2xl p-4 border border-dashed border-gray-100 dark:border-zinc-850 animate-pulse flex flex-col justify-between">
                  <div>
                    <div className="w-12 h-3 bg-gray-200 dark:bg-zinc-800 rounded mb-2" />
                    <div className="w-full h-4 bg-gray-200 dark:bg-zinc-800 rounded mb-1.5" />
                    <div className="w-3/4 h-3 bg-gray-200 dark:bg-zinc-800 rounded" />
                  </div>
                  <div className="w-1/2 h-2 bg-gray-200 dark:bg-zinc-800 rounded" />
                </div>
              ))}
            </div>
          ) : suggestedStories.length > 0 ? (
            <div className="space-y-3">
              {suggestionsExplanation && (
                <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-450 italic mb-2 leading-relaxed bg-indigo-50/55 dark:bg-indigo-900/10 px-3.5 py-2.5 rounded-2xl border border-indigo-100/40 dark:border-indigo-900/20">
                  ✨ "{suggestionsExplanation}"
                </p>
              )}
              
              <div className="flex space-x-3 overflow-x-auto pb-2 scrollbar-none snap-x snap-mandatory">
                {suggestedStories.map((story) => {
                  const readingTime = calculateReadingTime(story.content);
                  return (
                    <Link 
                      key={story.id}
                      to={`/story/${story.id}`}
                      className="flex-shrink-0 w-[240px] snap-start bg-white dark:bg-zinc-900/60 p-4 rounded-2xl border border-gray-100/80 dark:border-zinc-900 hover:border-indigo-400 dark:hover:border-indigo-600 transition-all duration-250 flex flex-col justify-between shadow-sm group"
                    >
                      <div>
                        <span className="text-[9px] uppercase font-black tracking-wider text-indigo-500/80 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded-md">
                          {story.category}
                        </span>
                        <h4 className="font-extrabold text-xs text-gray-950 dark:text-white mt-2 line-clamp-2 leading-relaxed group-hover:text-indigo-500 transition">
                          {story.title}
                        </h4>
                        <p className="text-[10px] text-zinc-400 dark:text-zinc-500 line-clamp-2 mt-1 leading-normal">
                          {story.summary || story.content.replace(/[#*`_\[\]]/g, '').trim()}
                        </p>
                      </div>
                      
                      <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-gray-50 dark:border-zinc-900/60 text-[9px] text-zinc-400 font-bold">
                        <span className="truncate max-w-[100px]">{story.authorProfile?.displayName || 'Creator'}</span>
                        <span>• {readingTime} min</span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="p-5.5 bg-gray-50/50 dark:bg-zinc-900/20 rounded-2xl text-center border border-dashed border-gray-200/60 dark:border-zinc-900">
              <p className="text-xs font-black text-gray-500 dark:text-zinc-400">
                Subscribing or liking stories trains your adaptive feed.
              </p>
              <p className="text-[10px] text-zinc-400 dark:text-zinc-500 font-semibold mt-1 max-w-sm mx-auto leading-relaxed">
                As soon as you interact with the chronicles on the platform, your custom Gemini AI picks will generate automatically here!
              </p>
            </div>
          )}
        </div>
      )}

      {/* Recommended Topics / Categories Bar */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-xs uppercase tracking-widest text-zinc-400 dark:text-zinc-500">
          Explore Categories
        </h3>
        <Link to="/search" className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline">
          All Topics
        </Link>
      </div>
      <div className="flex space-x-2 overflow-x-auto pb-4 scrollbar-hide py-1 border-b border-gray-100 dark:border-zinc-900">
        {STORY_CATEGORIES.map((topic) => (
          <button 
            key={topic}
            onClick={() => navigate(`/search?category=${topic.toLowerCase()}`)}
            className="flex-shrink-0 px-4 py-1.5 bg-gray-50 hover:bg-gray-100 dark:bg-zinc-900/80 dark:hover:bg-zinc-900 text-gray-700 dark:text-zinc-300 text-xs font-semibold rounded-full transition-all border border-gray-100 dark:border-zinc-900 capitalize"
          >
            {topic}
          </button>
        ))}
      </div>

      {/* Underline Tabs */}
      <div className="flex space-x-6 border-b border-gray-100 dark:border-zinc-900 mt-2 mb-6">
        <button 
          onClick={() => setActiveTab('all')}
          className={`pb-3 text-sm font-bold tracking-tight transition-all relative ${activeTab === 'all' ? 'text-gray-900 dark:text-white font-extrabold' : 'text-zinc-400 hover:text-zinc-600 dark:text-zinc-500 dark:hover:text-zinc-300'}`}
        >
          For You
          {activeTab === 'all' && (
            <motion.div layoutId="homeTabUnderline" className="absolute bottom-0 left-0 right-0 h-0.5 bg-gray-900 dark:bg-white" />
          )}
        </button>
        <button 
          onClick={() => setActiveTab('following')}
          className={`pb-3 text-sm font-bold tracking-tight transition-all relative ${activeTab === 'following' ? 'text-gray-900 dark:text-white font-extrabold' : 'text-zinc-400 hover:text-zinc-600 dark:text-zinc-500 dark:hover:text-zinc-300'}`}
        >
          Following
          {activeTab === 'following' && (
            <motion.div layoutId="homeTabUnderline" className="absolute bottom-0 left-0 right-0 h-0.5 bg-gray-900 dark:bg-white" />
          )}
        </button>
      </div>

      {/* Main Feed List */}
      {stories.length === 0 ? (
        activeTab === 'following' ? (
          <div className="space-y-6">
            <div className="text-center py-12 px-6 bg-white dark:bg-zinc-950 rounded-[2rem] border border-gray-100 dark:border-zinc-900 shadow-sm">
              <Sparkles className="w-10 h-10 text-indigo-500 mx-auto mb-4 animate-pulse" />
              <h3 className="text-lg font-black text-gray-950 dark:text-white tracking-tight">Your Subscriber Feed is waiting</h3>
              <p className="mt-2 text-xs text-gray-400 max-w-sm mx-auto leading-relaxed">
                Follow writers and creators to start filling your personal chronological feed with premium life stories and chronicles.
              </p>
            </div>

            {recommendedCreators.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-zinc-400 dark:text-zinc-500">Featured Creators</span>
                </div>
                
                <div className="grid grid-cols-1 gap-3">
                  {recommendedCreators.map((creator) => (
                    <div 
                      key={creator.uid} 
                      className="bg-white dark:bg-zinc-950 rounded-2xl p-4 border border-gray-100 dark:border-zinc-900 flex items-center justify-between gap-4"
                    >
                      <Link to={`/profile/${creator.uid}`} className="flex items-center space-x-3.5 min-w-0 flex-1">
                        {creator.photoURL ? (
                          <img src={creator.photoURL} alt={creator.displayName} className="w-11 h-11 rounded-full object-cover ring-2 ring-gray-100 dark:ring-zinc-900" />
                        ) : (
                          <div className="w-11 h-11 rounded-full bg-indigo-50 dark:bg-zinc-900 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-bold shrink-0">
                            <User className="w-5 h-5" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <h4 className="font-extrabold text-sm text-gray-950 dark:text-white truncate hover:text-indigo-500 transition">{creator.displayName}</h4>
                          <p className="text-[11px] text-gray-400 dark:text-zinc-500 truncate mt-0.5">{creator.bio || 'Co-creator sharing premium life chronicles.'}</p>
                          <span className="text-[10px] font-bold text-indigo-500/80 dark:text-indigo-400/80 mt-block">{(creator.followersCount || 0).toLocaleString()} subscribers</span>
                        </div>
                      </Link>

                      <motion.button
                        onClick={(e) => {
                          e.preventDefault();
                          followCreator(creator.uid, creator.displayName);
                        }}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        transition={{ type: 'spring', stiffness: 500, damping: 15 }}
                        className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-md shadow-indigo-500/10 shrink-0 cursor-pointer"
                      >
                        Follow
                      </motion.button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-20 bg-white dark:bg-zinc-950 rounded-[2rem] border border-gray-100 dark:border-zinc-900 shadow-sm">
            <BookOpen className="w-12 h-12 text-gray-300 dark:text-zinc-700 mx-auto mb-4" />
            <h3 className="text-base font-semibold text-gray-900 dark:text-white">No stories found</h3>
            <p className="mt-1 text-xs text-gray-500">Be the first to publish a new story!</p>
            <button 
              onClick={() => navigate('/add')}
              className="mt-4 px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-lg hover:bg-indigo-700 transition"
            >
              Create New Story
            </button>
          </div>
        )
      ) : (
        <div className="space-y-4">
          {stories.map((story, index) => {
            const readingTime = calculateReadingTime(story.content);
            const rawViews = story.viewsCount || 0;
            const viewsFormatted = rawViews >= 1000 
              ? (rawViews / 1000).toFixed(1).replace('.0', '') + 'k' 
              : rawViews;

            // Algorithmic indicators
            const isCreatorFollowed = followingIds.has(story.authorId);
            const isHighlyDiscussed = (story.commentsCount || 0) >= 3;
            const isPopular = (story.likesCount || 0) >= 5;
            const isFresh = story.createdAt ? (Date.now() - (story.createdAt.toMillis?.() || story.createdAt.seconds * 1000)) < 3 * 60 * 60 * 1000 : false;

            return (
              <motion.div
                key={story.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: Math.min(index, 10) * 0.05 }}
                className="bg-white dark:bg-zinc-950 rounded-[24px] border border-gray-100 dark:border-zinc-900 shadow-sm hover:shadow-md hover:scale-[1.005] transition-all duration-200 block"
                id={`story-card-${story.id}`}
              >
                <Link 
                  to={`/story/${story.id}`}
                  className="block p-6 pb-3"
                >
                <div className="flex items-center space-x-5">
                  {/* Left Cover Image */}
                  <div className="w-[100px] h-[134px] flex-shrink-0 bg-zinc-50 dark:bg-zinc-900 rounded-[18px] overflow-hidden border border-gray-100 dark:border-zinc-800 shadow-sm relative group">
                    {story.imageUrl ? (
                      <img 
                        src={story.imageUrl} 
                        alt={story.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-gradient-to-br from-indigo-50 to-indigo-100/50 dark:from-zinc-900 dark:to-zinc-800">
                        <BookOpen className="w-6 h-6 text-indigo-500 mb-1 animate-pulse" />
                        <span className="text-[10px] font-bold text-indigo-600/70 dark:text-indigo-400 capitalize truncate w-full">{story.category}</span>
                      </div>
                    )}
                  </div>

                  {/* Right Description metadata */}
                  <div className="flex-1 min-w-0 flex flex-col justify-center">
                    {/* FB Recommendation engine badges */}
                    <div className="flex flex-wrap gap-1 mb-1.5">
                      {isCreatorFollowed && (
                        <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 bg-indigo-500/10 text-indigo-600 dark:text-indigo-450 rounded-md">
                          Following
                        </span>
                      )}
                      {isHighlyDiscussed && (
                        <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-md">
                          Discussed 💬
                        </span>
                      )}
                      {isPopular && (
                        <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 bg-pink-500/10 text-pink-500 dark:text-pink-400 rounded-md">
                          Popular ❤️
                        </span>
                      )}
                      {isFresh && (
                        <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-md">
                          Fresh ⚡
                        </span>
                      )}
                      {activeTab === 'all' && story.fbScore && story.fbScore > 35 && (
                        <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 bg-violet-600/10 text-violet-600 dark:text-violet-400 rounded-md">
                          Top Match ✨
                        </span>
                      )}
                    </div>

                    <div className="flex items-center space-x-2 mb-2 w-full pr-8">
                      {story.authorProfile?.photoURL ? (
                        <img src={story.authorProfile.photoURL} alt={story.authorProfile.displayName || 'Anonymous'} className="w-6 h-6 rounded-full object-cover border border-gray-200 dark:border-zinc-800" />
                      ) : (
                        <div className="w-6 h-6 text-[10px] rounded-full bg-slate-100 text-slate-500 flex items-center justify-center font-bold">
                          {(story.authorProfile?.displayName || 'A').substring(0,1)}
                        </div>
                      )}
                      <span className="text-xs font-bold text-gray-900 dark:text-white truncate">
                        {story.authorProfile?.displayName || 'Anonymous'}
                      </span>
                      <span className="text-gray-400 dark:text-zinc-600">·</span>
                      <span className="text-[11px] font-semibold text-gray-500 truncate min-w-0">
                        {story.createdAt?.toDate ? formatDistanceToNow(story.createdAt.toDate(), { addSuffix: true }) : 'Just now'}
                      </span>
                    </div>

                    <h2 className="text-[18px] sm:text-[20px] font-extrabold text-gray-950 dark:text-white leading-snug line-clamp-1 sm:line-clamp-2 tracking-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors mb-0.5">
                      {story.title}
                    </h2>
                    <p className="text-[13px] text-gray-500 dark:text-zinc-400 line-clamp-2 mb-3 leading-relaxed">
                      {story.summary || story.content.replace(/[#*`_\[\]]/g, '').trim()}
                    </p>
                    <div className="flex items-center text-[12px] text-gray-500 dark:text-zinc-600 space-x-2 font-bold tracking-tight">
                      <span>{viewsFormatted} Views</span>
                      <span>•</span>
                      <span>{readingTime} min</span>
                      <span>•</span>
                      <span className="capitalize text-indigo-500/90 dark:text-indigo-400/90">{story.category}</span>
                    </div>
                  </div>
                </div>
                </Link>
                
                <div className="px-6 pb-4 flex items-center justify-between border-t border-gray-50 dark:border-zinc-900/50 pt-3">
                  <div className="w-32">
                    <ReactionButton
                      storyId={story.id}
                      storyTitle={story.title}
                      authorId={story.authorId}
                      initialReaction={story.myReaction || null}
                      initialLikesCount={story.likesCount || 0}
                      onReactionUpdate={(newReaction, newCount) => {
                        setStories((current: any) => current.map((s: any) => 
                          s.id === story.id ? { ...s, myReaction: newReaction, isLikedByMe: !!newReaction, likesCount: newCount } : s
                        ));
                      }}
                      isFeedMode={true}
                    />
                  </div>
                  <div className="flex items-center space-x-3">
                    <button 
                      onClick={() => navigate(`/story/${story.id}`)}
                      className="flex items-center space-x-1.5 text-sm font-medium text-gray-500 dark:text-gray-400 hover:text-indigo-500 dark:hover:text-indigo-400 transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>{story.commentsCount || 0}</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
