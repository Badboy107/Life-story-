import React, { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { BookOpen, AlertCircle, Loader2, ArrowRight, ShieldCheck, Mail, Lock, User as UserIcon } from 'lucide-react';

export default function Login() {
  const { currentUser, loginWithGoogle, loginWithEmail, signupWithEmail } = useAuth();
  const navigate = useNavigate();

  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);

  if (currentUser) {
    return <Navigate to="/" replace />;
  }

  const handleGoogleLogin = async () => {
    setErrorMsg(null);
    setAuthLoading(true);
    try {
      await loginWithGoogle();
      navigate('/');
    } catch (error: any) {
      console.error('Failed to log in with Google', error);
      if (
        error.code === 'auth/unauthorized-domain' || 
        (error.message && error.message.toLowerCase().includes('unauthorized-domain'))
      ) {
        setErrorMsg(`Firebase Unauthorized Domain: Please add "${window.location.hostname}" to your Firebase Console under Authentication -> Settings -> Authorized Domains to allow Google Sign-in on this deployment.`);
      } else {
        setErrorMsg(error.message || 'Failed to authenticate with Google. Please try again.');
      }
    } finally {
      setAuthLoading(false);
    }
  };

  const handleEmailAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!email || !password) {
      setErrorMsg('Please supply both your email address and password.');
      return;
    }

    if (isRegister && !name) {
      setErrorMsg('Please supply your display name to register.');
      return;
    }

    setAuthLoading(true);
    try {
      if (isRegister) {
        await signupWithEmail(email.trim(), password, name.trim());
      } else {
        await loginWithEmail(email.trim(), password);
      }
      navigate('/');
    } catch (err: any) {
      console.error('Email authentication failure:', err);
      // user-friendly messages
      if (err.code === 'auth/operation-not-allowed') {
        setErrorMsg('Email/Password login is not enabled in your Firebase project. To enable it, login to the Firebase Console -> Authentication -> Sign-in method, click "Add new provider" and select "Email/Password".');
      } else if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setErrorMsg('Invalid email or password. If you do not have an account yet on this project, please select the "Create Account" tab above to register first!');
      } else if (err.code === 'auth/email-already-in-use') {
        setErrorMsg('An account already exists with this email address. Please log in instead.');
      } else if (err.code === 'auth/weak-password') {
        setErrorMsg('Password should be at least 6 characters long.');
      } else {
        setErrorMsg(err.message || 'An error occurred during authentication.');
      }
    } finally {
      setAuthLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-black flex flex-col justify-center py-12 sm:px-6 lg:px-8 font-sans">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center text-indigo-600 dark:text-indigo-400">
          <BookOpen className="w-16 h-16" />
        </div>
        <h2 className="mt-6 text-center text-3xl font-black text-gray-900 dark:text-white tracking-tight">
          Life Story Platform
        </h2>
        <p className="mt-2 text-center text-xs text-gray-500 dark:text-gray-400 leading-relaxed font-semibold">
          Share your journey, discover lives, and manage dynamic elements.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="bg-white dark:bg-zinc-950 py-8 px-6 shadow-sm rounded-3xl sm:px-10 border border-gray-150/70 dark:border-zinc-900 space-y-6">
          
          <div className="flex border-b border-gray-100 dark:border-zinc-900 pb-0.5">
            <button
              onClick={() => {
                setIsRegister(false);
                setErrorMsg(null);
              }}
              className={`flex-1 pb-3 text-xs font-black uppercase tracking-wider text-center border-b-2 transition ${
                !isRegister 
                  ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' 
                  : 'border-transparent text-gray-400 hover:text-gray-600'
              }`}
            >
              Log In
            </button>
            <button
              onClick={() => {
                setIsRegister(true);
                setErrorMsg(null);
              }}
              className={`flex-1 pb-3 text-xs font-black uppercase tracking-wider text-center border-b-2 transition ${
                isRegister 
                  ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400' 
                  : 'border-transparent text-gray-400 hover:text-gray-600'
              }`}
            >
              Create Account
            </button>
          </div>

          {errorMsg && (
            <div className="p-3.5 bg-rose-50 text-rose-800 dark:bg-rose-950/20 dark:text-rose-450 rounded-2xl border border-rose-100/40 dark:border-rose-900/40 flex items-start space-x-3 text-left">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-rose-600" />
              <p className="text-xs font-black leading-normal">{errorMsg}</p>
            </div>
          )}

          {/* Core Login/Register Form */}
          <form onSubmit={handleEmailAuthSubmit} className="space-y-4 text-left">
            {isRegister && (
              <div className="space-y-1.5">
                <label className="text-[10px] uppercase font-black text-gray-400 tracking-wider">Your Full Name</label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-3 w-4.5 h-4.5 text-gray-400" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ariyan"
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs font-semibold outline-none focus:ring-2 focus:ring-indigo-500 transition text-gray-900 dark:text-white"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-[10px] uppercase font-black text-gray-400 tracking-wider">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4.5 h-4.5 text-gray-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="msojib724@gmail.com"
                  className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs font-semibold outline-none focus:ring-2 focus:ring-indigo-500 transition text-gray-900 dark:text-white"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] uppercase font-black text-gray-400 tracking-wider">Password Secret</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4.5 h-4.5 text-gray-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs font-semibold outline-none focus:ring-2 focus:ring-indigo-500 transition text-gray-900 dark:text-white"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={authLoading}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-zinc-400 text-white font-black text-xs tracking-wider uppercase rounded-xl transition flex items-center justify-center space-x-2 shadow-md cursor-pointer"
            >
              {authLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <span>{isRegister ? 'Register and Connect' : 'Log In Securely'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <div className="text-center mt-2">
              <button
                type="button"
                onClick={() => {
                  setIsRegister(!isRegister);
                  setErrorMsg(null);
                }}
                className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                {isRegister ? "Already have an account? Log In" : "Don't have an account? Create Account"}
              </button>
            </div>
          </form>

          <div className="relative select-none">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-150 dark:border-zinc-900" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2.5 bg-white dark:bg-zinc-950 text-[10px] font-bold text-gray-400 uppercase tracking-wide">
                Or alternate path
              </span>
            </div>
          </div>

          <button
            onClick={handleGoogleLogin}
            disabled={authLoading}
            className="w-full flex justify-center items-center space-x-2 py-3 px-4 border border-gray-200 dark:border-zinc-850 rounded-xl shadow-none text-xs font-bold text-gray-700 dark:text-zinc-200 hover:bg-gray-50 dark:hover:bg-zinc-900 transition duration-150 cursor-pointer"
          >
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path
                fill="currentColor"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="currentColor"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="currentColor"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22c-.87-2.6-2.87-4.53-5.83-4.53z"
              />
              <path
                fill="currentColor"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Sign in with Google</span>
          </button>

          <p className="text-[10px] text-gray-400 font-medium select-none flex items-center justify-center space-x-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>End-to-End Encrypted Cloud Credentials</span>
          </p>
        </div>
      </div>
    </div>
  );
}
