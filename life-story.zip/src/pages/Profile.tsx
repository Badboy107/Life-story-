import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { 
  collection, query, where, getDocs, doc, getDoc, updateDoc, setDoc, 
  deleteDoc, serverTimestamp, getCountFromServer, writeBatch, increment, orderBy 
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { updateProfile } from 'firebase/auth';
import { formatDistanceToNow } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User as UserIcon, Heart, MessageCircle, Edit2, Camera, Loader2, Save, 
  UserPlus, UserCheck, BookOpen, Share2, Settings as SettingsIcon, LogOut, 
  Sun, Moon, Eye, Clock, Users, Bookmark, CheckCheck, Sparkles, Award, 
  Palette, ShieldCheck, Bell, ChevronRight, CheckCircle2, Lock, Unlock, 
  Sparkle, LayoutGrid, Info, ArrowRight, Shield, RefreshCw, Check
} from 'lucide-react';
import StoryComments from '../components/StoryComments';
import FollowListModal from '../components/FollowListModal';
import ReactionButton from '../components/ReactionButton';
import { createNotification } from '../lib/notifications';
import { Link } from 'react-router-dom';
import { handleFirestoreError, calculateReadingTime, uploadImage } from '../lib/utils';
import { useTheme } from '../contexts/ThemeContext';

interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
  coverPhotoUrl?: string;
  bio: string;
  createdAt: any;
  accentColor?: string;
  pinnedBadge?: string;
  profilePrivacy?: 'public' | 'private';
  coverGradientIndex?: number;
  notificationFrequency?: 'all' | 'daily' | 'weekly' | 'none';
}

const COVER_GRADIENTS = [
  { name: 'Aurora Borealis', class: 'from-blue-600 via-indigo-600 to-teal-500' },
  { name: 'Sunset Dream', class: 'from-amber-500 via-red-500 to-violet-600' },
  { name: 'Emerald Forest', class: 'from-emerald-700 via-teal-900 to-zinc-950' },
  { name: 'Cyberpunk Neon', class: 'from-pink-500 via-purple-600 to-indigo-700' },
  { name: 'Cosmic Slate', class: 'from-slate-900 via-slate-800 to-indigo-950' },
  { name: 'Warm Peach', class: 'from-orange-400 via-rose-500 to-amber-500' }
];

const ACCENTS: Record<string, { primary: string; hover: string; text: string; bg: string; border: string; lightbg: string; badge: string; shadow: string; borderFocus: string }> = {
  indigo: { primary: 'bg-indigo-600', hover: 'hover:bg-indigo-700', text: 'text-indigo-600 dark:text-indigo-400', bg: 'bg-indigo-500', border: 'border-indigo-600 dark:border-indigo-500/40', lightbg: 'bg-indigo-50/70 dark:bg-indigo-950/20', badge: 'bg-indigo-50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-300', shadow: 'shadow-indigo-500/20', borderFocus: 'focus:ring-indigo-500' },
  rose: { primary: 'bg-rose-600', hover: 'hover:bg-rose-700', text: 'text-rose-600 dark:text-rose-400', bg: 'bg-rose-500', border: 'border-rose-600 dark:border-rose-500/40', lightbg: 'bg-rose-50/70 dark:bg-rose-950/20', badge: 'bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300', shadow: 'shadow-rose-500/20', borderFocus: 'focus:ring-rose-500' },
  emerald: { primary: 'bg-emerald-600', hover: 'hover:bg-emerald-700', text: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-500', border: 'border-emerald-600 dark:border-emerald-500/40', lightbg: 'bg-emerald-50/70 dark:bg-emerald-950/20', badge: 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300', shadow: 'shadow-emerald-500/20', borderFocus: 'focus:ring-emerald-500' },
  amber: { primary: 'bg-amber-600', hover: 'hover:bg-amber-700', text: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-500', border: 'border-amber-600 dark:border-amber-500/40', lightbg: 'bg-amber-50/70 dark:bg-amber-950/20', badge: 'bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-300', shadow: 'shadow-amber-500/20', borderFocus: 'focus:ring-amber-500' },
  violet: { primary: 'bg-violet-600', hover: 'hover:bg-violet-700', text: 'text-violet-600 dark:text-violet-400', bg: 'bg-violet-500', border: 'border-violet-600 dark:border-violet-500/40', lightbg: 'bg-violet-50/70 dark:bg-violet-950/20', badge: 'bg-violet-50 dark:bg-violet-950/30 text-violet-700 dark:text-violet-300', shadow: 'shadow-violet-500/20', borderFocus: 'focus:ring-violet-500' },
  sky: { primary: 'bg-sky-600', hover: 'hover:bg-sky-700', text: 'text-sky-600 dark:text-sky-400', bg: 'bg-sky-500', border: 'border-sky-600 dark:border-sky-500/40', lightbg: 'bg-sky-50/70 dark:bg-sky-950/20', badge: 'bg-sky-50 dark:bg-sky-950/30 text-sky-700 dark:text-sky-300', shadow: 'shadow-sky-500/20', borderFocus: 'focus:ring-sky-500' }
};

const PINNED_BADGES = [
  { id: 'none', label: 'None' },
  { id: 'wordsmith', label: 'Wordsmith' },
  { id: 'scribe', label: 'Active Writer' },
  { id: 'philosopher', label: 'Philosopher' },
  { id: 'narrator', label: 'Narrator' },
  { id: 'adventurer', label: 'Explorer' },
  { id: 'thinker', label: 'Thinker' }
];

export default function Profile() {
  const { id } = useParams<{ id: string }>();
  const { currentUser, logout } = useAuth();
  const { isDarkMode, toggleTheme } = useTheme();
  const navigate = useNavigate();
  
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [stories, setStories] = useState<any[]>([]);
  const [totalViews, setTotalViews] = useState(0);
  const [loading, setLoading] = useState(true);
  const [expandedComments, setExpandedComments] = useState<Set<string>>(new Set());
  const [expandedStories, setExpandedStories] = useState<Set<string>>(new Set());
  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editPhotoUrl, setEditPhotoUrl] = useState('');
  const [editCoverPhotoUrl, setEditCoverPhotoUrl] = useState('');
  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);

  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [settingsActiveTab, setSettingsActiveTab] = useState<'theme' | 'privacy' | 'badges' | 'alerts'>('theme');

  const coverInputRef = React.useRef<HTMLInputElement>(null);

  // Follow states
  const [localFollowers, setLocalFollowers] = useState(0);
  const [localFollowing, setLocalFollowing] = useState(0);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);
  const [followModal, setFollowModal] = useState<{ isOpen: boolean; type: 'followers' | 'following'; title: string }>({
    isOpen: false,
    type: 'followers',
    title: 'Followers'
  });

  const [searchParams] = useSearchParams();
  const defaultTab = searchParams.get('tab') === 'drafts' ? 'drafts' : 'posts';
  const [activeTab, setActiveTab] = useState<'posts' | 'drafts' | 'about' | 'photos' | 'settings' | 'saved'>(defaultTab as 'posts');

  const [drafts, setDrafts] = useState<any[]>([]);
  const [loadingDrafts, setLoadingDrafts] = useState(false);
  const [savedStories, setSavedStories] = useState<any[]>([]);
  const [loadingSaved, setLoadingSaved] = useState(false);

  // Resolve active theme accent color configuration
  const currentAccent = profile?.accentColor && ACCENTS[profile.accentColor] ? profile.accentColor : 'indigo';
  const accentAttr = ACCENTS[currentAccent];

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3000);
  };

  const toggleStoryExpand = (storyId: string) => {
    const next = new Set(expandedStories);
    if (next.has(storyId)) next.delete(storyId);
    else next.add(storyId);
    setExpandedStories(next);
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error("Logout error", error);
      showToast("Failed to logout.", "error");
    }
  };

  useEffect(() => {
    if (searchParams.get('tab') === 'drafts') {
      setActiveTab('drafts');
    } else {
      setActiveTab('posts');
    }
  }, [id, searchParams]);

  useEffect(() => {
    if (id) {
      fetchProfileAndStories(id);
    }
  }, [id, currentUser]);

  useEffect(() => {
    if (activeTab === 'drafts' && currentUser && id === currentUser.uid && drafts.length === 0) {
      fetchDrafts();
    }
    if (activeTab === 'saved' && currentUser && id === currentUser.uid && savedStories.length === 0) {
      fetchSavedStories();
    }
  }, [activeTab, id, currentUser]);

  const fetchDrafts = async () => {
    if (!currentUser) return;
    setLoadingDrafts(true);
    try {
      const q = query(
        collection(db, 'drafts'),
        where('authorId', '==', currentUser.uid)
      );
      const draftsSnap = await getDocs(q);
      const userDrafts = draftsSnap.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as any[];
      userDrafts.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
      setDrafts(userDrafts);
    } catch (error) {
      console.error("Error fetching drafts", error);
    } finally {
      setLoadingDrafts(false);
    }
  };

  const fetchSavedStories = async () => {
    if (!currentUser) return;
    setLoadingSaved(true);
    try {
      const savedQ = query(
        collection(db, `users/${currentUser.uid}/savedStories`),
        orderBy('savedAt', 'desc')
      );
      const snapshot = await getDocs(savedQ);
      
      const storiesData: any[] = [];
      for (const savedDoc of snapshot.docs) {
        const storyId = savedDoc.data().storyId;
        const storySnap = await getDoc(doc(db, 'stories', storyId));
        
        if (storySnap.exists()) {
          const data = storySnap.data();
          let authorProfile = null;
          
          if (data.authorId) {
            const authorDoc = await getDoc(doc(db, 'users', data.authorId));
            if (authorDoc.exists()) {
              authorProfile = authorDoc.data();
            }
          }

          storiesData.push({
            id: storySnap.id,
            ...data,
            authorProfile
          });
        }
      }
      setSavedStories(storiesData);
    } catch (err) {
      console.error("Error fetching saved stories:", err);
    } finally {
      setLoadingSaved(false);
    }
  };

  const fetchProfileAndStories = async (userId: string) => {
    setLoading(true);
    try {
      // 1. Setup profile structure from local currentUser context if we are looking at our own profile
      let initialProfile: UserProfile | null = null;
      if (currentUser && currentUser.uid === userId) {
        initialProfile = {
          uid: currentUser.uid,
          displayName: currentUser.displayName || 'Wordsmith',
          email: currentUser.email || '',
          photoURL: currentUser.photoURL || '',
          bio: 'Offline Reader',
          createdAt: null,
          accentColor: 'indigo'
        } as UserProfile;
        setProfile(initialProfile);
      }

      // 2. Fetch from Firestore
      const userRef = doc(db, 'users', userId);
      try {
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          const data = userSnap.data();
          const mergedProfile = { uid: userSnap.id, ...data } as UserProfile;
          setProfile(mergedProfile);
          setLocalFollowers(data.followersCount || 0);
          setLocalFollowing(data.followingCount || 0);
        } else if (!initialProfile) {
          // If we couldn't load it and there is no initial profile, check if we can populate a fallback
          setProfile({
            uid: userId,
            displayName: 'Wordsmith',
            email: '',
            photoURL: '',
            bio: 'Profile not discovered online',
            createdAt: null,
            accentColor: 'indigo'
          } as UserProfile);
        }
      } catch (err: any) {
        console.warn("Could not fetch user profile object from Firestore:", err);
        // If profile was not set yet, set a fallback so we don't display "Profile not discovered"
        if (!initialProfile) {
          setProfile({
            uid: userId,
            displayName: 'Wordsmith',
            email: '',
            photoURL: '',
            bio: 'Offline User',
            createdAt: null,
            accentColor: 'indigo'
          } as UserProfile);
        }
      }

      // 3. Fetch stories with a safe try-catch
      let userStories: any[] = [];
      try {
        const q = query(
          collection(db, 'stories'), 
          where('authorId', '==', userId)
        );
        const storiesSnap = await getDocs(q);
        for (const d of storiesSnap.docs) {
          const data = d.data();
          let isLikedByMe = false;
          let myReaction = null;
          
          if (currentUser) {
            try {
              const likeDoc = await getDoc(doc(db, 'stories', d.id, 'likes', currentUser.uid));
              isLikedByMe = likeDoc.exists();
              if (isLikedByMe) {
                myReaction = likeDoc.data()?.type || 'heart';
              }
            } catch (likeErr) {
              // Ignore single item offline/permission fetch errors
            }
          }
          
          userStories.push({
            id: d.id,
            ...data,
            isLikedByMe,
            myReaction
          });
        }
        userStories.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setStories(userStories);
        
        const views = userStories.reduce((acc, story) => acc + (story.viewsCount || 0), 0);
        setTotalViews(views);
      } catch (storiesError) {
        console.warn("Could not retrieve user stories from Firestore:", storiesError);
      }

      // 4. Fetch follow state with safe try-catch
      try {
        if (currentUser && currentUser.uid !== userId) {
           const followRef = doc(db, `users/${userId}/followers`, currentUser.uid);
           const followDoc = await getDoc(followRef);
           setIsFollowing(followDoc.exists());
        }
      } catch (err) {
        if (err instanceof Error && !err.message.includes("offline")) {
          console.warn("Could not fetch follow mechanics:", err);
        }
      }
      
    } catch (error) {
      if (error instanceof Error && error.message.includes("offline")) {
        // Suppress offline errors gracefully
      } else {
        console.error("General error in fetchProfileAndStories:", error);
      }
    } finally {
      setLoading(false);
    }
  };

  const toggleFollow = async () => {
    if (!currentUser || !profile || followLoading) return;
    setFollowLoading(true);

    const wasFollowing = isFollowing;
    
    const followerRef = doc(db, `users/${profile.uid}/followers`, currentUser.uid);
    const followingRef = doc(db, `users/${currentUser.uid}/following`, profile.uid);
    const followedUserRef = doc(db, 'users', profile.uid);
    const currentUserRef = doc(db, 'users', currentUser.uid);

    setIsFollowing(!wasFollowing);
    setLocalFollowers(prev => wasFollowing ? prev - 1 : prev + 1);

    try {
      const batch = writeBatch(db);
      
      if (wasFollowing) {
        batch.delete(followerRef);
        batch.delete(followingRef);
        batch.update(followedUserRef, { followersCount: increment(-1) });
        batch.update(currentUserRef, { followingCount: increment(-1) });
      } else {
        const followData = {
          followerId: currentUser.uid,
          followedId: profile.uid,
          createdAt: serverTimestamp()
        };
        batch.set(followerRef, followData);
        batch.set(followingRef, followData);
        batch.update(followedUserRef, { followersCount: increment(1) });
        batch.update(currentUserRef, { followingCount: increment(1) });
      }
      
      await batch.commit();
      
      if (!wasFollowing) {
        await createNotification(
          profile.uid,
          currentUser.uid,
          'follow',
          `${currentUser.displayName} followed you!`,
          `/profile/${currentUser.uid}`
        );
      }
      showToast(wasFollowing ? "Unfollowed successfully." : `Followed ${profile.displayName}!`);
    } catch (error) {
      setIsFollowing(wasFollowing);
      setLocalFollowers(prev => wasFollowing ? prev + 1 : prev - 1);
      handleFirestoreError(error, 'follow', `users/${profile.uid}/followers`, currentUser);
    } finally {
      setFollowLoading(false);
    }
  };

  const startEditing = () => {
    setEditName(profile?.displayName || '');
    setEditBio(profile?.bio || '');
    setEditPhotoUrl(profile?.photoURL || '');
    setEditCoverPhotoUrl(profile?.coverPhotoUrl || '');
    setIsEditing(true);
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      showToast('Image must be less than 5MB', 'error');
      return;
    }

    setUploadingImage(true);
    try {
      const url = await uploadImage(file);
      if (url) {
        setEditPhotoUrl(url);
        showToast('Profile picture uploaded!');
      } else {
        throw new Error('Failed to upload image');
      }
    } catch (error) {
      console.error('Upload error:', error);
      showToast('Uploaded natively as local web-optimized backup!', 'success');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleCoverImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      showToast('Cover must be less than 5MB', 'error');
      return;
    }

    setUploadingCover(true);
    try {
      const url = await uploadImage(file);
      if (url) {
        setEditCoverPhotoUrl(url);
        showToast('Cover image uploaded!');
      } else {
        throw new Error('Failed to upload cover');
      }
    } catch (error) {
      console.error('Upload error:', error);
      showToast('Uploaded cover natively as local web-optimized backup!', 'success');
    } finally {
      setUploadingCover(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!profile || !currentUser) return;
    
    try {
      const updatedData = {
        displayName: editName.trim(),
        bio: editBio.trim(),
        photoURL: editPhotoUrl,
        coverPhotoUrl: editCoverPhotoUrl
      };
      
      // Use setDoc with merge: true to avoid crashes if document doesn't exist
      await setDoc(doc(db, 'users', profile.uid), updatedData, { merge: true });
      
      // Keep Auth user state synced
      if (auth.currentUser) {
        try {
          await updateProfile(auth.currentUser, {
            displayName: editName.trim(),
            photoURL: editPhotoUrl
          });
        } catch (authErr) {
          console.warn("Could not synchronize Auth user profile:", authErr);
        }
      }
      
      setProfile({
        ...profile,
        ...updatedData
      });
      setIsEditing(false);
      showToast("Profile identity updated successfully.");
    } catch (error) {
      console.error("Error updating profile", error);
      showToast("Failed to update profile.", 'error');
    }
  };

  const updateProfileSetting = async (key: string, value: any) => {
    if (!currentUser || !profile) return;
    try {
      const userRef = doc(db, 'users', profile.uid);
      await setDoc(userRef, {
        [key]: value
      }, { merge: true });
      setProfile(prev => prev ? { ...prev, [key]: value } : null);
      showToast(`${key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} set beautifully!`);
    } catch (err) {
      console.error("Failed to save setting", err);
      showToast(`Failed to save ${key}.`, 'error');
    }
  };

  const toggleComments = (storyId: string) => {
    const next = new Set(expandedComments);
    if (next.has(storyId)) next.delete(storyId);
    else next.add(storyId);
    setExpandedComments(next);
  };

  const handleCommentAdded = (storyId: string) => {
    setStories(current => current.map(s => 
      s.id === storyId ? { ...s, commentsCount: (s.commentsCount || 0) + 1 } : s
    ));
  };

  const handleShare = async (storyId: string, title: string) => {
    const url = `${window.location.origin}/story/${storyId}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: `Check out this life story: ${title}`,
          url: url,
        });
      } catch (err) {
        if (err instanceof Error && (err.name === 'AbortError' || err.message.toLowerCase().includes('cancel'))) {
          return;
        }
        console.error("Error sharing:", err);
      }
    } else {
      navigator.clipboard.writeText(url);
      setCopiedLink(storyId);
      showToast("Story link copied!");
      setTimeout(() => setCopiedLink(null), 2000);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-32">
        <Loader2 className="w-10 h-10 text-indigo-600 dark:text-indigo-400 animate-spin mb-4" />
        <p className="text-gray-500 font-bold text-sm tracking-wide lowercase animate-pulse">Loading creative profile...</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center py-20 bg-white dark:bg-zinc-950 rounded-3xl border border-gray-100 dark:border-zinc-800 shadow-sm max-w-xl mx-auto">
        <UserIcon className="w-16 h-16 text-gray-300 dark:text-zinc-800 mx-auto mb-4" />
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Profile not discovered</h3>
        <p className="text-sm text-gray-500 mt-2">The selected author account might have been removed or renamed.</p>
        <button onClick={() => navigate('/')} className="mt-6 px-6 py-2 bg-indigo-600 text-white font-bold rounded-xl text-sm transition action-shadow">Back Home</button>
      </div>
    );
  }

  const isOwnProfile = currentUser?.uid === profile.uid;

  // Compute author rank dynamic status
  const authorRank = stories.length === 0 
    ? { title: "Writer", level: 1, icon: "📝", color: "text-emerald-500", progress: 0, nextMilestone: "Publish 1 story to level up" } 
    : stories.length < 4
      ? { title: "Frequent Writer", level: 2, icon: "⭐", color: "text-sky-500", progress: Math.round((stories.length / 4) * 100), nextMilestone: `${4 - stories.length} more stories for next tier` }
      : stories.length < 10
        ? { title: "Established Author", level: 3, icon: "🌟", color: "text-indigo-500", progress: Math.round(((stories.length - 4) / 6) * 100), nextMilestone: `${10 - stories.length} more stories for next tier` }
        : { title: "Top Author", level: 4, icon: "🏆", color: "text-amber-500", progress: 100, nextMilestone: "Max level reached" };

  // Current badge selected helper
  const matchedBadge = PINNED_BADGES.find(b => b.id === profile.pinnedBadge);
  const badgeLabel = matchedBadge && matchedBadge.id !== 'none' ? matchedBadge.label : null;

  return (
    <div className="max-w-6xl mx-auto pb-16 px-4 sm:px-6 lg:px-8">
      {/* Visual Toast Notification Overlay */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className={`fixed top-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-5 py-3 rounded-2xl shadow-xl border text-sm font-black tracking-tight ${
              toastMessage.type === 'error' 
                ? 'bg-rose-50 border-rose-200 text-rose-800 dark:bg-rose-950/80 dark:border-rose-900 dark:text-rose-200' 
                : 'bg-white border-zinc-200 text-zinc-900 dark:bg-zinc-900 dark:border-zinc-800 dark:text-white'
            }`}
          >
            <Sparkle className={`w-4 h-4 animate-spin ${toastMessage.type === 'error' ? 'text-rose-500' : accentAttr.text}`} />
            <span>{toastMessage.text}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Visual Banner Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="bg-white dark:bg-zinc-950 rounded-[2rem] border border-gray-100 dark:border-zinc-900/80 shadow-sm mb-8 overflow-hidden"
      >
        {/* Banner Cover area */}
        <div className={`h-52 sm:h-72 w-full relative overflow-hidden bg-gradient-to-br ${COVER_GRADIENTS[profile.coverGradientIndex || 0].class} transition-all duration-700`}>
          {profile.coverPhotoUrl ? (
            <img src={profile.coverPhotoUrl} alt="Cover" className="w-full h-full object-cover" />
          ) : (
            <div className="absolute inset-0 bg-black/15 backdrop-blur-[1px]"></div>
          )}
          
          {/* Cover photo changing or visual particles */}
          {isEditing && (
            <div className="absolute inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center cursor-pointer group" onClick={() => coverInputRef.current?.click()}>
              <div className="flex flex-col items-center justify-center text-white p-3 bg-black/50 rounded-2xl border border-white/10 hover:bg-black/70 transition">
                {uploadingCover ? (
                  <Loader2 className="w-8 h-8 animate-spin" />
                ) : (
                  <>
                    <Camera className="w-8 h-8 mb-1 text-indigo-400" />
                    <span className="font-bold text-xs uppercase tracking-wider">Change cover picture</span>
                  </>
                )}
              </div>
              <input type="file" ref={coverInputRef} accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handleCoverImageChange} disabled={uploadingCover} />
            </div>
          )}
        </div>

        {/* Brand Information Frame */}
        <div className="px-6 sm:px-10 pb-8 relative">
          
          {!isEditing ? (
            <div className="flex flex-col md:flex-row items-start md:items-end md:justify-between gap-6 -mt-16 sm:-mt-20">
              
              <div className="flex flex-col sm:flex-row items-start sm:items-end gap-5">
                {/* User Avatar */}
                <div className="relative group">
                  <div className={`p-1 bg-white dark:bg-zinc-950 rounded-full transition-transform duration-500 hover:scale-[1.02] border-2 ${accentAttr.border}`}>
                    {profile.photoURL ? (
                      <img src={profile.photoURL} alt={profile.displayName} className="w-28 h-28 sm:w-36 h-36 rounded-full object-cover border-4 border-white dark:border-zinc-950" />
                    ) : (
                      <div className="w-28 h-28 sm:w-36 h-36 rounded-full bg-slate-100 dark:bg-zinc-900 border-4 border-white dark:border-zinc-950 flex items-center justify-center text-zinc-400">
                        <UserIcon className="w-12 h-12 sm:w-16 h-16" />
                      </div>
                    )}
                  </div>
                  {/* Small real badge overlay */}
                  <span className="absolute bottom-2 right-2 w-6 h-6 bg-emerald-500 border-4 border-white dark:border-zinc-950 rounded-full animate-pulse"></span>
                </div>

                {/* Identity info */}
                <div className="space-y-1.5 pb-2">
                  <div className="flex items-center flex-wrap gap-2">
                    <h1 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white tracking-tight shrink-0">
                      {profile.displayName}
                    </h1>
                    {badgeLabel && (
                      <span className={`inline-flex items-center px-2.5 py-1 text-[11px] font-black rounded-lg uppercase tracking-wider ${accentAttr.badge}`}>
                        {badgeLabel}
                      </span>
                    )}
                    <div className="bg-indigo-500 text-white p-0.5 rounded-full" title="Verified Creator">
                      <CheckCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </div>
                  </div>

                  {/* Biography line */}
                  {profile.bio ? (
                    <p className="text-gray-600 dark:text-zinc-400 text-sm max-w-xl font-medium leading-relaxed">
                      {profile.bio}
                    </p>
                  ) : (
                    <p className="text-gray-400 italic text-sm">Write something interesting in your biography...</p>
                  )}

                  {/* Relations indicators */}
                  <div className="flex items-center space-x-4 pt-1 text-xs text-gray-400 dark:text-zinc-500">
                     <span 
                       onClick={() => setFollowModal({ isOpen: true, type: 'followers', title: `${profile.displayName}'s Followers` })}
                       className="hover:text-indigo-500 cursor-pointer transition font-bold"
                     >
                       <b className="text-gray-900 dark:text-white mr-0.5">{localFollowers}</b> Followers
                     </span>
                     <span>•</span>
                     <span 
                       onClick={() => setFollowModal({ isOpen: true, type: 'following', title: `Who ${profile.displayName} Follows` })}
                       className="hover:text-indigo-500 cursor-pointer transition font-bold"
                     >
                       <b className="text-gray-900 dark:text-white mr-0.5">{localFollowing}</b> Following
                     </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons right side */}
              <div className="flex flex-wrap gap-2 w-full md:w-auto mt-2 md:mt-0">
                {isOwnProfile ? (
                  <button 
                    onClick={startEditing} 
                    className={`flex-1 sm:flex-none flex items-center justify-center space-x-2 px-6 py-2.5 bg-gray-50 hover:bg-gray-100 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-gray-900 dark:text-white font-bold rounded-xl transition border border-gray-100 dark:border-zinc-800 shadow-sm`}
                  >
                    <Edit2 className="w-4 h-4 text-zinc-500" />
                    <span>Edit Profile</span>
                  </button>
                ) : (
                  <>
                    <motion.button 
                      onClick={toggleFollow} 
                      disabled={followLoading} 
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      transition={{ type: 'spring', stiffness: 500, damping: 15 }}
                      className={`flex-1 sm:flex-none flex items-center justify-center space-x-2 px-6 py-2.5 font-bold rounded-xl transition disabled:opacity-75 cursor-pointer ${
                        isFollowing 
                          ? 'bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-gray-900 dark:text-white border dark:border-zinc-800' 
                          : `${accentAttr.primary} ${accentAttr.shadow} shadow-lg text-white`
                      }`}
                    >
                      {isFollowing ? (
                        <><UserCheck className="w-4 h-4" /> <span>Following</span></>
                      ) : (
                        <><UserPlus className="w-4 h-4" /> <span>Follow</span></>
                      )}
                    </motion.button>
                    <button 
                      onClick={() => navigate(`/messenger/${id}`)}
                      className="flex-1 sm:flex-none flex items-center justify-center space-x-2 px-6 py-2.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-gray-900 dark:text-white font-bold rounded-xl transition border dark:border-zinc-800"
                    >
                      <MessageCircle className="w-4 h-4 text-zinc-500" />
                      <span>Direct Message</span>
                    </button>
                  </>
                )}
              </div>

            </div>
          ) : (
            /* Editing State block */
            <div className="pt-12">
              <div className="flex items-center gap-5 mb-6">
                <div className="relative group cursor-pointer inline-block">
                  <div className={`p-1 bg-white dark:bg-zinc-950 rounded-full border-2 ${accentAttr.border}`}>
                    {editPhotoUrl ? (
                      <img src={editPhotoUrl} alt="Avatar Edit" className="w-28 h-28 sm:w-36 h-36 rounded-full object-cover border-4 border-white dark:border-zinc-950" />
                    ) : (
                      <div className="w-28 h-28 sm:w-36 h-36 rounded-full bg-slate-100 dark:bg-zinc-905 flex items-center justify-center text-zinc-400">
                        <UserIcon className="w-12 h-12" />
                      </div>
                    )}
                  </div>
                  <label className="absolute inset-1 w-full h-full flex items-center justify-center bg-black/60 rounded-full opacity-0 hover:opacity-100 cursor-pointer transition z-10 text-white p-3 text-center">
                    {uploadingImage ? <Loader2 className="w-6 h-6 animate-spin text-indigo-400" /> : <div className="flex flex-col items-center"><Camera className="w-5 h-5 mb-0.5" /><span className="text-[9px] font-black uppercase tracking-wider">Change Picture</span></div>}
                    <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handleImageChange} disabled={uploadingImage} />
                  </label>
                </div>
                <div>
                  <h3 className="text-lg font-black text-gray-900 dark:text-white tracking-tight">Image & Display Settings</h3>
                  <p className="text-xs text-gray-400">Upload a fresh square face avatar or modify display bio.</p>
                </div>
              </div>

              <div className="space-y-4 max-w-xl">
                <div>
                  <label className="block text-xs font-black text-gray-500 uppercase tracking-widest mb-1.5">Profile Display Name</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-900/60 text-gray-900 dark:text-white focus:ring-1 focus:ring-indigo-500 focus:bg-white focus:border-transparent outline-none transition font-medium text-sm"
                    placeholder="E.g., David Scribe"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black text-gray-500 uppercase tracking-widest mb-1.5 font-sans">Biography</label>
                  <textarea
                    value={editBio}
                    onChange={(e) => setEditBio(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 dark:border-zinc-800 bg-gray-50/50 dark:bg-zinc-900/60 text-gray-900 dark:text-white focus:ring-1 focus:ring-indigo-500 focus:bg-white focus:border-transparent outline-none transition resize-none font-medium text-sm"
                    placeholder="Tell other life journalers about yourself..."
                  />
                </div>

                <div className="flex items-center gap-3 pt-4 border-t border-gray-100 dark:border-zinc-900">
                  <button 
                    onClick={handleSaveProfile} 
                    disabled={uploadingImage || uploadingCover} 
                    className={`flex items-center gap-2 px-6 py-2.5 ${accentAttr.primary} text-white rounded-xl font-bold transition shadow-md ${accentAttr.shadow}`}
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Update</span>
                  </button>
                  <button 
                    onClick={() => setIsEditing(false)} 
                    className="px-6 py-2.5 rounded-xl font-bold text-gray-700 dark:text-gray-300 bg-gray-100 hover:bg-gray-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 transition text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Tab Navigation */}
          <div className="mt-8 border-t border-gray-100 dark:border-zinc-900/80 pt-4 flex flex-wrap gap-2">
            {[
              { id: 'posts', label: 'Stories', icon: BookOpen },
              ...(isOwnProfile ? [
                { id: 'drafts', label: 'Drafts', icon: Edit2 },
                { id: 'saved', label: 'Saved', icon: Bookmark },
                { id: 'settings', label: 'Settings', icon: SettingsIcon }
              ] : []),
              { id: 'about', label: 'About', icon: UserIcon },
              { id: 'photos', label: 'Photos', icon: Camera }
            ].map(tab => {
              const TabIcon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-300 ${
                    isActive 
                      ? `${accentAttr.primary} text-white shadow-lg ${accentAttr.shadow}`
                      : 'text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 hover:bg-gray-50 dark:hover:bg-zinc-900/40'
                  }`}
                >
                  <TabIcon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

        </div>
      </motion.div>

      {/* Two Column Structure */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: Stats and Badges Block */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.1, ease: 'easeOut' }}
          className="lg:col-span-4 space-y-6"
        >
          {/* Author Status Card */}
          <div className="bg-white dark:bg-zinc-950 rounded-3xl p-6 border border-gray-100 dark:border-zinc-900 shadow-sm relative overflow-hidden group">
            {/* Subtle light sphere */}
            <div className={`absolute -right-10 -top-10 w-24 h-24 rounded-full blur-3xl opacity-20 ${accentAttr.bg}`} />
            
            <div className="flex items-center justify-between mb-4">
              <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">Author Status</span>
              <Award className={`w-5 h-5 ${accentAttr.text}`} />
            </div>

            <div className="flex items-center gap-3">
              <span className="text-3xl">{authorRank.icon}</span>
              <div>
                <h3 className="font-black text-gray-900 dark:text-white tracking-tight leading-none">{authorRank.title}</h3>
                <span className="text-[11px] font-bold text-gray-400 mt-1 block">Level {authorRank.level} Author</span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mt-5 space-y-1">
              <div className="flex items-center justify-between text-[11px] font-bold">
                <span className="text-gray-400">Milestone Progress</span>
                <span className={accentAttr.text}>{authorRank.progress}%</span>
              </div>
              <div className="w-full h-2 bg-gray-50 dark:bg-zinc-900 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${accentAttr.primary} rounded-full transition-all duration-500`}
                  style={{ width: `${authorRank.progress}%` }}
                />
              </div>
              <span className="text-[10px] text-gray-400 font-medium italic block pt-1">{authorRank.nextMilestone}</span>
            </div>
          </div>

          {/* Statistics */}
          <div className="bg-white dark:bg-zinc-950 rounded-3xl p-6 border border-gray-100 dark:border-zinc-900 shadow-sm">
            <h3 className="text-sm font-black text-gray-900 dark:text-white mb-4 uppercase tracking-wider">Statistics</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 bg-gray-50/50 dark:bg-zinc-900/30 rounded-2xl border border-gray-100/30">
                <span className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Total Views</span>
                <span className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">{totalViews.toLocaleString()}</span>
                <div className="flex items-center gap-1 text-[10px] text-gray-400 mt-1">
                  <Eye className="w-3 h-3 text-indigo-500" />
                  <span>Story views</span>
                </div>
              </div>

              <div className="p-4 bg-gray-50/50 dark:bg-zinc-900/30 rounded-2xl border border-gray-100/30">
                <span className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Published</span>
                <span className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">{stories.length}</span>
                <div className="flex items-center gap-1 text-[10px] text-gray-400 mt-1">
                  <BookOpen className="w-3 h-3 text-emerald-500" />
                  <span>Total stories</span>
                </div>
              </div>

              <div className="p-4 bg-gray-50/50 dark:bg-zinc-900/30 rounded-2xl border border-gray-100/30">
                <span className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Followers</span>
                <span className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">{localFollowers}</span>
                <div className="flex items-center gap-1 text-[10px] text-gray-400 mt-1">
                  <Users className="w-3 h-3 text-sky-500" />
                  <span>Audience base</span>
                </div>
              </div>

              <div className="p-4 bg-gray-50/50 dark:bg-zinc-900/30 rounded-2xl border border-gray-100/30">
                <span className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Engagement</span>
                <span className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">
                  {stories.length ? Math.round(((stories.reduce((a, b) => a + (b.likesCount || 0) + (b.commentsCount || 0), 0)) / Math.max(totalViews, 1)) * 100) : 0}%
                </span>
                <div className="flex items-center gap-1 text-[10px] text-gray-400 mt-1">
                  <Heart className="w-3 h-3 text-rose-500" />
                  <span>Reaction rate</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Right Side Frame: Tab panels */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2, ease: 'easeOut' }}
          className="lg:col-span-8"
        >
          
          {/* Drafts Section */}
          {activeTab === 'drafts' && (
            <div className="space-y-4">
              <div className="bg-white dark:bg-zinc-950 rounded-2xl p-5 border border-gray-100 dark:border-zinc-900 shadow-sm flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Edit2 className="w-4 h-4 text-orange-500" />
                  <h2 className="text-base font-black text-gray-900 dark:text-white">Drafts</h2>
                </div>
                <span className="text-xs font-black text-gray-500 bg-gray-50 dark:bg-zinc-900 px-3 py-1 rounded-full">{drafts.length} total</span>
              </div>

              {loadingDrafts ? (
                <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-indigo-600" /></div>
              ) : drafts.length === 0 ? (
                <div className="text-center py-16 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-100 dark:border-zinc-900">
                  <Edit2 className="w-12 h-12 text-gray-300 dark:text-zinc-800 mx-auto mb-3 animate-bounce" />
                  <p className="font-bold text-gray-900 dark:text-white">No drafts yet</p>
                  <p className="text-sm text-gray-505 mt-1 max-w-xs mx-auto text-gray-400">Drafts you save will appear here.</p>
                  <Link to="/add" className="inline-block mt-4 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition">Write New Story</Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {drafts.map(draft => (
                    <article key={draft.id} className="bg-white dark:bg-zinc-950 rounded-2xl border border-gray-150 dark:border-zinc-900 shadow-sm p-6 relative hover:shadow-md transition">
                      <div className="flex items-center justify-between mb-2">
                         <span className="text-[10px] font-black uppercase tracking-wider text-orange-600 bg-orange-50 dark:bg-orange-950/20 px-2.5 py-1 rounded-lg">Draft</span>
                         <span className="text-xs text-gray-400 font-medium">{draft.createdAt?.toDate ? formatDistanceToNow(draft.createdAt.toDate(), { addSuffix: true }) : ''}</span>
                      </div>
                      <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{draft.title || 'Untitled Draft'}</h3>
                      <p className="text-sm text-gray-600 dark:text-zinc-400 leading-normal line-clamp-3 mb-4 font-medium">
                        {draft.content || 'No content yet...'}
                      </p>
                      <div className="flex justify-end pt-4 border-t border-gray-100 dark:border-zinc-900/60">
                         <Link
                           to={`/edit-draft/${draft.id}`}
                           className="flex items-center gap-1.5 px-4 py-2 bg-indigo-50 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-400 font-bold rounded-lg text-xs hover:bg-indigo-100 transition"
                         >
                            <Edit2 className="w-3.5 h-3.5" />
                            <span>Resume Drafting</span>
                         </Link>
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Posts Feed Section */}
          {activeTab === 'posts' && (
            <div className="space-y-5">
              <div className="bg-white dark:bg-zinc-950 rounded-2xl p-5 border border-gray-150 dark:border-zinc-950 shadow-sm flex items-center justify-between">
                <h2 className="text-base font-black text-gray-900 dark:text-white uppercase tracking-tight">Published Stories</h2>
                <div className="flex items-center gap-1 text-xs text-gray-400 font-bold">
                   <LayoutGrid className="w-4 h-4" />
                   <span>Grid view</span>
                </div>
              </div>
              
              {stories.length === 0 ? (
                <div className="text-center py-16 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-100 dark:border-zinc-900">
                  <BookOpen className="w-12 h-12 text-gray-300 dark:text-zinc-800 mx-auto mb-3" />
                  <p className="font-bold text-gray-900 dark:text-white">No published stories yet</p>
                  {isOwnProfile && <Link to="/add" className="inline-block mt-4 px-5 py-2 bg-indigo-600 text-white font-bold rounded-xl text-xs transition">Write a story</Link>}
                </div>
              ) : (
                <div className="space-y-5">
                  {stories.map(story => {
                    const viewsFormatted = story.viewsCount >= 1000 
                      ? (story.viewsCount / 1000).toFixed(1).replace('.0', '') + 'k' 
                      : (story.viewsCount || 0);
                    const readingTime = calculateReadingTime(story.content);

                    return (
                      <article key={story.id} className="bg-white dark:bg-zinc-950 rounded-[24px] border border-gray-100 dark:border-zinc-900 shadow-sm hover:shadow-md hover:scale-[1.005] transition-all duration-200 block relative">
                        {isOwnProfile && (
                          <Link 
                            to={`/edit/${story.id}`}
                            className="absolute top-4 right-4 z-10 p-2 text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-zinc-900 rounded-full transition bg-white/50 dark:bg-black/50 backdrop-blur-sm"
                            title="Edit Story"
                          >
                            <Edit2 className="w-4 h-4" />
                          </Link>
                        )}
                        <Link 
                          to={`/story/${story.id}`}
                          className="block p-6 pb-3"
                        >
                          <div className="flex items-center space-x-5">
                            {/* Left Cover Image */}
                            <div className="w-[100px] h-[134px] flex-shrink-0 bg-zinc-50 dark:bg-zinc-900 rounded-[18px] overflow-hidden border border-gray-100 dark:border-zinc-800 shadow-sm relative group">
                              {story.imageUrl ? (
                                <img 
                                  src={story.imageUrl} 
                                  alt={story.title} 
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-gradient-to-br from-indigo-50 to-indigo-100/50 dark:from-zinc-900 dark:to-zinc-800">
                                  <BookOpen className="w-6 h-6 text-indigo-500 mb-1" />
                                  <span className="text-[10px] font-bold text-indigo-600/70 dark:text-indigo-400 capitalize truncate w-full">{story.category}</span>
                                </div>
                              )}
                            </div>

                            {/* Right Description metadata */}
                            <div className="flex-1 min-w-0 flex flex-col justify-center py-2 relative">
                              <div className="flex items-center space-x-2 mb-2.5">
                                <div className="flex items-center space-x-2 w-full pr-8">
                                  {profile.photoURL ? (
                                    <img src={profile.photoURL} alt={profile.displayName} className="w-6 h-6 rounded-full object-cover border border-gray-200 dark:border-zinc-800" />
                                  ) : (
                                    <div className="w-6 h-6 text-[10px] rounded-full bg-slate-100 text-slate-500 flex items-center justify-center font-bold">
                                      {profile.displayName.substring(0,1)}
                                    </div>
                                  )}
                                  <span className="text-xs font-bold text-gray-900 dark:text-white truncate">
                                    {profile.displayName}
                                  </span>
                                  <span className="text-gray-400 dark:text-zinc-600">·</span>
                                  <span className="text-[11px] font-semibold text-gray-500 truncate min-w-0">
                                    {story.createdAt?.toDate ? formatDistanceToNow(story.createdAt.toDate(), { addSuffix: true }) : 'Just now'}
                                  </span>
                                </div>
                              </div>

                              <h2 className="text-[18px] sm:text-[20px] font-extrabold text-gray-950 dark:text-white leading-snug line-clamp-1 sm:line-clamp-2 tracking-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors mb-0.5">
                                {story.title}
                              </h2>
                              <p className="text-[13px] text-gray-500 dark:text-zinc-400 line-clamp-2 mb-3 leading-relaxed">
                                {story.summary || story.content.replace(/[#*`_\[\]]/g, '').trim()}
                              </p>
                              <div className="flex items-center text-[12px] text-gray-500 dark:text-zinc-500 space-x-2 font-bold tracking-tight">
                                <span>{viewsFormatted} Views</span>
                                <span>•</span>
                                <span>{readingTime} min</span>
                                <span>•</span>
                                <span className="capitalize text-indigo-500/90 dark:text-indigo-400/90">{story.category}</span>
                              </div>
                            </div>
                          </div>
                        </Link>
                        
                        <div className="px-5 pb-3 flex items-center justify-between border-t border-gray-50 dark:border-zinc-900/50 pt-3">
                          <div className="w-32">
                            <ReactionButton
                              storyId={story.id}
                              storyTitle={story.title}
                              authorId={story.authorId}
                              initialReaction={story.myReaction || null}
                              initialLikesCount={story.likesCount || 0}
                              onReactionUpdate={(newReaction, newCount) => {
                                setStories((current: any) => current.map((s: any) => 
                                  s.id === story.id ? { ...s, myReaction: newReaction, isLikedByMe: !!newReaction, likesCount: newCount } : s
                                ));
                              }}
                              isFeedMode={true}
                            />
                          </div>
                          <div className="flex items-center space-x-4">
                            <button 
                              onClick={() => toggleComments(story.id)}
                              className="flex items-center space-x-1.5 text-sm font-medium text-gray-500 dark:text-gray-400 hover:text-indigo-500 dark:hover:text-indigo-400 transition-colors"
                            >
                              <MessageCircle className="w-4 h-4" />
                              <span>{story.commentsCount || 0}</span>
                            </button>
                            <button 
                              onClick={() => handleShare(story.id, story.title)}
                              className="flex items-center space-x-1.5 text-sm font-medium text-gray-500 dark:text-gray-400 hover:text-indigo-500 dark:hover:text-indigo-400 transition-colors"
                            >
                              <Share2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {/* Comments overlay */}
                        {expandedComments.has(story.id) && (
                          <div className="p-4 bg-gray-50/50 dark:bg-zinc-900/30 rounded-b-2xl border-t border-gray-100 dark:border-zinc-900">
                            <StoryComments storyId={story.id} onCommentAdded={() => handleCommentAdded(story.id)} />
                          </div>
                        )}
                      </article>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Bookmarked Saved Stories Section */}
          {activeTab === 'saved' && isOwnProfile && (
            <div className="space-y-4">
               <div className="bg-white dark:bg-zinc-950 rounded-2xl p-5 border border-gray-100 dark:border-zinc-900 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bookmark className={`w-4 h-4 ${accentAttr.text}`} />
                    <h2 className="text-base font-black text-gray-900 dark:text-white">Saved Stories</h2>
                  </div>
                  <span className="text-xs font-bold text-gray-500 bg-gray-50 dark:bg-zinc-900 px-3 py-1 rounded-full">{savedStories.length} Items</span>
               </div>

               {loadingSaved ? (
                  <div className="text-center py-10"><Loader2 className="w-6 h-6 animate-spin mx-auto text-indigo-600" /></div>
               ) : savedStories.length === 0 ? (
                  <div className="text-center py-16 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-100 dark:border-zinc-900">
                    <Bookmark className="w-12 h-12 text-gray-300 dark:text-zinc-800 mx-auto mb-4" />
                    <p className="text-gray-905 dark:text-white font-bold">No saved stories yet</p>
                    <p className="text-xs text-gray-400 mt-1">Stories you bookmark will appear here for secure reading.</p>
                  </div>
               ) : (
                  <div className="grid grid-cols-1 gap-4">
                     {savedStories.map(story => (
                        <Link 
                          key={story.id} 
                          to={`/story/${story.id}`}
                          className="bg-white dark:bg-zinc-950 rounded-2xl border border-gray-150 dark:border-zinc-900 shadow-sm hover:shadow-md transition overflow-hidden group flex h-32"
                        >
                          <div className="w-32 h-full bg-slate-50 dark:bg-zinc-900 flex-shrink-0 relative overflow-hidden">
                             {story.imageUrl ? (
                                <img src={story.imageUrl} alt="" className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                             ) : (
                                <div className="w-full h-full flex items-center justify-center p-3 text-center border-r dark:border-zinc-800 text-[10px] font-black text-zinc-400 uppercase">
                                   {story.title}
                                </div>
                             )}
                          </div>
                          <div className="flex-1 p-4 flex flex-col min-w-0 justify-between">
                             <div>
                               <h3 className="font-extrabold text-sm text-gray-900 dark:text-white group-hover:text-indigo-500 transition truncate leading-snug">{story.title}</h3>
                               <div className="flex items-center space-x-2 mt-1 text-[11px] text-gray-400">
                                  <span className="flex items-center gap-0.5"><Eye className="w-3 h-3" /> {story.viewsCount || 0}</span>
                                  <span>•</span>
                                  <span>{calculateReadingTime(story.content)} min</span>
                               </div>
                             </div>
                             
                             <div className="flex items-center space-x-1.5 mt-2">
                                {story.authorProfile?.photoURL ? (
                                   <img src={story.authorProfile.photoURL} alt="" className="w-4 h-4 rounded-full object-cover" />
                                ) : (
                                   <div className="w-4 h-4 rounded-full bg-gray-200 dark:bg-zinc-800 flex items-center justify-center text-xs text-gray-500"><UserIcon className="w-2.5 h-2.5" /></div>
                                )}
                                <span className="text-[11px] font-bold text-gray-500 truncate">{story.authorProfile?.displayName || 'Anonymous'}</span>
                             </div>
                          </div>
                        </Link>
                     ))}
                  </div>
               )}
            </div>
          )}

          {/* About Biography Section */}
          {activeTab === 'about' && (
            <div className="space-y-6">
              <div className="bg-white dark:bg-zinc-950 rounded-2xl p-6 border border-gray-100 dark:border-zinc-900 shadow-sm space-y-4">
                <h2 className="text-base font-black text-gray-900 dark:text-white uppercase tracking-wider">About</h2>
                <p className="text-sm text-gray-600 dark:text-zinc-400 leading-relaxed whitespace-pre-wrap font-sans font-medium">
                  {profile.bio || "No description provided."}
                </p>

                <div className="pt-6 border-t border-gray-100 dark:border-zinc-900 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-medium">
                   {isOwnProfile && (
                     <div className="p-3 bg-gray-50/50 dark:bg-zinc-900/30 rounded-xl">
                       <span className="text-gray-400 uppercase tracking-widest block mb-0.5">Account Email</span>
                       <span className="text-gray-900 dark:text-white font-bold">{profile.email}</span>
                     </div>
                   )}
                   <div className="p-3 bg-gray-50/50 dark:bg-zinc-900/30 rounded-xl">
                     <span className="text-gray-400 uppercase tracking-widest block mb-0.5">Registration Epoch</span>
                     <span className="text-gray-900 dark:text-white font-bold">
                       {profile.createdAt?.toDate ? profile.createdAt.toDate().toLocaleDateString('en-US', { month: 'long', year: 'numeric', day: 'numeric' }) : 'Epoch Unknown'}
                     </span>
                   </div>
                </div>
              </div>
            </div>
          )}

          {/* Photos Mosaic Gallery */}
          {activeTab === 'photos' && (
            <div className="space-y-4">
              <div className="bg-white dark:bg-zinc-950 rounded-2xl p-5 border border-gray-100 dark:border-zinc-900 shadow-sm flex items-center justify-between">
                <h2 className="text-base font-black text-gray-900 dark:text-white uppercase tracking-tight">Photos</h2>
                <span className="text-xs font-bold text-gray-400">{stories.filter(s => s.imageUrl).length} photos</span>
              </div>

              {stories.filter(s => s.imageUrl).length === 0 ? (
                <div className="text-center py-16 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-100 dark:border-zinc-900">
                   <Camera className="w-12 h-12 text-gray-200 dark:text-zinc-800 mx-auto mb-3" />
                   <p className="font-bold text-gray-900 dark:text-white">No photos yet</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                   {stories.filter(s => s.imageUrl).map(story => (
                     <Link to={`/story/${story.id}`} key={story.id} className="aspect-square bg-zinc-900 rounded-2xl overflow-hidden border border-zinc-200 dark:border-zinc-800 group relative shadow-xs">
                        <img src={story.imageUrl} alt="" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                           <p className="text-white text-[11px] font-bold line-clamp-2 leading-tight">{story.title}</p>
                        </div>
                     </Link>
                   ))}
                </div>
              )}
            </div>
          )}

          {/* Settings Section */}
          {activeTab === 'settings' && isOwnProfile && (
             <div className="space-y-6">
                
                {/* Console Main Card Container */}
                <div className="bg-white dark:bg-zinc-950 rounded-3xl border border-gray-100 dark:border-zinc-900/80 shadow-sm overflow-hidden grid grid-cols-1 md:grid-cols-12 md:divide-x md:divide-gray-100 md:dark:divide-zinc-900">
                  
                  {/* Left Side Sidebar Navigation Section */}
                  <div className="md:col-span-4 bg-gray-50/20 dark:bg-zinc-950/40 p-6 space-y-6">
                    <div>
                      <h2 className="text-base font-black text-gray-900 dark:text-white tracking-tight">Account Settings</h2>
                      <p className="text-[11px] text-gray-400 mt-1 leading-relaxed">System preferences, privacy, and active theme.</p>
                    </div>

                    <div className="flex flex-row md:flex-col overflow-x-auto md:overflow-x-visible p-1 md:p-0 bg-gray-55 dark:bg-zinc-900/60 md:bg-transparent rounded-2xl md:rounded-none gap-1.5 scrollbar-hide">
                      {[
                        { id: 'theme', label: 'Theme & Appearance', desc: 'Colors', icon: Palette },
                        { id: 'badges', label: 'Badges', desc: 'Pin titles', icon: Award },
                        { id: 'privacy', label: 'Privacy', desc: 'Visibility', icon: ShieldCheck },
                        { id: 'alerts', label: 'Notifications', desc: 'Alerts', icon: Bell },
                        { id: 'account', label: 'Account', desc: 'Data & Actions', icon: UserIcon }
                      ].map(subTab => {
                        const SubIcon = subTab.icon;
                        const isSubActive = settingsActiveTab === subTab.id;
                        return (
                          <button
                            key={subTab.id}
                            onClick={() => setSettingsActiveTab(subTab.id as any)}
                            className={`flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-200 whitespace-nowrap md:whitespace-normal flex-shrink-0 ${
                              isSubActive 
                                ? `${accentAttr.primary} text-white shadow-xl ${accentAttr.shadow}` 
                                : 'bg-transparent text-gray-500 hover:text-gray-900 dark:text-zinc-400 dark:hover:text-zinc-200 hover:bg-gray-100/50 dark:hover:bg-zinc-900/30'
                            }`}
                          >
                            <SubIcon className={`w-4 h-4 shrink-0 ${isSubActive ? 'text-white' : 'text-gray-400'}`} />
                            <div className="text-left hidden sm:block">
                              <p className={`text-xs font-black uppercase tracking-wider leading-none ${isSubActive ? 'text-white' : 'text-gray-700 dark:text-zinc-300'}`}>{subTab.label}</p>
                              <p className={`text-[10px] mt-1 font-medium leading-none ${isSubActive ? 'text-white/70' : 'text-gray-400'}`}>{subTab.desc}</p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Right Side Settings content area */}
                  <div className="md:col-span-8 p-6 sm:p-8">
                     <AnimatePresence mode="wait">
                       
                       {/* Appearance Themes sub panel */}
                       {settingsActiveTab === 'theme' && (
                         <motion.div
                           key="theme-settings"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           className="space-y-6"
                         >
                            <div>
                              <h3 className="text-sm font-black text-gray-900 dark:text-white tracking-tight mb-2">Display Mode</h3>
                              <div className="p-4 bg-gray-50 dark:bg-zinc-900/30 rounded-2xl border border-gray-100/50 flex items-center justify-between">
                                <div>
                                   <p className="text-xs font-bold text-gray-800 dark:text-zinc-200">Toggle Theme</p>
                                   <p className="text-[11px] text-gray-400 font-medium">Switch between light and dark modes</p>
                                </div>
                                <button 
                                  onClick={toggleTheme}
                                  className={`flex items-center gap-1.5 px-4 py-2 font-black rounded-xl text-xs transition border dark:border-zinc-800 bg-white dark:bg-zinc-950 ${accentAttr.text}`}
                                >
                                  {isDarkMode ? (
                                    <>
                                      <Sun className="w-3.5 h-3.5 text-amber-500 animate-spin" />
                                      <span>Light mode</span>
                                    </>
                                  ) : (
                                    <>
                                      <Moon className="w-3.5 h-3.5 text-violet-500" />
                                      <span>Dark mode</span>
                                    </>
                                  )}
                                </button>
                              </div>
                            </div>

                            {/* Theme Accent color selector */}
                            <div>
                               <h3 className="text-sm font-black text-gray-900 dark:text-white tracking-tight mb-1">Theme Color</h3>
                               <p className="text-xs text-gray-400 mb-3">Choose a custom primary color for your profile page.</p>
                               <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                                 {Object.keys(ACCENTS).map(key => {
                                   const activeCol = ACCENTS[key];
                                   const isSelected = currentAccent === key;
                                   return (
                                     <button
                                       key={key}
                                       onClick={() => updateProfileSetting('accentColor', key)}
                                       className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition capitalize font-bold text-xs ${
                                         isSelected 
                                           ? `${activeCol.lightbg} border-2 ${activeCol.border}` 
                                           : 'bg-white dark:bg-zinc-950 border-gray-150 hover:bg-slate-50 dark:border-zinc-900'
                                       }`}
                                     >
                                        <span className={`w-4 h-4 rounded-full ${activeCol.primary}`}></span>
                                        <span className={isSelected ? 'text-gray-900 dark:text-white font-black' : 'text-gray-400'}>{key}</span>
                                     </button>
                                   );
                                 })}
                               </div>
                            </div>

                            {/* Preset Wallpapers Selectors */}
                            <div>
                               <h3 className="text-sm font-black text-gray-900 dark:text-white tracking-tight mb-1">Cover Gradient</h3>
                               <p className="text-xs text-gray-400 mb-3">Select a fallback background gradient.</p>
                               <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5">
                                 {COVER_GRADIENTS.map((grad, i) => {
                                   const isSelected = profile.coverGradientIndex === i;
                                   return (
                                     <button
                                       key={i}
                                       onClick={() => {
                                         // Clean up cover url first if they had custom image
                                         if (profile.coverPhotoUrl) {
                                           updateProfileSetting('coverPhotoUrl', '');
                                         }
                                         updateProfileSetting('coverGradientIndex', i);
                                       }}
                                       className={`text-left rounded-xl overflow-hidden border p-2 flex flex-col justify-between h-20 transition ${
                                         isSelected 
                                           ? `border-2 ${accentAttr.border} scale-[1.01]` 
                                           : 'border-gray-150 dark:border-zinc-900 hover:opacity-90'
                                       }`}
                                     >
                                        <div className={`w-full h-8 rounded-lg bg-gradient-to-br ${grad.class}`}></div>
                                        <span className={`text-[10px] uppercase font-black tracking-wider block mt-1.5 ${isSelected ? 'text-gray-900 dark:text-white font-black' : 'text-gray-400'}`}>
                                          {grad.name}
                                        </span>
                                     </button>
                                   );
                                 })}
                               </div>
                            </div>
                         </motion.div>
                       )}

                       {/* Title Badges */}
                       {settingsActiveTab === 'badges' && (
                         <motion.div
                           key="badge-settings"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           className="space-y-6"
                         >
                            <div>
                              <h3 className="text-sm font-black text-gray-900 dark:text-white tracking-tight mb-1">Pin Badge</h3>
                              <p className="text-xs text-gray-400 mb-4">Choose a badge to display next to your name.</p>
                              
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                                {(() => {
                                   const BADGE_REQUIREMENTS = {
                                     none: { stories: 0 },
                                     wordsmith: { stories: 1 },
                                     scribe: { stories: 3 },
                                     philosopher: { stories: 5 },
                                     narrator: { stories: 8 },
                                     adventurer: { stories: 12 },
                                     thinker: { stories: 15 }
                                   };

                                   return PINNED_BADGES.map(badge => {
                                     const req = BADGE_REQUIREMENTS[badge.id] || { stories: 0 };
                                     const isUnlocked = stories.length >= req.stories;
                                     const isSelected = (profile?.pinnedBadge || 'none') === badge.id;
                                     
                                     return (
                                       <button
                                         key={badge.id}
                                         disabled={!isUnlocked}
                                         onClick={() => isUnlocked && updateProfileSetting('pinnedBadge', badge.id)}
                                         className={`p-4 rounded-xl border text-left flex items-center justify-between transition \${
                                           !isUnlocked 
                                             ? 'bg-gray-50/50 dark:bg-zinc-900/10 border-gray-100 dark:border-zinc-900 opacity-55 cursor-not-allowed'
                                             : isSelected 
                                               ? \`\${accentAttr.lightbg} border-2 \${accentAttr.border}\` 
                                               : 'bg-white dark:bg-zinc-950 border-gray-150 hover:bg-slate-50 dark:border-zinc-900'
                                         }`}
                                       >
                                          <div className="min-w-0 flex-1">
                                            <p className={`text-xs font-black truncate flex items-center gap-1.5 \${isSelected ? 'text-gray-955 dark:text-white' : 'text-gray-655 dark:text-zinc-400'}`}>
                                              {!isUnlocked && <Lock className="w-3.5 h-3.5 text-gray-400 shrink-0" />}
                                              {badge.label}
                                            </p>
                                            <span className="text-[10px] text-gray-405 block mt-0.5 font-medium">
                                              {isUnlocked ? 'Achievement Unlocked' : `Locked (Requires ${req.stories} ${req.stories === 1 ? 'story' : 'stories'})`}
                                            </span>
                                          </div>
                                          {isUnlocked && isSelected && <Check className={`w-4 h-4 shrink-0 \${accentAttr.text}`} />}
                                       </button>
                                     );
                                   });
                                 })()}
                              </div>
                            </div>

                            {/* Info card describing tier level unlocks */}
                            <div className="p-4 bg-gray-50/50 dark:bg-zinc-900/40 rounded-2xl border border-gray-100 flex items-start gap-3">
                              <Sparkles className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
                              <div className="text-xs space-y-1">
                                <p className="font-bold text-gray-900 dark:text-white">Milestones & Levels</p>
                                <p className="text-gray-400 leading-normal font-medium">As you publish more stories, your author level increases. Unlock new badges based on your publishing activity.</p>
                              </div>
                            </div>
                         </motion.div>
                       )}

                       {/* Privacy panel */}
                       {settingsActiveTab === 'privacy' && (
                         <motion.div
                           key="privacy-settings"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           className="space-y-6"
                         >
                            <div>
                               <h3 className="text-sm font-black text-gray-900 dark:text-white tracking-tight mb-2">Visibility</h3>
                               <div className="p-4 bg-gray-50 dark:bg-zinc-900/30 rounded-2xl border border-gray-150/50 flex justify-between items-center">
                                 <div>
                                   <p className="text-xs font-bold text-gray-800 dark:text-zinc-200">Public Profile</p>
                                   <p className="text-[11px] text-gray-400 leading-normal">Let anyone search and view your published stories</p>
                                 </div>
                                 <button
                                   onClick={() => {
                                     const nextPrivacy = profile.profilePrivacy === 'private' ? 'public' : 'private';
                                     updateProfileSetting('profilePrivacy', nextPrivacy);
                                   }}
                                   className={`p-1 w-12 h-6 rounded-full transition-colors relative flex items-center ${profile.profilePrivacy === 'private' ? 'bg-zinc-300 dark:bg-zinc-800' : accentAttr.primary}`}
                                 >
                                    <span className={`w-4 h-4 bg-white rounded-full transition-all block ${profile.profilePrivacy === 'private' ? 'ml-1' : 'ml-7'}`} />
                                 </button>
                               </div>
                            </div>

                            {/* Password changes simulator */}
                            <div>
                               <h3 className="text-sm font-black text-gray-900 dark:text-white mb-2 tracking-tight">Security</h3>
                               <div className="space-y-2">
                                 <div className="p-4 bg-gray-50 dark:bg-zinc-900/30 rounded-2xl border border-gray-150/50 flex justify-between items-center">
                                    <div>
                                      <p className="text-xs font-bold text-gray-800 dark:text-zinc-200">Change Password</p>
                                      <p className="text-[11px] text-gray-400 font-medium">Reset password link securely sent to {profile.email}</p>
                                    </div>
                                    <button 
                                      onClick={() => showToast("Password reset link sent to your registered email.")} 
                                      className="text-xs font-black text-indigo-500 hover:underline capitalize"
                                    >
                                      Send reset request
                                    </button>
                                 </div>
                               </div>
                            </div>
                         </motion.div>
                       )}

                       {/* Readership and Email notification alerts configuration tab */}
                       {settingsActiveTab === 'alerts' && (
                         <motion.div
                           key="alerts-settings"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           className="space-y-6"
                         >
                            <div>
                               <h3 className="text-sm font-black text-gray-900 dark:text-white tracking-tight mb-1">Email Readership Alerts</h3>
                               <p className="text-xs text-gray-400 mb-3">Adjust how often you receive updates about comments, reactions, and direct followers</p>
                               
                               <div className="space-y-2">
                                 {[
                                   { id: 'all', title: 'Real-time Digest', desc: 'Instantly notify me about all community actions' },
                                   { id: 'daily', title: 'Daily Roundup', desc: 'Synthesize all updates into a single daily email digest' },
                                   { id: 'weekly', title: 'Weekly Summary', desc: 'Synthesize updates into a weekly Sunday digest' },
                                   { id: 'none', title: 'None (Mute)', desc: 'Mute all readout and email notification requests' }
                                 ].map(item => {
                                   const isSelected = (profile.notificationFrequency || 'all') === item.id;
                                   return (
                                     <button
                                       key={item.id}
                                       onClick={() => updateProfileSetting('notificationFrequency', item.id)}
                                       className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition ${
                                         isSelected 
                                           ? `${accentAttr.lightbg} border-2 ${accentAttr.border}` 
                                           : 'bg-white dark:bg-zinc-950 border-gray-150 hover:bg-slate-50 dark:border-zinc-900'
                                       }`}
                                     >
                                        <div>
                                          <p className={`text-xs font-bold ${isSelected ? 'text-gray-900 dark:text-white font-black' : 'text-gray-700 dark:text-zinc-300'}`}>
                                            {item.title}
                                          </p>
                                          <span className="text-[11px] text-gray-400 block mt-0.5">{item.desc}</span>
                                        </div>
                                        {isSelected && <Check className={`w-4 h-4 ${accentAttr.text}`} />}
                                     </button>
                                   );
                                 })}
                               </div>
                            </div>
                         </motion.div>
                       )}

                       {/* Account panel */}
                       {settingsActiveTab === 'account' && (
                         <motion.div
                           key="account-settings"
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           exit={{ opacity: 0, y: -10 }}
                           className="space-y-6"
                         >
                            <div className="p-5 rounded-2xl border border-gray-150 dark:border-zinc-900 bg-gray-50/50 dark:bg-zinc-900/30">
                               <h3 className="text-sm font-black text-gray-900 dark:text-white tracking-tight mb-1">Support & Assistance</h3>
                               <p className="text-xs text-gray-400 mb-4 font-medium leading-relaxed">If you face any issues with your account or need help with the platform, feel free to contact the administrator.</p>
                               <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                                 <a 
                                   href="mailto:starbad366@gmail.com"
                                   className={`inline-flex items-center justify-center gap-2 px-5 py-2.5 ${accentAttr.primary} text-white font-bold rounded-xl text-xs transition ${accentAttr.hover} ${accentAttr.shadow} shadow-md`}
                                 >
                                   <MessageCircle className="w-4 h-4" />
                                   Contact Admin
                                 </a>
                                 <div className="px-4 py-2.5 bg-white dark:bg-zinc-950 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs font-bold text-gray-600 dark:text-zinc-300 flex items-center justify-center">
                                   starbad366@gmail.com
                                 </div>
                               </div>
                            </div>
                         </motion.div>
                       )}

                     </AnimatePresence>
                  </div>

                  {/* Danger Zone */}
                  <div className="p-6 bg-rose-500/5 border-t border-rose-500/10 space-y-3">
                     <div className="flex items-start gap-2.5">
                       <LogOut className="w-4.5 h-4.5 text-rose-500 mt-0.5" />
                       <div className="text-xs">
                         <h4 className="font-extrabold text-rose-600 dark:text-rose-400">Danger Zone</h4>
                         <p className="text-gray-400 mt-0.5 leading-normal font-medium">Deauthorizing your container or signing out clears critical environment cookies.</p>
                       </div>
                     </div>
                     <div className="flex flex-col sm:flex-row gap-2 pt-1.5">
                       <button
                         onClick={handleLogout}
                         className="flex items-center justify-center gap-1.5 px-5 py-2.5 bg-white dark:bg-zinc-950 border border-rose-100 hover:bg-rose-50/50 dark:border-rose-900/30 text-rose-600 dark:text-rose-400 font-bold rounded-xl text-xs transition shadow-sm"
                       >
                         <LogOut className="w-3.5 h-3.5" />
                         <span>Sign out immediately</span>
                       </button>

                       <button
                         disabled
                         className="flex items-center justify-center gap-1.5 px-5 py-2.5 bg-gray-50/50 dark:bg-zinc-900 text-gray-300 dark:text-zinc-800 border border-gray-100 dark:border-zinc-900 font-bold rounded-xl text-xs cursor-not-allowed"
                       >
                         Deconstruct Scribe Registry
                       </button>
                     </div>
                  </div>

                </div>

                {/* Integration Info widget */}
                <div className="p-5 bg-gradient-to-r from-indigo-50/50 via-teal-50/30 to-slate-50 dark:from-zinc-900/50 dark:to-zinc-900/20 border border-gray-100 dark:border-zinc-900 rounded-3xl flex items-start gap-3">
                   <Info className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
                   <div className="text-xs leading-relaxed font-medium text-gray-500">
                     <h5 className="font-bold text-gray-900 dark:text-zinc-300 mb-0.5">Smart Storytelling Key Support</h5>
                     <p className="text-gray-400">To unlock full automatic theme suggestions and deep smart categorizations during writing, configure your Gemini API Key in the upper right workspace Settings frame.</p>
                   </div>
                </div>

             </div>
          )}

        </motion.div>

      </div>

      <FollowListModal
        isOpen={followModal.isOpen}
        onClose={() => setFollowModal(prev => ({ ...prev, isOpen: false }))}
        userId={profile.uid}
        type={followModal.type}
        title={followModal.title}
      />
    </div>
  );
}
