import React, { useState, useEffect } from 'react';
import { useParams, Link, useLocation } from 'react-router-dom';
import { doc, getDoc, updateDoc, increment, setDoc, deleteDoc, serverTimestamp, collection, query, where, limit, getDocs, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { formatDistanceToNow } from 'date-fns';
import { Heart, MessageCircle, User, Loader2, Share2, ArrowLeft, Eye, Clock, Bookmark, BookmarkCheck, Flag, Maximize2, CheckCheck, BookOpen, ChevronLeft, Plus } from 'lucide-react';
import { handleFirestoreError, calculateReadingTime, cn } from '../lib/utils';
import StoryComments from '../components/StoryComments';
import ReactionButton from '../components/ReactionButton';
import { motion } from 'motion/react';
import { createNotification } from '../lib/notifications';
import { MONETIZATION_RATES } from '../lib/constants';
import { DollarSign, ExternalLink, Sparkles } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import AdSense from '../components/AdSense';
import StoryAnalytics from '../components/StoryAnalytics';

interface Story {
  id: string;
  authorId: string;
  title: string;
  content: string;
  category: string;
  likesCount: number;
  commentsCount: number;
  createdAt: any;
  updatedAt: any;
  imageUrl?: string;
  authorProfile?: any;
  isLikedByMe?: boolean;
  myReaction?: string | null;
  viewsCount: number;
  parts?: any[];
}

export default function SingleStory() {
  const { id } = useParams<{ id: string }>();
  const [story, setStory] = useState<Story | null>(null);
  const [relatedStories, setRelatedStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingRelated, setLoadingRelated] = useState(false);
  const [expandedComments, setExpandedComments] = useState(true);
  const { currentUser } = useAuth();
  const [copiedLink, setCopiedLink] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [reporting, setReporting] = useState(false);
  const [showReported, setShowReported] = useState(false);
  const [isReadingMode, setIsReadingMode] = useState(false);
  const [isMonetized, setIsMonetized] = useState(false);
  const [isReading, setIsReading] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<'summary' | 'parts' | 'analytics'>(() => {
    if (location.state?.activeTab === 'analytics') {
      return 'analytics';
    }
    return 'summary';
  });
  const [activePartIdx, setActivePartIdx] = useState<number | null>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = document.documentElement.scrollTop || window.scrollY;
      const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (windowHeight > 0) {
        setScrollProgress((scrollPosition / windowHeight) * 100);
      } else {
        setScrollProgress(0);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to top when id changes
    if (id) {
      fetchStory().then((fetchedStory) => {
        if (fetchedStory) {
          fetchRelatedStories(fetchedStory);
        }
      });
    }
  }, [id, currentUser]);

  const fetchStory = async () => {
    try {
      if (!id) return null;
      setLoading(true);
      
      const storyDoc = await getDoc(doc(db, 'stories', id));
      if (!storyDoc.exists()) {
        setStory(null);
        setLoading(false);
        return null;
      }

      const data = storyDoc.data() as Omit<Story, 'id'>;
      let authorProfile = null;
      let isLikedByMe = false;

      // Fetch author profile
      if (data.authorId) {
        const authorDoc = await getDoc(doc(db, 'users', data.authorId));
        if (authorDoc.exists()) {
          authorProfile = authorDoc.data();
        }
      }
      
      // Check if I liked it
      let myReaction = null;
      if (currentUser) {
        const likeDoc = await getDoc(doc(db, 'stories', id, 'likes', currentUser.uid));
        isLikedByMe = likeDoc.exists();
        if (isLikedByMe) {
          myReaction = likeDoc.data()?.type || 'heart';
        }

        const savedDoc = await getDoc(doc(db, `users/${currentUser.uid}/savedStories`, id));
        setIsSaved(savedDoc.exists());

        if (data.authorId && currentUser.uid !== data.authorId) {
          try {
            const followRef = doc(db, `users/${data.authorId}/followers`, currentUser.uid);
            const followDoc = await getDoc(followRef);
            setIsFollowing(followDoc.exists());
          } catch (err) {
            console.warn("Could not fetch follow mechanics:", err);
          }
        }
      }

      const fetchedStory = {
        ...data,
        id: storyDoc.id,
        authorProfile,
        isLikedByMe,
        myReaction
      };
      
      setStory(fetchedStory);
      
      // Check for monetization eligibility
      checkMonetization(fetchedStory.authorId);
      
      // Increment views count
      try {
        const storyRef = doc(db, 'stories', fetchedStory.id);
        await updateDoc(storyRef, { viewsCount: increment(1) });
      } catch (err) {
        console.error("Error incrementing views:", err);
      }

      return fetchedStory;
    } catch (error) {
      if (error instanceof Error && error.message.includes("offline")) {
         // Silently fail on offline
      } else {
        console.error("Error fetching story:", error);
      }
      return null;
    } finally {
      setLoading(false);
    }
  };

  const fetchRelatedStories = async (currentStory: Story) => {
    setLoadingRelated(true);
    try {
      // Fetch up to 5 stories in the same category
      const q = query(
        collection(db, 'stories'),
        where('category', '==', currentStory.category),
        limit(5)
      );
      
      const snapshot = await getDocs(q);
      const related: Story[] = [];

      for (const docSnap of snapshot.docs) {
        if (docSnap.id === currentStory.id) continue; // Skip the currently viewed story
        if (related.length >= 3) break; // We only want to show 3 related stories
        
        const data = docSnap.data() as Omit<Story, 'id'>;
        let authorProfile = null;
        
        if (data.authorId) {
          const authorDoc = await getDoc(doc(db, 'users', data.authorId));
          if (authorDoc.exists()) {
            authorProfile = authorDoc.data();
          }
        }

        related.push({
          ...data,
          id: docSnap.id,
          authorProfile
        } as Story);
      }

      setRelatedStories(related);
    } catch (error) {
      console.error("Error fetching related stories:", error);
    } finally {
      setLoadingRelated(false);
    }
  };

  const checkMonetization = async (authorId: string) => {
    try {
      const q = query(collection(db, 'stories'), where('authorId', '==', authorId));
      const snap = await getDocs(q);
      const stories = snap.docs.map(doc => doc.data());
      
      const totalLikes = stories.reduce((acc, s) => acc + (s.likesCount || 0), 0);
      const totalStories = stories.length;
      
      if (totalLikes >= MONETIZATION_RATES.LIKES_REQUIREMENT && totalStories >= MONETIZATION_RATES.STORIES_REQUIREMENT) {
        setIsMonetized(true);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleFollow = async () => {
    if (!currentUser || !story || !story.authorId || followLoading) return;
    setFollowLoading(true);

    const wasFollowing = isFollowing;
    const authorId = story.authorId;

    const followerRef = doc(db, `users/${authorId}/followers`, currentUser.uid);
    const followingRef = doc(db, `users/${currentUser.uid}/following`, authorId);
    const followedUserRef = doc(db, 'users', authorId);
    const currentUserRef = doc(db, 'users', currentUser.uid);

    setIsFollowing(!wasFollowing);

    try {
      const { writeBatch } = await import('firebase/firestore');
      const batch = writeBatch(db);

      if (wasFollowing) {
        batch.delete(followerRef);
        batch.delete(followingRef);
        batch.update(followedUserRef, { followersCount: increment(-1) });
        batch.update(currentUserRef, { followingCount: increment(-1) });
      } else {
        const followData = {
          followerId: currentUser.uid,
          followedId: authorId,
          createdAt: serverTimestamp()
        };
        batch.set(followerRef, followData);
        batch.set(followingRef, followData);
        batch.update(followedUserRef, { followersCount: increment(1) });
        batch.update(currentUserRef, { followingCount: increment(1) });
      }

      await batch.commit();

      if (!wasFollowing) {
        await createNotification(
          authorId,
          currentUser.uid,
          'follow',
          `${currentUser.displayName} followed you!`,
          `/profile/${currentUser.uid}`
        );
      }
    } catch (error) {
      setIsFollowing(wasFollowing);
      handleFirestoreError(error, 'follow', `users/${authorId}/followers`, currentUser);
    } finally {
      setFollowLoading(false);
    }
  };

  const handleLike = async () => {
    if (!currentUser || !story) return;
    
    const currentlyLiked = !!story.isLikedByMe;

    // Optimistic UI Update
    setStory((current) => {
      if (!current) return current;
      return {
        ...current,
        isLikedByMe: !currentlyLiked,
        likesCount: currentlyLiked ? current.likesCount - 1 : current.likesCount + 1
      };
    });

    try {
      const storyRef = doc(db, 'stories', story.id);
      const likeRef = doc(db, 'stories', story.id, 'likes', currentUser.uid);

      if (currentlyLiked) {
        await deleteDoc(likeRef);
        await updateDoc(storyRef, { likesCount: increment(-1) });
      } else {
        await setDoc(likeRef, {
          userId: currentUser.uid,
          createdAt: serverTimestamp()
        });
        await updateDoc(storyRef, { likesCount: increment(1) });

        // Trigger notification
        if (story.authorId !== currentUser.uid) {
          await createNotification(
            story.authorId,
            currentUser.uid,
            'like',
            `${currentUser.displayName} liked your story: ${story.title}`,
            `/story/${story.id}`
          );
        }
      }
    } catch (error) {
      handleFirestoreError(error, 'like', `stories/${story.id}/likes`, currentUser);
      fetchStory(); // Revert on failure
    }
  };

  const handleSave = async () => {
    if (!currentUser || !story || saving) return;
    
    setSaving(true);
    const currentlySaved = isSaved;
    
    // Optimistic
    setIsSaved(!currentlySaved);

    try {
      const savedRef = doc(db, `users/${currentUser.uid}/savedStories`, story.id);
      
      if (currentlySaved) {
        await deleteDoc(savedRef);
      } else {
        await setDoc(savedRef, {
          storyId: story.id,
          savedAt: serverTimestamp()
        });
      }
    } catch (error) {
      setIsSaved(currentlySaved);
      handleFirestoreError(error, 'save', `users/${currentUser.uid}/savedStories`, currentUser);
    } finally {
      setSaving(false);
    }
  };

  const handleShare = async () => {
    if (!story) return;
    const url = `${window.location.origin}/story/${story.id}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: story.title,
          text: `Check out this story: ${story.title}`,
          url: url,
        });
      } catch (err) {
        if (err instanceof Error && (err.name === 'AbortError' || err.message.toLowerCase().includes('cancel'))) {
          // User canceled the share, safely ignore
          return;
        }
        console.error("Error sharing:", err);
      }
    } else {
      navigator.clipboard.writeText(url);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const handleCommentAdded = () => {
    if (!story) return;
    setStory({ ...story, commentsCount: (story.commentsCount || 0) + 1 });
  };

  const handleReport = async () => {
    if (!currentUser || !story || reporting) return;
    
    if (!confirm("Are you sure you want to report this story for inappropriate content?")) return;

    setReporting(true);
    try {
      await addDoc(collection(db, 'reports'), {
        storyId: story.id,
        reporterId: currentUser.uid,
        authorId: story.authorId,
        reason: 'Inappropriate content',
        status: 'pending',
        createdAt: serverTimestamp()
      });
      setShowReported(true);
      setTimeout(() => setShowReported(false), 3000);
    } catch (error) {
      console.error("Error reporting:", error);
      alert("Failed to report story.");
    } finally {
      setReporting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col flex-1 items-center justify-center py-20 min-h-[50vh]">
        <Loader2 className="w-8 h-8 text-blue-600 animate-spin mb-4" />
        <p className="text-gray-500 font-medium">Loading story...</p>
      </div>
    );
  }

  if (!story) {
    return (
      <div className="text-center py-20 bg-white dark:bg-black rounded-2xl border border-gray-100 dark:border-zinc-800">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white">Story not found</h3>
        <Link to="/" className="text-indigo-600 mt-2 inline-block">Go back to Feed</Link>
      </div>
    );
  }

  // Distraction-Free active reading view matches Screenshot 3
  if (isReading) {
    return (
      <div className="max-w-2xl mx-auto px-4 pb-24 font-serif select-text transition-all duration-300">
        <Helmet>
          <title>{story.title} | Reading Mode</title>
        </Helmet>

        {/* Scroll Progress Bar */}
        <div className="fixed top-0 left-0 w-full h-[3px] bg-transparent z-[100] pointer-events-none">
          <div 
            className="h-full bg-indigo-500 transition-all duration-150 ease-out"
            style={{ width: `${scrollProgress}%` }}
          />
        </div>

        {/* Reader Header */}
        <div className="flex items-center justify-between py-4 border-b border-gray-100 dark:border-zinc-900 mb-8 sticky top-0 bg-white/95 dark:bg-black/95 backdrop-blur z-20">
          <button 
            onClick={() => {
              setIsReading(false);
              window.scrollTo(0, 0);
            }}
            className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-zinc-900 transition-colors"
          >
            <ChevronLeft className="w-6 h-6 text-gray-600 dark:text-zinc-300" />
          </button>
          <div className="flex items-center space-x-2.5">
            {story.authorProfile?.photoURL ? (
              <img src={story.authorProfile.photoURL} alt="" className="w-7 h-7 rounded-full object-cover" />
            ) : (
              <div className="w-7 h-7 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center"><User className="w-4 h-4 text-zinc-500" /></div>
            )}
            <span className="font-sans text-sm font-semibold text-gray-800 dark:text-zinc-200">
              {story.authorProfile?.displayName || 'Anonymous'}
            </span>
          </div>
          <div className="w-10"></div> {/* Spacer for symmetry */}
        </div>

        {/* Read Body content */}
        <div className="space-y-6">
          <h1 className="text-3xl font-extrabold text-gray-950 dark:text-white leading-tight font-serif text-center mb-6">
            {activePartIdx !== null && story.parts && story.parts[activePartIdx] ? story.parts[activePartIdx].title : story.title}
          </h1>

          <p className="text-[19px] sm:text-[21px] leading-relaxed select-text font-serif text-zinc-800 dark:text-zinc-200 whitespace-pre-wrap tracking-wide leading-extra-relaxed max-w-xl mx-auto">
            {activePartIdx !== null && story.parts && story.parts[activePartIdx] ? story.parts[activePartIdx].content : story.content}
          </p>
        </div>

        {/* Comments section embedded inside reader body */}
        <div className="mt-16 pt-8 border-t border-gray-100 dark:border-zinc-900 max-w-xl mx-auto font-sans">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Comments ({story.commentsCount || 0})</h3>
          <StoryComments storyId={story.id} onCommentAdded={handleCommentAdded} />
        </div>

        {/* Sticky bottom stats layout matching Screenshot 3 */}
        <div className="fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-zinc-950/95 border-t border-gray-100 dark:border-zinc-900 backdrop-blur z-20 shadow-lg">
          <div className="max-w-lg mx-auto flex items-center justify-around h-14 text-zinc-500 dark:text-zinc-400 font-sans text-sm font-semibold">
            {/* Views count */}
            <div className="flex items-center space-x-1.5" title="Views">
              <Eye className="w-5 h-5 text-zinc-400" />
              <span>{story.viewsCount || 0}</span>
            </div>

            {/* Likes count */}
            <motion.button 
              onClick={handleLike}
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.92 }}
              transition={{ type: 'spring', stiffness: 500, damping: 15 }}
              className="flex items-center space-x-1.5 hover:text-red-500 transition cursor-pointer focus:outline-none" 
              title="Like"
            >
              <Heart className={`w-5 h-5 transition-colors ${story.isLikedByMe ? 'text-red-500 fill-current' : 'text-zinc-500'}`} />
              <span className={story.isLikedByMe ? 'text-red-500 font-extrabold' : ''}>{story.likesCount || 0}</span>
            </motion.button>

            {/* Comments count */}
            <div className="flex items-center space-x-1.5" title="Comments">
              <MessageCircle className="w-5 h-5 text-indigo-500" />
              <span>{story.commentsCount || 0}</span>
            </div>

            {/* Shares count */}
            <button onClick={handleShare} className="flex items-center space-x-1.5 hover:text-indigo-600 transition" title="Share">
              <Share2 className="w-5 h-5 text-emerald-500" />
              <span>{story.sharesCount || 0}</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Premium details summary cover view matches Screenshot 2
  return (
    <div className="max-w-2xl mx-auto px-4 pb-24 space-y-6 font-sans">
      <Helmet>
        <title>{story.title} | life Stories</title>
      </Helmet>

      {/* Scroll Progress Bar */}
      <div className="fixed top-0 left-0 w-full h-[3px] bg-transparent z-[100] pointer-events-none">
        <div 
          className="h-full bg-indigo-500 transition-all duration-150 ease-out"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* Header back navigation */}
      <div className="py-2">
        <Link 
          to="/" 
          className="inline-flex items-center p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-zinc-900 text-gray-500 hover:text-gray-900 transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </Link>
      </div>

      {/* Visual story content cover panel matches Screenshot 2 */}
      <div className="bg-white dark:bg-zinc-950 rounded-[24px] p-6 border border-gray-100 dark:border-zinc-900 shadow-sm">
        <div className="flex flex-col sm:flex-row gap-6">
          {/* Cover portrait thumbnail */}
          <div className="w-[124px] h-[170px] bg-zinc-50 dark:bg-zinc-900 rounded-[18px] overflow-hidden border border-gray-100 dark:border-zinc-800 shadow-md flex-shrink-0 mx-auto sm:mx-0 relative">
            {story.imageUrl ? (
              <img src={story.imageUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-gradient-to-br from-indigo-50 to-indigo-100/50 dark:from-zinc-900 dark:to-zinc-800">
                <BookOpen className="w-6 h-6 text-indigo-500 mb-1" />
                <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">{story.category}</span>
              </div>
            )}
          </div>

          {/* Description specs */}
          <div className="flex-1 text-center sm:text-left flex flex-col justify-between">
            <div>
              <h1 className="text-[24px] font-extrabold text-gray-950 dark:text-white leading-tight mb-2 tracking-tight">
                {story.title}
              </h1>
              
              {/* Creator details row */}
              <div className="flex items-center justify-center sm:justify-start space-x-3 mb-4">
                <Link to={`/profile/${story.authorId}`}>
                  {story.authorProfile?.photoURL ? (
                    <img src={story.authorProfile.photoURL} alt="" className="w-8 h-8 rounded-full object-cover" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center"><User className="w-4 h-4 text-zinc-500" /></div>
                  )}
                </Link>
                <div className="text-left">
                  <Link to={`/profile/${story.authorId}`} className="text-sm font-bold text-gray-800 dark:text-zinc-200 hover:underline">
                    {story.authorProfile?.displayName || 'Anonymous'}
                  </Link>
                  <p className="text-[10px] text-gray-400 font-medium font-sans mt-0.5">
                    <span className="capitalize">{story.category}</span>
                    <span className="mx-1.5">•</span>
                    <span>{story.createdAt?.toDate ? formatDistanceToNow(story.createdAt.toDate(), { addSuffix: true }) : 'Just now'}</span>
                  </p>
                </div>
                
                {currentUser && currentUser.uid !== story.authorId && (
                  <motion.button
                    onClick={toggleFollow}
                    disabled={followLoading}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 15 }}
                    className={`ml-4 px-4 py-1 rounded-full text-xs font-bold transition cursor-pointer ${
                      isFollowing
                        ? 'bg-zinc-200 text-zinc-800 dark:bg-zinc-800 dark:text-zinc-200'
                        : 'bg-zinc-900 text-white dark:bg-white dark:text-black hover:opacity-90'
                    }`}
                  >
                    {isFollowing ? 'Following' : 'Follow'}
                  </motion.button>
                )}
              </div>
            </div>

            {/* Horizontal metrics stats row */}
            <div className="flex items-center justify-center sm:justify-start gap-4 pt-3 border-t border-gray-50 dark:border-zinc-900/60 text-zinc-500 dark:text-zinc-400 text-sm font-bold font-sans">
              <div className="flex items-center space-x-1.5" title="Views">
                <Eye className="w-4 h-4" />
                <span>{story.viewsCount || 0}</span>
              </div>
              <motion.button 
                onClick={handleLike}
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.92 }}
                transition={{ type: 'spring', stiffness: 500, damping: 15 }}
                className="flex items-center space-x-1.5 hover:text-red-500 transition cursor-pointer focus:outline-none animate-fade-in" 
                title="Like"
              >
                <Heart className={`w-4 h-4 transition-colors ${story.isLikedByMe ? 'text-red-500 fill-current' : 'text-zinc-400 dark:text-zinc-500'}`} />
                <span className={story.isLikedByMe ? 'text-red-500 font-extrabold' : ''}>{story.likesCount || 0}</span>
              </motion.button>
              <div className="flex items-center space-x-1.5" title="Shares">
                <Share2 className="w-4 h-4 text-zinc-400" />
                <span>{story.sharesCount || 0}</span>
              </div>
              {story.parts && story.parts.length > 0 && (
                <div className="flex items-center space-x-1.5" title="Parts">
                  <BookOpen className="w-4 h-4 text-zinc-400" />
                  <span>{story.parts.length} Parts</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Tabs selections */}
      <div className="border-b border-gray-100 dark:border-zinc-900">
        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab('summary')}
            className={`pb-3 text-sm font-bold transition-all relative cursor-pointer ${
              activeTab === 'summary' 
                ? 'text-gray-900 dark:text-white font-extrabold' 
                : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            Summary
            {activeTab === 'summary' && (
              <span className="absolute bottom-0 left-0 right-0 h-[3px] bg-[#ff501a] rounded-full animate-fade-in" />
            )}
          </button>
          
          {story.parts && story.parts.length > 0 && (
            <button
              onClick={() => setActiveTab('parts')}
              className={`pb-3 text-sm font-bold transition-all relative cursor-pointer ${
                activeTab === 'parts' 
                  ? 'text-gray-900 dark:text-white font-extrabold' 
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              Parts
              {activeTab === 'parts' && (
                <span className="absolute bottom-0 left-0 right-0 h-[3px] bg-[#ff501a] rounded-full animate-fade-in" />
              )}
            </button>
          )}

          {currentUser && currentUser.uid === story.authorId && (
            <button
              onClick={() => setActiveTab('analytics')}
              className={`pb-3 text-sm font-bold transition-all relative cursor-pointer ${
                activeTab === 'analytics' 
                  ? 'text-gray-900 dark:text-white font-extrabold' 
                  : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              Analytics
              {activeTab === 'analytics' && (
                <span className="absolute bottom-0 left-0 right-0 h-[3px] bg-[#ff501a] rounded-full animate-fade-in" />
              )}
            </button>
          )}
        </div>
      </div>

      {/* Tabs panels */}
      <div className="space-y-6">
        {activeTab === 'analytics' && currentUser && currentUser.uid === story.authorId ? (
          <StoryAnalytics story={story as any} isMonetized={isMonetized} />
        ) : activeTab === 'summary' ? (
          <>
            {/* Story Summary */}
            <div className="space-y-3">
              <h3 className="text-xs uppercase tracking-wider font-extrabold text-zinc-400 dark:text-zinc-500 leading-none">Synopsis</h3>
              <div className="bg-white dark:bg-zinc-950 rounded-2xl p-5 border border-gray-100 dark:border-zinc-900">
                <p className="text-[14px] text-gray-600 dark:text-zinc-400 leading-relaxed max-h-48 overflow-y-auto">
                  {story.summary || story.content.replace(/[#*`_\[\]]/g, '').trim()}
                </p>
              </div>
            </div>

            {/* Comments panel */}
            <div className="space-y-3">
              <h3 className="text-xs uppercase tracking-wider font-extrabold text-zinc-400 dark:text-zinc-500 leading-none">Comments ({story.commentsCount || 0})</h3>
              <div className="bg-white dark:bg-zinc-950 rounded-2xl p-4 border border-gray-100 dark:border-zinc-900">
                <StoryComments storyId={story.id} onCommentAdded={handleCommentAdded} />
              </div>
            </div>
          </>
        ) : (
          /* Chapter/Parts selector list */
          <div className="space-y-3">
            <h3 className="text-xs uppercase tracking-wider font-extrabold text-zinc-400 dark:text-zinc-500 leading-none">Story parts</h3>
            <div className="divide-y divide-gray-50 dark:divide-zinc-900 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-100 dark:border-zinc-900 overflow-hidden">
              {story.parts && story.parts.length > 0 ? (
                story.parts.map((p: any, idx: number) => (
                  <button 
                    key={idx}
                    onClick={() => {
                      setActivePartIdx(idx);
                      setIsReading(true);
                      window.scrollTo(0, 0);
                    }} 
                    className="w-full text-left p-4 hover:bg-gray-50 dark:hover:bg-zinc-900 transition flex items-center justify-between cursor-pointer"
                  >
                    <div>
                      <h4 className="font-bold text-sm text-gray-900 dark:text-white">Part {idx + 1}: {p.title}</h4>
                      <p className="text-xs text-gray-400 mt-0.5">{calculateReadingTime(p.content || '')} min read</p>
                    </div>
                    <BookOpen className="w-4 h-4 text-indigo-500" />
                  </button>
                ))
              ) : (
                <button 
                  onClick={() => {
                    setActivePartIdx(null);
                    setIsReading(true);
                    window.scrollTo(0, 0);
                  }} 
                  className="w-full text-left p-4 hover:bg-gray-50 dark:hover:bg-zinc-900 transition flex items-center justify-between cursor-pointer"
                >
                  <div>
                    <h4 className="font-bold text-sm text-gray-900 dark:text-white">Part 1: {story.title}</h4>
                    <p className="text-xs text-gray-400 mt-0.5">{calculateReadingTime(story.content)} min read</p>
                  </div>
                  <BookOpen className="w-4 h-4 text-indigo-500" />
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Floating Action read trigger at structurally sticky screen bottom matches Screenshot 2 */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-zinc-50 via-zinc-50/90 to-transparent dark:from-black dark:via-black/90 z-20 flex justify-center items-center">
        <div className="max-w-md w-full flex items-center space-x-3.5 shadow-xl bg-white dark:bg-zinc-900 p-2.5 rounded-full border border-gray-100 dark:border-zinc-800">
          <button
            onClick={() => {
              setIsReading(true);
              window.scrollTo(0, 0);
            }}
            className="flex-1 py-3.5 px-6 rounded-full bg-[#ff501a] hover:bg-[#e04513] text-white text-[14px] font-black uppercase tracking-wider transition-all active:scale-95 text-center cursor-pointer shadow-lg shadow-orange-500/20"
          >
            Continue Reading
          </button>
          
          <button
            onClick={handleSave}
            disabled={saving}
            className={`w-[48px] h-[48px] rounded-full flex items-center justify-center transition-all border cursor-pointer ${
              isSaved 
                ? 'bg-orange-50 border-orange-200 text-[#ff501a] dark:bg-zinc-800 dark:border-zinc-700' 
                : 'bg-zinc-50 border-zinc-100 text-zinc-500 dark:bg-zinc-800 dark:border-zinc-700'
            }`}
            title={isSaved ? "Saved to Bookmarks" : "Add to Bookmarks"}
          >
            <Plus className={`w-5 h-5 transition-transform duration-300 ${isSaved ? 'rotate-45' : ''}`} />
          </button>
        </div>
      </div>
    </div>
  );
}
