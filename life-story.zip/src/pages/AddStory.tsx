import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, doc, setDoc, getDoc, updateDoc, getDocs, query, where, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { handleFirestoreError, uploadImage } from '../lib/utils';
import { ChevronLeft, Image as ImageIcon, Sparkles, Loader2, X, Plus, BookOpen } from 'lucide-react';
import { suggestStoryContent, refineStoryContent } from '../services/geminiService';
import { STORY_CATEGORIES } from '../lib/constants';

const CATEGORIES = STORY_CATEGORIES;

interface StoryListItem {
  id: string;
  title: string;
  category: string;
  parts?: any[];
}

export default function AddStory() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form Mode
  const [formMode, setFormMode] = useState<'new' | 'part'>('new');
  const [userStories, setUserStories] = useState<StoryListItem[]>([]);
  const [selectedStoryId, setSelectedStoryId] = useState('');
  const [loadingStories, setLoadingStories] = useState(false);

  // Form Fields
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('general');
  const [hashtags, setHashtags] = useState('');
  const [isPremium, setIsPremium] = useState(false);
  const [premiumTeaser, setPremiumTeaser] = useState('');
  const [premiumCost, setPremiumCost] = useState(0);
  const [summary, setSummary] = useState('');

  // Image Upload Fields
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // UI States
  const [isLoading, setIsLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [error, setError] = useState('');
  const [aiSuggestions, setAiSuggestions] = useState<any | null>(null);
  const [showAiPanel, setShowAiPanel] = useState(false);

  // Fetch current user's existing stories on mount (for Add Part mode)
  useEffect(() => {
    if (currentUser) {
      setLoadingStories(true);
      const q = query(
        collection(db, 'stories'),
        where('authorId', '==', currentUser.uid)
      );
      getDocs(q)
        .then((snapshot) => {
          const list = snapshot.docs.map(d => ({
            id: d.id,
            title: d.data().title || 'Untitled Story',
            category: d.data().category || 'general',
            parts: d.data().parts || []
          }));
          setUserStories(list);
        })
        .catch((err) => {
          console.error("Error fetching user's stories:", err);
        })
        .finally(() => {
          setLoadingStories(false);
        });
    }
  }, [currentUser]);

  // When selected story is changed, auto map details
  const handleSelectStory = (storyId: string) => {
    setSelectedStoryId(storyId);
    if (storyId) {
      const selected = userStories.find(u => u.id === storyId);
      if (selected) {
        setCategory(selected.category);
        setTitle(`Part ${ (selected.parts?.length || 0) + 1 }`);
      }
    } else {
      setTitle('');
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setError('Image size should be less than 5MB');
        return;
      }
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setError('');
    }
  };

  const removeImage = () => {
    setImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const saveToFirestore = async (isDraft: boolean) => {
    if (formMode === 'new' && !title.trim()) {
      setError('Story title is required.');
      return;
    }
    if (formMode === 'part' && !selectedStoryId) {
      setError('Please select which of your stories to add this part to.');
      return;
    }
    if (!content.trim()) {
      setError('Story content is required.');
      return;
    }
    if (!currentUser) return;

    setIsLoading(true);
    setError('');

    try {
      let finalImageUrl = '';

      // Upload Cover if new form mode and image selected
      if (formMode === 'new' && image) {
        finalImageUrl = await uploadImage(image);
      }

      if (formMode === 'new') {
        const storyRef = doc(collection(db, isDraft ? 'drafts' : 'stories'));
        
        const storyData: any = {
          authorId: currentUser.uid,
          title: title.trim(),
          content: content.trim(),
          category,
          hashtags: hashtags.trim(),
          isPremium,
          premiumTeaser: premiumTeaser.trim(),
          premiumCost: Number(premiumCost) || 0,
          summary: summary.trim(),
          likesCount: 0,
          commentsCount: 0,
          viewsCount: 0,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          parts: [
            {
              title: title.trim(),
              content: content.trim(),
              createdAt: new Date().toISOString()
            }
          ]
        };

        if (finalImageUrl) {
          storyData.imageUrl = finalImageUrl;
        }

        await setDoc(storyRef, storyData);
        
        if (isDraft) {
          navigate(`/profile/${currentUser.uid}?tab=drafts`);
        } else {
          navigate('/');
        }
      } else {
        // Form Mode: PART
        const storyRef = doc(db, 'stories', selectedStoryId);
        const storySnap = await getDoc(storyRef);
        
        if (!storySnap.exists()) {
          throw new Error("Story target not found");
        }

        const currentStoryData = storySnap.data();
        const currentParts = currentStoryData.parts || [
          {
            title: currentStoryData.title,
            content: currentStoryData.content,
            createdAt: currentStoryData.createdAt ? (currentStoryData.createdAt.toDate ? currentStoryData.createdAt.toDate().toISOString() : new Date().toISOString()) : new Date().toISOString()
          }
        ];

        const partTitleInput = title.trim() || `Part ${currentParts.length + 1}`;
        const newPart = {
          title: partTitleInput,
          content: content.trim(),
          createdAt: new Date().toISOString()
        };

        await updateDoc(storyRef, {
          parts: [...currentParts, newPart],
          updatedAt: serverTimestamp()
        });

        navigate(`/story/${selectedStoryId}`);
      }
    } catch (err: any) {
      if (err.message) {
        setError(err.message);
      } else {
        setError("Failed to process transaction. Mind credentials/connection.");
        handleFirestoreError(err, 'create', formMode === 'new' ? 'stories' : 'stories/parts', currentUser);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    saveToFirestore(false);
  };

  const handleSaveDraft = (e: React.MouseEvent) => {
    e.preventDefault();
    saveToFirestore(true);
  };

  const handleAiSuggest = async () => {
    setAiLoading(true);
    setError('');
    const inputTitle = title.trim() || "Mysterious twist";
    const suggestion = await suggestStoryContent(inputTitle, category);
    if (suggestion) {
      setAiSuggestions(suggestion);
      setShowAiPanel(true);
    } else {
      setError('AI is polishing brains. Try again shortly.');
    }
    setAiLoading(false);
  };

  const applyAiSuggestion = () => {
    if (aiSuggestions) {
      setTitle(aiSuggestions.title);
      setContent(aiSuggestions.content);
      setAiSuggestions(null);
      setShowAiPanel(false);
    }
  };

  const handleAiRefine = async () => {
    if (!content.trim()) {
      setError('Type some storytelling block to allow AI magic!');
      return;
    }
    setAiLoading(true);
    setError('');
    const refined = await refineStoryContent(content);
    if (refined) {
      setContent(refined);
    } else {
      setError('AI Refine timed out. Give it another try.');
    }
    setAiLoading(false);
  };

  const autoFormatContent = () => {
    if (!content.trim()) return;
    let formatted = content.trim();
    formatted = formatted.charAt(0).toUpperCase() + formatted.slice(1);
    formatted = formatted.replace(/  +/g, ' ');
    setContent(formatted);
  };

  const wordCount = content.trim() === '' ? 0 : content.trim().split(/\s+/).length;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-black text-gray-900 dark:text-zinc-100 flex flex-col font-sans select-text pb-20">
      
      {/* Mobile-First Floating/Sticky Custom Header */}
      <div className="sticky top-0 z-30 bg-white dark:bg-zinc-950 border-b border-gray-100 dark:border-zinc-900 flex items-center justify-between px-4 py-3">
        <button 
          onClick={() => navigate(-1)} 
          className="flex items-center space-x-1 text-gray-800 dark:text-zinc-200 hover:text-indigo-600 transition"
        >
          <ChevronLeft className="w-6 h-6" />
          <span className="font-extrabold text-[17px] tracking-tight">Share Your Story</span>
        </button>
        <div className="flex items-center space-x-2">
          {formMode === 'new' && (
            <button
              onClick={handleSaveDraft}
              disabled={isLoading}
              className="px-4 py-1.5 rounded-full text-xs font-bold text-gray-600 hover:bg-gray-100 dark:text-zinc-300 dark:hover:bg-zinc-900 transition mr-1"
            >
              Draft
            </button>
          )}
          <button 
            onClick={handlePublish} 
            disabled={isLoading || (formMode === 'part' && !selectedStoryId)}
            className="px-5 py-1.5 bg-[#ff501a] hover:bg-[#e04513] text-white text-[13px] font-black uppercase tracking-wider rounded-full transition active:scale-95 disabled:opacity-50 cursor-pointer shadow-lg shadow-orange-500/10"
          >
            {isLoading ? 'Publishing...' : 'Publish'}
          </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto w-full px-4 sm:px-6 py-6 space-y-6">
        
        {error && (
          <div className="bg-red-50 dark:bg-red-950/20 text-red-600 dark:text-red-400 p-4 rounded-xl text-xs font-bold border border-red-200/50 dark:border-red-900/30">
            {error}
          </div>
        )}

        {/* Story Form Mode Dropdown */}
        <div className="space-y-1.5">
          <select
            value={formMode}
            onChange={(e) => setFormMode(e.target.value as 'new' | 'part')}
            className="w-full px-4 py-3 rounded-xl border border-gray-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 text-gray-800 dark:text-white font-extrabold text-[15px] focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none cursor-pointer transition shadow-sm"
          >
            <option value="new">Create New Story</option>
            <option value="part">Add Part to Existing Story</option>
          </select>
        </div>

        {/* Existing Story Selector (Only for 'part' mode) */}
        {formMode === 'part' && (
          <div className="space-y-2">
            <label className="block text-xs font-extrabold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest leading-none">Select Story</label>
            {loadingStories ? (
              <div className="flex items-center space-x-2 py-2">
                <Loader2 className="w-4 h-4 text-orange-500 animate-spin" />
                <span className="text-sm text-gray-400">Loading your stories...</span>
              </div>
            ) : userStories.length === 0 ? (
              <p className="text-xs text-red-500">You don't have any existing stories yet. Please create a new story first.</p>
            ) : (
              <select
                value={selectedStoryId}
                onChange={(e) => handleSelectStory(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 text-gray-800 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer transition shadow-sm"
              >
                <option value="">-- Choose one of your stories --</option>
                {userStories.map(s => (
                  <option key={s.id} value={s.id}>{s.title}</option>
                ))}
              </select>
            )}
          </div>
        )}

        {/* Tap to add cover photo (Only for 'new' mode) */}
        {formMode === 'new' && (
          <div className="space-y-2">
            {imagePreview ? (
              <div className="relative rounded-2xl overflow-hidden border border-gray-100 dark:border-zinc-900 aspect-video bg-zinc-100 dark:bg-zinc-950 shadow-inner group">
                <img src={imagePreview} alt="Cover Preview" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={removeImage}
                  className="absolute top-3 right-3 p-2 bg-black/60 hover:bg-black/85 text-white rounded-full transition shadow"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-zinc-200 dark:border-zinc-900 rounded-2xl p-10 flex flex-col items-center justify-center cursor-pointer bg-white dark:bg-zinc-950 hover:bg-zinc-50 dark:hover:bg-zinc-900/30 transition duration-200 shadow-sm"
              >
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleImageChange}
                  accept="image/*"
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-full bg-zinc-50 dark:bg-zinc-900 flex items-center justify-center mb-3 border border-gray-100 dark:border-zinc-800/50">
                  <ImageIcon className="w-5 h-5 text-zinc-400" />
                </div>
                <p className="text-[14px] font-black text-zinc-700 dark:text-zinc-300">Tap to add cover photo</p>
                <p className="text-[11px] text-zinc-400 mt-1 uppercase tracking-wider font-extrabold">PNG, JPG, WEBP formats</p>
              </div>
            )}
          </div>
        )}

        {/* Story/Part Title */}
        <div className="space-y-1">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            disabled={isLoading}
            className="w-full px-4 py-3.5 rounded-xl border border-gray-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 text-gray-900 dark:text-white placeholder-zinc-400 focus:ring-2 focus:ring-indigo-500 outline-none transition shadow-sm font-bold"
            placeholder={formMode === 'new' ? "Write your story title..." : "Write your part title (e.g. Part 2: The Truth)..."}
          />
        </div>

        {/* Category Select (Only for 'new' stories) */}
        {formMode === 'new' && (
          <div className="space-y-2">
            <label className="block text-xs font-extrabold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest leading-none">Select Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 text-gray-800 dark:text-white capitalize focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer transition shadow-sm"
            >
              {CATEGORIES.map(cat => (
                <option key={cat} value={cat} className="capitalize">
                  {cat}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Hashtags input */}
        <div className="space-y-2">
          <label className="block text-xs font-extrabold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest leading-none">#Hashtags</label>
          <input
            type="text"
            value={hashtags}
            onChange={(e) => setHashtags(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-gray-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 text-gray-900 dark:text-white placeholder-zinc-400 focus:ring-2 focus:ring-indigo-500 outline-none transition shadow-sm font-semibold"
            placeholder="#Hashtags (e.g., #horror #thriller #story)"
          />
        </div>



        {/* Short description / summary */}
        <div className="space-y-2">
          <label className="block text-xs font-extrabold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest leading-none">Short Description / Summary</label>
          <textarea
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            rows={3}
            className="w-full px-4 py-3 rounded-xl border border-gray-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 text-gray-900 dark:text-white placeholder-zinc-400 focus:ring-2 focus:ring-indigo-500 outline-none transition resize-none text-[13px] leading-relaxed shadow-sm"
            placeholder="Write a short description/summary..."
          />
        </div>

        {/* AI Story Assistant Suggestion Result inline Card */}
        {showAiPanel && aiSuggestions && (
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50/50 dark:from-zinc-900/60 dark:to-zinc-950 rounded-2xl p-5 border border-indigo-100/50 dark:border-zinc-800 shadow-sm space-y-3 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-indigo-700 dark:text-indigo-400 font-extrabold text-sm">
                <Sparkles className="w-5 h-5 animate-pulse" />
                <span>AI Brainwave Suggestion</span>
              </div>
              <button 
                onClick={() => {
                  setAiSuggestions(null);
                  setShowAiPanel(false);
                }} 
                className="p-1 hover:bg-indigo-100 dark:hover:bg-zinc-800 rounded-full text-zinc-400 hover:text-zinc-600 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <h4 className="font-extrabold text-gray-950 dark:text-white text-base">Recommended Title: {aiSuggestions.title}</h4>
            <div className="bg-white/75 dark:bg-black/50 rounded-xl p-4 border border-indigo-50 dark:border-zinc-800 shadow-inner">
              <p className="text-xs text-gray-700 dark:text-zinc-300 italic leading-relaxed">"{aiSuggestions.content}"</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Outline Beats</p>
              <ul className="text-xs text-gray-600 dark:text-zinc-400 space-y-1 list-disc list-inside">
                {aiSuggestions.outline?.map((beat: string, i: number) => (
                  <li key={i}>{beat}</li>
                ))}
              </ul>
            </div>
            <div className="flex space-x-2 pt-2">
              <button 
                onClick={applyAiSuggestion} 
                className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Use this Inspiration
              </button>
              <button 
                onClick={() => {
                  setAiSuggestions(null);
                  setShowAiPanel(false);
                }} 
                className="px-4 py-2 bg-zinc-200 hover:bg-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Maybe later
              </button>
            </div>
          </div>
        )}

        {/* The Story Editor Content area */}
        <div className="space-y-2 flex flex-col flex-1">
          <label className="block text-xs font-extrabold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest leading-none">The Story Content</label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onBlur={autoFormatContent}
            disabled={isLoading}
            rows={15}
            className="w-full flex-1 px-4 py-4 rounded-2xl border border-gray-130 dark:border-zinc-900 bg-white dark:bg-zinc-950 text-gray-900 ::placeholder-zinc-400 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition font-serif text-[17px] leading-relaxed resize-y shadow-sm"
            placeholder="Start writing your amazing story here..."
          />
        </div>

      </div>

      {/* Styled Footer Sticky Action toolbar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/95 dark:bg-zinc-950/95 border-t border-gray-100 dark:border-zinc-900 backdrop-blur z-20 shadow-lg">
        <div className="max-w-2xl mx-auto flex items-center justify-between h-14 px-6">
          <div className="flex items-center space-x-4">
            
            {/* Pick Cover Image */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-gray-50 dark:hover:bg-zinc-900 rounded-full transition cursor-pointer"
              title="Upload Cover Background"
            >
              <ImageIcon className="w-5 h-5" />
            </button>

            {/* AI suggest brainwaves */}
            <button
              type="button"
              onClick={handleAiSuggest}
              disabled={aiLoading}
              className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-gray-50 dark:hover:bg-zinc-900 rounded-full transition cursor-pointer"
              title="Request AI story brainwaves"
            >
              {aiLoading ? (
                <Loader2 className="w-5 h-5 text-orange-500 animate-spin" />
              ) : (
                <Sparkles className="w-5 h-5" />
              )}
            </button>

            {/* Magic Refine text selection */}
            {content.length > 5 && (
              <button
                type="button"
                onClick={handleAiRefine}
                disabled={aiLoading}
                className="px-3.5 py-1 text-[11px] font-black uppercase tracking-wider bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-zinc-900 dark:text-indigo-400 rounded-md transition"
                title="AI Magic Refine content"
              >
                Refine
              </button>
            )}

            {/* Capitalization quick-form handler */}
            {content.length > 0 && (
              <button
                type="button"
                onClick={autoFormatContent}
                className="px-2.5 py-1 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 text-zinc-500 dark:text-zinc-300 font-extrabold text-[11px] rounded"
                title="Format capitalization and spacing"
              >
                A-Z
              </button>
            )}

          </div>

          <div className="text-zinc-400 dark:text-zinc-500 text-xs font-bold font-mono">
            {wordCount} words
          </div>
        </div>
      </div>

    </div>
  );
}
