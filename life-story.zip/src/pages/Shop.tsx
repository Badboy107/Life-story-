import React, { useState, useEffect } from 'react';
import { 
  Code, ShoppingBag, Search, Tag, Globe, Coins, Download, 
  ExternalLink, Plus, Filter, ArrowLeft, ArrowUpRight, 
  Check, AlertCircle, Loader2, Sparkles, BookOpen, Trash2, X
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { db } from '../lib/firebase';
import { 
  collection, doc, getDoc, getDocs, setDoc, updateDoc, 
  onSnapshot, query, where, orderBy, addDoc, serverTimestamp, deleteDoc 
} from 'firebase/firestore';
import { useAuth } from '../contexts/AuthContext';
import { Helmet } from 'react-helmet-async';

interface CodeProduct {
  id: string;
  title: string;
  description: string;
  category: 'games' | 'mobile' | 'web' | 'scripts' | 'ui';
  techStack: string[];
  price: number;
  demoUrl?: string;
  downloadUrl: string;
  createdAt: any;
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  purchaseCount: number;
  likesCount: number;
}

const PRESET_STACKS = ['React', 'Unity', 'Flutter', 'Swift', 'Kotlin', 'Tailwind CSS', 'Node.js', 'Firebase', 'TypeScript', 'Python'];

const CATEGORY_LABELS = {
  all: 'All Products',
  games: 'Games',
  mobile: 'Mobile Apps',
  web: 'Web Templates',
  scripts: 'Scripts & Tools',
  ui: 'UI Kits & Components'
};

export default function Shop() {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'browse' | 'purchased' | 'sell'>('browse');
  const [products, setProducts] = useState<CodeProduct[]>([]);
  const [purchasedIds, setPurchasedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [userCoins, setUserCoins] = useState<number>(250); // Fallback default
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  // Sell Form States
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<'games' | 'mobile' | 'web' | 'scripts' | 'ui'>('games');
  const [techStack, setTechStack] = useState<string[]>([]);
  const [selectedTechInput, setSelectedTechInput] = useState('');
  const [price, setPrice] = useState<number>(50);
  const [demoUrl, setDemoUrl] = useState('');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Buy Modal Confirmation
  const [selectedProduct, setSelectedProduct] = useState<CodeProduct | null>(null);
  const [buying, setBuying] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Fetch or subscribe to User coins
  useEffect(() => {
    if (!currentUser) return;
    const userRef = doc(db, 'users', currentUser.uid);
    const unsubscribe = onSnapshot(userRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.coins !== undefined) {
          setUserCoins(data.coins);
        } else {
          // Initialize user coins in first visit if missing
          updateDoc(userRef, { coins: 500 }).catch(err => console.error("Error setting coins:", err));
          setUserCoins(500);
        }
      }
    }, (err) => {
      console.warn("Could not fetch user coins count, using offline fallback", err);
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Handle Loading listings & Purchased indices
  useEffect(() => {
    setLoading(true);
    // Subscribe to code listings
    const q = query(collection(db, 'shop_listings'), orderBy('createdAt', 'desc'));
    const unsubscribeListings = onSnapshot(q, (snapshot) => {
      const listData: CodeProduct[] = [];
      snapshot.forEach((doc) => {
        listData.push({ id: doc.id, ...doc.data() } as CodeProduct);
      });
      setProducts(listData);
      setLoading(false);
    }, (error) => {
      console.error("Listing snapshot sync error:", error);
      setLoading(false);
    });

    // Subscribe to purchased list
    if (currentUser) {
      const pQ = query(collection(db, `users/${currentUser.uid}/purchased_code`));
      const unsubscribePurchased = onSnapshot(pQ, (snapshot) => {
        const pIds: string[] = [];
        snapshot.forEach((doc) => {
          pIds.push(doc.id);
        });
        setPurchasedIds(pIds);
      }, (error) => {
        console.warn("Purchased code tracking offline:", error);
      });
      return () => {
        unsubscribeListings();
        unsubscribePurchased();
      };
    }

    return () => unsubscribeListings();
  }, [currentUser]);

  // Quick Seed template assets if the shop is completely empty so it looks fabulous immediately!
  const handleSeedPlaceholders = async () => {
    if (!currentUser) return;
    try {
      setLoading(true);
      const items = [
        {
          title: "Multiplayer Flappy Clash Creator",
          description: "Stunning realtime HTML5/Phaser multi-player Flappy Bird clone with custom server backend, persistent global user leaderboards, and responsive layout.",
          category: "games",
          techStack: ["React", "TypeScript", "Node.js", "Tailwind CSS"],
          price: 150,
          demoUrl: "https://example.com/demo/flappyclash",
          downloadUrl: "https://github.com/example/flappy-multiclash",
          purchaseCount: 12,
          likesCount: 22,
          authorId: "system",
          authorName: "Elite Publisher",
          createdAt: new Date()
        },
        {
          title: "Crypto Wallet Native Flutter UI",
          description: "Stunning animated production-ready dark theme UI workspace designed for crypto wallets. Contains historical graph components, coin lists, send/receive models, beautiful custom assets, and haptic feedback configurations.",
          category: "ui",
          techStack: ["Flutter", "Dart", "Tailwind CSS"],
          price: 75,
          demoUrl: "https://example.com/demo/cryptowallet",
          downloadUrl: "https://github.com/example/flutter-crypto-wallet",
          purchaseCount: 43,
          likesCount: 45,
          authorId: "system",
          authorName: "Flutter Artisan",
          createdAt: new Date()
        },
        {
          title: "Fullstack E-Commerce CMS Template",
          description: "Clean boilerplate containing full auth, product dashboards, integrated stripe webhook handlers, multi-category inventory models, and instant checkout pathways.",
          category: "web",
          techStack: ["React", "Node.js", "Firebase", "TypeScript"],
          price: 200,
          demoUrl: "https://example.com/demo/ecommerce-cms",
          downloadUrl: "https://github.com/example/shopify-express-cms",
          purchaseCount: 8,
          likesCount: 15,
          authorId: "system",
          authorName: "Stack Wizard",
          createdAt: new Date()
        }
      ];

      for (const item of items) {
        await addDoc(collection(db, 'shop_listings'), {
          ...item,
          createdAt: serverTimestamp()
        });
      }
      setToast({ message: "Successfully loaded template listings!", type: 'success' });
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const addTechTag = (tag: string) => {
    if (tag && !techStack.includes(tag)) {
      setTechStack([...techStack, tag]);
    }
    setSelectedTechInput('');
  };

  const removeTechTag = (tag: string) => {
    setTechStack(techStack.filter(t => t !== tag));
  };

  // Create Listing Form Submission
  const handlePublishListing = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setFormError('');
    setFormSuccess(false);

    if (!title.trim()) return setFormError('Title is required.');
    if (!description.trim() || description.length < 20) return setFormError('Please write a detailed description (at least 20 chars).');
    if (!downloadUrl.trim()) return setFormError('Source code folder link or repository URL is required for customers to download.');
    if (price <= 0) return setFormError('Price must be greater than zero.');

    setSubmitting(true);
    try {
      await addDoc(collection(db, 'shop_listings'), {
        title: title.trim(),
        description: description.trim(),
        category,
        techStack,
        price: Number(price),
        demoUrl: demoUrl.trim() || null,
        downloadUrl: downloadUrl.trim(),
        purchaseCount: 0,
        likesCount: 0,
        authorId: currentUser.uid,
        authorName: currentUser.displayName || 'Developer',
        authorPhoto: currentUser.photoURL || '',
        createdAt: serverTimestamp()
      });

      // Show Success
      setFormSuccess(true);
      setTitle('');
      setDescription('');
      setDemoUrl('');
      setDownloadUrl('');
      setTechStack([]);
      setToast({ message: "Source code listing live on store!", type: 'success' });
      
      // Auto toggle to browse
      setTimeout(() => {
        setActiveTab('browse');
        setFormSuccess(false);
      }, 1500);

    } catch (error: any) {
      setFormError(error.message || 'Failed to list developer code.');
    } finally {
      setSubmitting(false);
    }
  };

  // Buying / unlocking flow
  const handleBuyProduct = async () => {
    if (!currentUser || !selectedProduct) return;
    setBuying(true);

    try {
      const userRef = doc(db, 'users', currentUser.uid);
      const userSnap = await getDoc(userRef);
      const buyerCoins = userSnap.exists() ? (userSnap.data().coins ?? 500) : 500;

      if (buyerCoins < selectedProduct.price) {
        setToast({ message: "Insufficient balance! Please complete payout workflows or write stories to earn coins.", type: 'error' });
        setSelectedProduct(null);
        setBuying(false);
        return;
      }

      // 1. Deduct coins from buyer
      await updateDoc(userRef, {
        coins: buyerCoins - selectedProduct.price
      });

      // 2. Add coins to seller (if not system)
      if (selectedProduct.authorId && selectedProduct.authorId !== 'system') {
        const sellerRef = doc(db, 'users', selectedProduct.authorId);
        const sellerSnap = await getDoc(sellerRef);
        if (sellerSnap.exists()) {
          const sellerCoins = sellerSnap.data().coins ?? 0;
          await updateDoc(sellerRef, {
            coins: sellerCoins + selectedProduct.price
          });
        }
      }

      // 3. Mark as purchased in user subcollection
      const purchaseRef = doc(db, `users/${currentUser.uid}/purchased_code`, selectedProduct.id);
      await setDoc(purchaseRef, {
        productId: selectedProduct.id,
        title: selectedProduct.title,
        downloadUrl: selectedProduct.downloadUrl,
        purchasedAt: serverTimestamp(),
        pricePaid: selectedProduct.price
      });

      // 4. Increment buy counter on listing product
      const productRef = doc(db, 'shop_listings', selectedProduct.id);
      await updateDoc(productRef, {
        purchaseCount: (selectedProduct.purchaseCount || 0) + 1
      });

      setToast({ message: `Successfully purchased "${selectedProduct.title}"! Zip key unlocked.`, type: 'success' });
      setSelectedProduct(null);
    } catch (error: any) {
      console.error(error);
      setToast({ message: "Purchase failed: " + error.message, type: 'error' });
    } finally {
      setBuying(false);
    }
  };

  // Add virtual test balance of 500 coins to play with!
  const addTestBalance = async () => {
    if (!currentUser) return;
    try {
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, {
        coins: userCoins + 500
      });
      setToast({ message: "+500 Test Coins credited directly to wallet!", type: 'success' });
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    }
  };

  const handleDeleteListing = async (productId: string) => {
    if (!confirm("Are you sure you want to delete your source code listing?")) return;
    try {
      await deleteDoc(doc(db, 'shop_listings', productId));
      setToast({ message: "Listing deleted successfully", type: 'success' });
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    }
  };

  // Filter listings
  const filteredProducts = products.filter(p => {
    const matchesSearch = p.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.techStack.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const purchasedProducts = products.filter(p => purchasedIds.includes(p.id));

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-black text-gray-900 dark:text-zinc-100 flex flex-col font-sans select-text pb-24">
      <Helmet>
        <title>Code Marketplace & App Shop | Life Story</title>
      </Helmet>

      {/* Floating alert notifications */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 flex items-center space-x-3 px-5 py-3.5 rounded-2xl border shadow-xl animate-bounce ${
          toast.type === 'success' 
            ? 'bg-emerald-50 border-emerald-100 text-emerald-800 dark:bg-zinc-950 dark:border-emerald-900/30 dark:text-emerald-400' 
            : 'bg-rose-50 border-rose-100 text-rose-800 dark:bg-zinc-950 dark:border-rose-900/30 dark:text-rose-400'
        }`}>
          {toast.type === 'success' ? <Check className="w-5 h-5 text-emerald-600" /> : <AlertCircle className="w-5 h-5 text-rose-600" />}
          <span className="text-xs font-extrabold tracking-wide">{toast.message}</span>
        </div>
      )}

      {/* Top Interactive Banner */}
      <div className="bg-indigo-600 text-white relative overflow-hidden py-10 px-6 sm:px-12 border-b border-indigo-700">
        <div className="absolute right-0 top-0 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse" />
        <div className="absolute left-1/3 bottom-0 w-80 h-80 bg-blue-400 rounded-full mix-blend-multiply filter blur-2xl opacity-20 animate-pulse" />
        
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center space-x-2 bg-indigo-500/20 w-fit px-3 py-1 rounded-full border border-indigo-400/30">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" />
              <span className="text-[10px] tracking-widest font-black uppercase text-amber-200">Developer Emporium</span>
            </div>
            <h1 className="text-3xl font-black tracking-tight leading-none">Code & Game Shop</h1>
            <p className="text-sm text-indigo-100 max-w-lg leading-relaxed font-medium">
              Sell your games, mobile applications, scripts, & developer code snippets, or purchase components from professional coders directly using virtual coins!
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 flex flex-col justify-between shrink-0 hover:bg-white/15 transition-all text-left">
            <div className="flex items-center space-x-2 text-indigo-100 text-xs font-extrabold uppercase tracking-wider">
              <Coins className="w-4 h-4 text-amber-300" />
              <span>Wallet balance</span>
            </div>
            <div className="text-2xl font-black text-amber-300 tracking-tight mt-1">{userCoins} $COINS</div>
            <p className="text-[10px] text-white/60 font-semibold mt-1">1 Coin matches $1 value equivalent</p>
            
            <button 
              onClick={addTestBalance}
              className="mt-3.5 px-3 py-1.5 bg-amber-400 hover:bg-amber-500 text-gray-950 font-black rounded-lg text-xs tracking-wider transition uppercase shadow-md flex items-center justify-center space-x-1"
            >
              <Coins className="w-3.5 h-3.5" />
              <span>Get Free Coins</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto w-full px-4 mt-8 space-y-6">
        {/* Navigation tabs */}
        <div className="flex space-x-1.5 p-1 bg-gray-200/50 dark:bg-zinc-900/60 rounded-2xl w-fit border border-gray-100 dark:border-zinc-900/40 font-bold text-xs">
          <button
            onClick={() => setActiveTab('browse')}
            className={`px-4 py-2.5 rounded-xl transition ${
              activeTab === 'browse' 
                ? 'bg-white dark:bg-zinc-950 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                : 'text-gray-500 hover:text-gray-900 dark:hover:text-zinc-200'
            }`}
          >
            Browse Products
          </button>
          <button
            onClick={() => setActiveTab('purchased')}
            className={`px-4 py-2.5 rounded-xl transition relative ${
              activeTab === 'purchased' 
                ? 'bg-white dark:bg-zinc-950 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                : 'text-gray-500 hover:text-gray-900 dark:hover:text-zinc-200'
            }`}
          >
            My Purchases
            {purchasedIds.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-indigo-600 text-white font-black text-[9px] w-4.5 h-4.5 flex items-center justify-center rounded-full">
                {purchasedIds.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('sell')}
            className={`px-4 py-2.5 rounded-xl transition ${
              activeTab === 'sell' 
                ? 'bg-white dark:bg-zinc-950 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                : 'text-gray-500 hover:text-gray-900 dark:hover:text-zinc-200'
            }`}
          >
            Sell Your Code
          </button>
        </div>

        {/* Tab 1: Browse Assets */}
        {activeTab === 'browse' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-3">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-gray-400" />
                <input 
                  type="text" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search code bases, languages, plugins..."
                  className="w-full pl-10 pr-4 py-3 bg-white dark:bg-zinc-950 border border-gray-200/80 dark:border-zinc-900/60 rounded-2xl text-xs font-bold outline-none ring-2 ring-transparent focus:ring-indigo-500 transition leading-none text-gray-900 dark:text-white"
                />
              </div>

              {/* Category Select Filters */}
              <div className="flex items-center space-x-1.5 overflow-x-auto pb-2 scrollbar-none shrink-0 text-xs">
                {Object.entries(CATEGORY_LABELS).map(([catKey, label]) => (
                  <button
                    key={catKey}
                    onClick={() => setSelectedCategory(catKey)}
                    className={`px-3.5 py-2 rounded-xl border whitespace-nowrap transition cursor-pointer font-bold ${
                      selectedCategory === catKey 
                        ? 'bg-zinc-900 text-white border-zinc-900 dark:bg-white dark:text-black dark:border-white' 
                        : 'bg-white text-gray-600 border-gray-150 hover:bg-gray-50 dark:bg-zinc-950 dark:text-zinc-400 dark:border-zinc-900/60'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {loading ? (
              <div className="flex flex-col items-center justify-center py-24 bg-white dark:bg-zinc-950 rounded-3xl border border-gray-100 dark:border-zinc-900">
                <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mb-4" />
                <p className="text-gray-500 font-bold text-xs tracking-wider uppercase">Loading asset market catalogs...</p>
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-16 bg-white dark:bg-zinc-950 rounded-3xl border border-gray-100 dark:border-zinc-900">
                <Code className="w-12 h-12 text-zinc-300 dark:text-zinc-800 mx-auto mb-4 animate-pulse" />
                <h4 className="text-base font-extrabold text-gray-800 dark:text-zinc-200">No source codes listed</h4>
                <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">Be the pioneer! List your games, native app build directories, or styling packs for sale.</p>
                {products.length === 0 && (
                  <button
                    onClick={handleSeedPlaceholders}
                    className="mt-4 px-4 py-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-zinc-900 text-indigo-600 dark:text-indigo-400 text-xs font-black rounded-xl border border-indigo-100/55 dark:border-zinc-800 capitalize transition"
                  >
                    ⚡ Seed Premium Placeholders
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredProducts.map((p) => {
                  const isPurchased = purchasedIds.includes(p.id);
                  const isAuthor = currentUser?.uid === p.authorId;
                  
                  return (
                    <div 
                      key={p.id}
                      className="bg-white dark:bg-zinc-950 border border-gray-100 dark:border-zinc-900/80 rounded-3xl p-5 hover:shadow-lg dark:hover:shadow-none hover:border-indigo-100 dark:hover:border-zinc-800 transition duration-300 flex flex-col justify-between relative group"
                    >
                      {/* Top Badging & Delete Button */}
                      <div className="flex items-start justify-between">
                        <span className="px-2.5 py-1 rounded-full text-[10px] uppercase font-black tracking-wider bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400 select-none">
                          {CATEGORY_LABELS[p.category]}
                        </span>
                        
                        {(isAuthor || ['msojib724@gmail.com', 'Starbad366@gmail.com'].includes(currentUser?.email || '')) && (
                          <button 
                            onClick={() => handleDeleteListing(p.id)}
                            className="p-1.5 text-zinc-300 hover:text-red-500 transition rounded-lg hover:bg-red-50/10"
                            title="Delete Listing"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>

                      {/* Title & Description */}
                      <div className="mt-4.5 space-y-2 flex-1">
                        <h3 className="text-lg font-black text-gray-950 dark:text-white leading-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                          {p.title}
                        </h3>
                        <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed font-medium line-clamp-3">
                          {p.description}
                        </p>
                      </div>

                      {/* Tech stack badges */}
                      {p.techStack && p.techStack.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-4">
                          {p.techStack.map((tech, idx) => (
                            <span key={idx} className="px-2 py-0.5 rounded-md text-[9px] uppercase font-bold tracking-wider bg-gray-100 text-gray-500 dark:bg-zinc-900 dark:text-zinc-400 border border-transparent dark:border-zinc-800/45">
                              {tech}
                            </span>
                          ))}
                        </div>
                      )}

                      {/* Seller Information */}
                      <div className="border-t border-gray-100 dark:border-zinc-900/60 pt-4 mt-5 flex items-center justify-between">
                        <div className="flex items-center space-x-2.5 min-w-0">
                          {p.authorPhoto ? (
                            <img src={p.authorPhoto} alt="" className="w-6 h-6 rounded-full object-cover shrink-0" />
                          ) : (
                            <div className="w-6 h-6 bg-zinc-100 dark:bg-zinc-900 rounded-full flex items-center justify-center shrink-0">
                              <Code className="w-3.5 h-3.5 text-zinc-400" />
                            </div>
                          )}
                          <span className="text-[11px] font-bold text-gray-400 truncate tracking-tight">By {p.authorName}</span>
                        </div>

                        {/* Cost, buy, or download tools */}
                        <div className="flex items-center space-x-2 shrink-0">
                          {isPurchased ? (
                            <a 
                              href={p.downloadUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400 text-xs font-black rounded-xl flex items-center space-x-1.5 transition select-none tracking-wider"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>DOWNLOAD</span>
                            </a>
                          ) : isAuthor ? (
                            <span className="px-3 py-2 bg-zinc-50 border border-zinc-100 text-zinc-400 dark:bg-zinc-900 dark:border-zinc-800 text-[10px] font-black uppercase tracking-wider rounded-xl select-none">
                              YOUR LISTING
                            </span>
                          ) : (
                            <button
                              onClick={() => setSelectedProduct(p)}
                              className="px-4 py-2.5 bg-zinc-950 hover:bg-indigo-600 text-white dark:bg-zinc-900 dark:hover:bg-indigo-600 text-xs font-black rounded-xl flex items-center space-x-1.5 transition tracking-wider shadow-inner"
                            >
                              <Coins className="w-3.5 h-3.5 text-amber-300" />
                              <span>{p.price} COINS</span>
                            </button>
                          )}

                          {p.demoUrl && (
                            <a 
                              href={p.demoUrl} 
                              target="_blank" 
                              rel="noreferrer"
                              className="p-2 bg-gray-50 hover:bg-gray-100 dark:bg-zinc-900 dark:hover:bg-zinc-850 rounded-xl text-gray-500 dark:text-zinc-400 transition"
                              title="Live Demo Preview"
                            >
                              <ArrowUpRight className="w-4 h-4" />
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: My Purchased Code */}
        {activeTab === 'purchased' && (
          <div className="space-y-6">
            <h3 className="text-base font-extrabold text-gray-950 dark:text-white flex items-center space-x-2">
              <ShoppingBag className="w-5 h-5 text-indigo-500" />
              <span>Purchased & Unlocked Source Codes</span>
            </h3>

            {purchasedProducts.length === 0 ? (
              <div className="text-center py-16 bg-white dark:bg-zinc-950 rounded-3xl border border-gray-100 dark:border-zinc-900">
                <ShoppingBag className="w-12 h-12 text-zinc-300 dark:text-zinc-800 mx-auto mb-4 animate-bounce" />
                <h4 className="text-base font-extrabold text-gray-800 dark:text-zinc-200">No templates owned yet</h4>
                <p className="text-xs text-gray-500 dark:text-zinc-400 mt-1 max-w-sm mx-auto">Purchase premium code kits and indie scripts with coins to instantly unlock their git links.</p>
                <button
                  onClick={() => setActiveTab('browse')}
                  className="mt-5 px-4.5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl tracking-wider transition uppercase"
                >
                  Explore Store Catalogs
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {purchasedProducts.map(p => (
                  <div 
                    key={p.id}
                    className="bg-white dark:bg-zinc-950 p-5 rounded-2xl border border-gray-150/70 dark:border-zinc-900 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <h4 className="text-base font-extrabold text-gray-950 dark:text-white">{p.title}</h4>
                      <p className="text-xs text-gray-400">Listed by developer {p.authorName}</p>
                    </div>

                    <div className="flex items-center space-x-2.5">
                      {p.demoUrl && (
                        <a 
                          href={p.demoUrl} 
                          target="_blank"  
                          rel="noreferrer"
                          className="px-3.5 py-2.5 bg-gray-50 hover:bg-gray-100 dark:bg-zinc-900 dark:hover:bg-zinc-850 text-gray-600 dark:text-zinc-300 rounded-xl font-bold text-xs flex items-center space-x-1 transition"
                        >
                          <Globe className="w-3.5 h-3.5" />
                          <span>Live Demo</span>
                        </a>
                      )}

                      <a 
                        href={p.downloadUrl} 
                        target="_blank" 
                        rel="noreferrer"
                        className="px-4.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-black text-xs flex items-center space-x-1.5 transition uppercase tracking-wider"
                      >
                        <Download className="w-4 h-4" />
                        <span>Source Zip Link</span>
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Sell Your Code listing */}
        {activeTab === 'sell' && (
          <div className="bg-white dark:bg-zinc-950 border border-gray-100 dark:border-zinc-900 rounded-3xl p-6 md:p-8 shadow-sm">
            <h3 className="text-xl font-black text-gray-950 dark:text-white leading-none">List Source Code for Sale</h3>
            <p className="text-xs text-gray-400 mt-2">Publish your original web modules, custom mobile apps, or gaming assets, set your coin limit, and earn from downloads.</p>

            <form onSubmit={handlePublishListing} className="space-y-5 mt-6 border-t border-gray-100 dark:border-zinc-900/60 pt-6">
              {formError && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-100 dark:bg-rose-950/20 dark:border-rose-900/30 text-rose-700 dark:text-rose-400 text-xs font-bold leading-normal flex items-start space-x-2">
                  <AlertCircle className="w-4.5 h-4.5 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {formSuccess && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-100 dark:bg-emerald-950/20 dark:border-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-xs font-bold leading-normal flex items-start space-x-2">
                  <Check className="w-4.5 h-4.5 shrink-0" />
                  <span>Listing published successfully! Opening marketplace catalogs...</span>
                </div>
              )}

              {/* Title */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase tracking-wider text-gray-400">Product Title</label>
                <input 
                  type="text" 
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. 3D Endless Runner Game Unity Template"
                  maxLength={60}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-zinc-900/40 border border-gray-200/80 dark:border-zinc-900/50 rounded-xl font-bold text-xs text-gray-950 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase tracking-wider text-gray-400">Detailed Description & Features</label>
                <textarea 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe what the application does, its core mechanics, instructions, setup details, and key features included."
                  rows={5}
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-zinc-900/40 border border-gray-200/80 dark:border-zinc-900/50 rounded-xl text-xs font-medium text-gray-950 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none resize-none leading-relaxed"
                  required
                />
              </div>

              {/* Grid 1: Category & Pricing */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-wider text-gray-400">Category Selection</label>
                  <select 
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-zinc-900/40 border border-gray-200/80 dark:border-zinc-900/50 rounded-xl font-bold text-xs text-gray-950 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    <option value="games">Games</option>
                    <option value="mobile">Mobile Apps</option>
                    <option value="web">Web Templates</option>
                    <option value="scripts">Scripts & Tools</option>
                    <option value="ui">UI Kits & Components</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-black uppercase tracking-wider text-gray-400">Listing Price (In Coins)</label>
                  <div className="relative">
                    <Coins className="absolute left-3.5 top-3.5 w-4 h-4 text-amber-500" />
                    <input 
                      type="number" 
                      value={price}
                      onChange={(e) => setPrice(Math.max(1, Number(e.target.value)))}
                      min={1}
                      className="w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-zinc-900/40 border border-gray-200/80 dark:border-zinc-900/50 rounded-xl font-bold text-xs text-gray-950 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Technology Stack tags */}
              <div className="space-y-2">
                <label className="block text-xs font-black uppercase tracking-wider text-gray-400">Technology stack / Framework tags</label>
                
                {/* Chosen values */}
                {techStack.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pb-2">
                    {techStack.map((tech) => (
                      <span 
                        key={tech}
                        onClick={() => removeTechTag(tech)}
                        className="px-2.5 py-1 bg-indigo-50 hover:bg-rose-50 text-indigo-600 hover:text-rose-600 dark:bg-indigo-950/40 dark:text-indigo-400 dark:hover:bg-rose-950/20 dark:hover:text-rose-400 text-[10px] font-black tracking-wider uppercase rounded-lg border border-transparent hover:border-rose-200 cursor-pointer transition flex items-center space-x-1"
                      >
                        <span>{tech}</span>
                        <X className="w-3 h-3 shrink-0" />
                      </span>
                    ))}
                  </div>
                )}

                {/* Preset quick pills */}
                <div className="flex flex-wrap gap-1.5 pt-1.5">
                  {PRESET_STACKS.map((tag) => (
                    <button
                      type="button"
                      key={tag}
                      onClick={() => addTechTag(tag)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition ${
                        techStack.includes(tag)
                          ? 'bg-indigo-600 text-white border-indigo-600 dark:bg-white dark:text-black'
                          : 'bg-gray-50 hover:bg-gray-100 border-gray-200 text-gray-500 dark:bg-zinc-900 dark:border-zinc-800'
                      }`}
                    >
                      +{tag}
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Preview Demo Link */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase tracking-wider text-gray-400">Live Demo URL (Optional)</label>
                <input 
                  type="url" 
                  value={demoUrl}
                  onChange={(e) => setDemoUrl(e.target.value)}
                  placeholder="e.g. https://play.google.com/store/apps/details?id=sample"
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-zinc-900/40 border border-gray-200/80 dark:border-zinc-900/50 rounded-xl font-bold text-xs text-gray-955 focus:ring-2 focus:ring-indigo-500 outline-none text-gray-900 dark:text-white"
                />
              </div>

              {/* Source link */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black uppercase tracking-wider text-gray-400">Source Code ZIP Download / Github Private URL</label>
                <input 
                  type="text" 
                  value={downloadUrl}
                  onChange={(e) => setDownloadUrl(e.target.value)}
                  placeholder="e.g. https://drive.google.com/uc?export=download&id=..."
                  className="w-full px-4 py-3 bg-gray-50 dark:bg-zinc-900/40 border border-gray-200/80 dark:border-zinc-900/50 rounded-xl font-bold text-xs text-gray-955 focus:ring-2 focus:ring-indigo-500 outline-none text-gray-900 dark:text-white"
                  required
                />
                <p className="text-[10px] text-gray-400 font-semibold">Customers automatically unlock this folder hyperlink once their coins are deducted securely.</p>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-4.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-zinc-300 dark:disabled:bg-zinc-800 text-white font-black text-sm uppercase tracking-widest rounded-2xl transition shadow-lg shrink-0"
              >
                {submitting ? (
                  <div className="flex items-center justify-center space-x-2">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>PUBLISHING MARKET CATALOG...</span>
                  </div>
                ) : (
                  <span>PUBLISH SOURCE CODE LISTING</span>
                )}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Buy Confirmation dialog modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-950 rounded-3xl p-6 max-w-sm w-full border border-gray-150 dark:border-zinc-900 text-center space-y-6 shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="w-16 h-16 bg-amber-50 dark:bg-amber-950/20 rounded-full flex items-center justify-center mx-auto border border-amber-100 dark:border-amber-900/20">
              <Coins className="w-8 h-8 text-amber-500 animate-pulse" />
            </div>

            <div className="space-y-2">
              <h4 className="text-lg font-black text-gray-950 dark:text-white leading-tight">Unlock Source Code?</h4>
              <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed font-semibold">
                You are purchasing "<span className="text-indigo-600 dark:text-indigo-400">{selectedProduct.title}</span>" containing full developer source assets.
              </p>
            </div>

            {/* Price detail block */}
            <div className="bg-gray-50 dark:bg-zinc-900 rounded-2xl p-4 flex items-center justify-between border border-gray-100 dark:border-zinc-800/60 text-left">
              <div>
                <p className="text-[10px] uppercase font-black text-gray-450 tracking-wider">Product Price</p>
                <p className="text-base font-black text-gray-950 dark:text-white">{selectedProduct.price} Coins</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] uppercase font-black text-gray-450 tracking-wider">Total balance</p>
                <p className="text-base font-black text-amber-500">{userCoins} Coins</p>
              </div>
            </div>

            {/* Confirmation actions */}
            <div className="grid grid-cols-2 gap-3.5 pt-2">
              <button
                type="button"
                disabled={buying}
                onClick={() => setSelectedProduct(null)}
                className="py-3 bg-gray-50 hover:bg-gray-100 dark:bg-zinc-900 dark:hover:bg-zinc-850 text-gray-500 dark:text-zinc-300 font-extrabold text-xs tracking-wider uppercase rounded-xl transition"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={buying}
                onClick={handleBuyProduct}
                className="py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs tracking-wider uppercase rounded-xl transition flex items-center justify-center space-x-1"
              >
                {buying ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <Coins className="w-3.5 h-3.5" />
                    <span>CONFIRM & BUY</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
