import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Users, ShoppingBag, BookOpen, Coins, Trash2, 
  Sparkles, Check, AlertTriangle, Loader2, Search, ArrowUpRight, 
  Maximize2, Star, Edit3, X, RefreshCw, Key, DollarSign
} from 'lucide-react';
import { db } from '../lib/firebase';
import { 
  collection, doc, getDocs, getDoc, updateDoc, 
  deleteDoc, query, orderBy, limit, onSnapshot, where 
} from 'firebase/firestore';
import { useAuth } from '../contexts/AuthContext';
import { Helmet } from 'react-helmet-async';

interface AdminStats {
  totalUsers: number;
  totalStories: number;
  totalProducts: number;
  totalCoinsCirculating: number;
}

interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  coins?: number;
  followersCount?: number;
  followingCount?: number;
  pinnedBadge?: string;
}

interface CodeProduct {
  id: string;
  title: string;
  category: string;
  price: number;
  downloadUrl: string;
  authorName: string;
  authorId: string;
}

interface StoryItem {
  id: string;
  title: string;
  authorName: string;
  viewsCount?: number;
  likesCount?: number;
  commentsCount?: number;
  isSponsored?: boolean;
}

const ADMIN_EMAILS = ['msojib724@gmail.com', 'Starbad366@gmail.com'];

export default function AdminPanel() {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'stats' | 'users' | 'shop' | 'stories'>('stats');
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  
  // Data States
  const [stats, setStats] = useState<AdminStats>({ totalUsers: 0, totalStories: 0, totalProducts: 0, totalCoinsCirculating: 0 });
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [products, setProducts] = useState<CodeProduct[]>([]);
  const [stories, setStories] = useState<StoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [userSearch, setUserSearch] = useState('');
  const [productSearch, setProductSearch] = useState('');
  const [storySearch, setStorySearch] = useState('');

  // Editing coin modal states
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [newCoinsValue, setNewCoinsValue] = useState<number>(0);
  const [savingCoins, setSavingCoins] = useState(false);

  // Editing listing modal states
  const [editingProduct, setEditingProduct] = useState<CodeProduct | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editDownloadUrl, setEditDownloadUrl] = useState('');
  const [editTitle, setEditTitle] = useState('');
  const [savingProduct, setSavingProduct] = useState(false);

  // Toast Feedback State
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(null), 3500);
      return () => clearTimeout(t);
    }
  }, [toast]);

  // Auth Verification
  useEffect(() => {
    if (!currentUser) {
      setIsAdmin(false);
      return;
    }
    const isEmailAdmin = ADMIN_EMAILS.includes(currentUser.email || '');
    setIsAdmin(isEmailAdmin);
  }, [currentUser]);

  // Fetch metrics data
  useEffect(() => {
    if (isAdmin !== true) return;
    
    setLoading(true);
    
    // 1. Subscribe to Users
    const unsubscribeUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      const uList: UserProfile[] = [];
      let totalCoins = 0;
      snapshot.forEach((doc) => {
        const u = { uid: doc.id, ...doc.data() } as UserProfile;
        uList.push(u);
        totalCoins += u.coins || 0;
      });
      setUsers(uList);
      setStats(prev => ({ ...prev, totalUsers: uList.length, totalCoinsCirculating: totalCoins }));
    }, (error) => {
      console.error("Users sync fail", error);
    });

    // 2. Subscribe to Products
    const unsubscribeProducts = onSnapshot(collection(db, 'shop_listings'), (snapshot) => {
      const pList: CodeProduct[] = [];
      snapshot.forEach((doc) => {
        pList.push({ id: doc.id, ...doc.data() } as CodeProduct);
      });
      setProducts(pList);
      setStats(prev => ({ ...prev, totalProducts: pList.length }));
    }, (error) => {
      console.error("Products sync fail", error);
    });

    // 3. Subscribe to Stories
    const unsubscribeStories = onSnapshot(collection(db, 'stories'), (snapshot) => {
      const sList: StoryItem[] = [];
      snapshot.forEach((doc) => {
        sList.push({ id: doc.id, ...doc.data() } as StoryItem);
      });
      setStories(sList);
      setStats(prev => ({ ...prev, totalStories: sList.length }));
      setLoading(false);
    }, (error) => {
      console.error("Stories sync fail", error);
      setLoading(false);
    });

    return () => {
      unsubscribeUsers();
      unsubscribeProducts();
      unsubscribeStories();
    };
  }, [isAdmin]);

  // 1. Action: Save custom coin limits
  const handleUpdateCoins = async () => {
    if (!editingUser) return;
    setSavingCoins(true);
    try {
      await updateDoc(doc(db, 'users', editingUser.uid), {
        coins: Number(newCoinsValue)
      });
      setToast({ message: `Coins for ${editingUser.displayName} updated to ${newCoinsValue} Successfully!`, type: 'success' });
      setEditingUser(null);
    } catch (err: any) {
      setToast({ message: "Update failed: " + err.message, type: 'error' });
    } finally {
      setSavingCoins(false);
    }
  };

  // 2. Action: Delete User Document completely (danger zone)
  const handleDeleteUser = async (uid: string, name: string) => {
    if (!confirm(`WARNING: Are you absolutely sure you want to permanently delete the user account for "${name}" from your cloud database?`)) return;
    try {
      await deleteDoc(doc(db, 'users', uid));
      setToast({ message: `Purged account ${name} successfully!`, type: 'success' });
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    }
  };

  // 3. Action: Save custom edits of product listings
  const handleUpdateProduct = async () => {
    if (!editingProduct) return;
    setSavingProduct(true);
    try {
      await updateDoc(doc(db, 'shop_listings', editingProduct.id), {
        title: editTitle.trim(),
        price: Number(editPrice),
        downloadUrl: editDownloadUrl.trim()
      });
      setToast({ message: `Updated product "${editTitle}" successfully!`, type: 'success' });
      setEditingProduct(null);
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    } finally {
      setSavingProduct(false);
    }
  };

  // 4. Action: Toggle Sponsoring of story feed posts
  const handleToggleSponsor = async (story: StoryItem) => {
    try {
      const nextStatus = !story.isSponsored;
      await updateDoc(doc(db, 'stories', story.id), {
        isSponsored: nextStatus
      });
      setToast({ 
        message: nextStatus ? `Sponsorship promoted for "${story.title}"!` : `Sponsorship removed for "${story.title}"`, 
        type: 'success' 
      });
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    }
  };

  // 5. Action: Delete Story post immediately (moderation tools)
  const handleDeleteStory = async (storyId: string, name: string) => {
    if (!confirm(`Are you sure you want to delete post "${name}" from feed as an admin?`)) return;
    try {
      await deleteDoc(doc(db, 'stories', storyId));
      setToast({ message: "Story deleted from database.", type: 'success' });
    } catch (err: any) {
      setToast({ message: err.message, type: 'error' });
    }
  };

  // Filter lists based on searchable keywords
  const filteredUsers = users.filter(u => 
    u.displayName.toLowerCase().includes(userSearch.toLowerCase()) || 
    u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.uid.toLowerCase().includes(userSearch.toLowerCase())
  );

  const filteredProducts = products.filter(p => 
    p.title.toLowerCase().includes(productSearch.toLowerCase()) || 
    p.authorName.toLowerCase().includes(productSearch.toLowerCase())
  );

  const filteredStories = stories.filter(s => 
    s.title.toLowerCase().includes(storySearch.toLowerCase()) || 
    s.authorName.toLowerCase().includes(storySearch.toLowerCase())
  );

  // Loading admin check state
  if (isAdmin === null) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center font-sans">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mb-4" />
        <p className="text-gray-500 font-medium">Authorizing system clearances...</p>
      </div>
    );
  }

  // Deny access if not admin
  if (isAdmin === false) {
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center space-y-6 font-sans">
        <div className="w-16 h-16 bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 rounded-full flex items-center justify-center mx-auto border border-rose-100 dark:border-rose-900/30">
          <AlertTriangle className="w-8 h-8 animate-pulse" />
        </div>
        <div className="space-y-2">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Admin Clearance Required</h2>
          <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed max-w-sm">
            Access to this diagnostic portal is restricted to key publishers. Your logged email current account does not have authorization roles.
          </p>
        </div>
        <div className="pt-2">
          <p className="text-[10px] text-gray-400 font-mono tracking-wider">SECURE SYSTEM CREDENTIAL ERROR</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-black text-gray-900 dark:text-zinc-100 font-sans select-text pb-24">
      <Helmet>
        <title>Central App & Shop Admin Portal</title>
      </Helmet>

      {/* Toast feedback alerts */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 flex items-center space-x-3 px-5 py-3.5 rounded-2xl border shadow-xl animate-bounce ${
          toast.type === 'success' 
            ? 'bg-emerald-50 border-emerald-100 text-emerald-800 dark:bg-zinc-950 dark:border-emerald-900/40 dark:text-emerald-400' 
            : 'bg-rose-50 border-rose-100 text-rose-800 dark:bg-zinc-950 dark:border-rose-900/40 dark:text-rose-400'
        }`}>
          {toast.type === 'success' ? <Check className="w-5 h-5 text-emerald-600" /> : <AlertTriangle className="w-5 h-5 text-rose-600" />}
          <span className="text-xs font-black tracking-wide">{toast.message}</span>
        </div>
      )}

      {/* Top Banner and System Status */}
      <div className="bg-zinc-900 text-white relative overflow-hidden py-10 px-6 sm:px-12 border-b border-zinc-800">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center space-x-2 bg-indigo-500/20 w-fit px-3 py-1 rounded-full border border-indigo-400/30">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
              <span className="text-[10px] tracking-widest font-black uppercase text-indigo-300">Authorized Operator Panel</span>
            </div>
            <h1 className="text-3xl font-black tracking-tight leading-none text-white">Central Admin Panel</h1>
            <p className="text-xs text-zinc-400 max-w-lg leading-relaxed font-medium">
              Diagnostic module for platform owners. Search registered app users, distribute virtual currency, monitor shop assets, source links, and moderate active feeds.
            </p>
          </div>

          <div className="flex items-center space-x-2 bg-zinc-950 border border-zinc-800/80 rounded-2xl px-4 py-3 shrink-0">
            <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping shrink-0" />
            <div className="text-left font-mono">
              <div className="text-[10px] uppercase font-black text-zinc-500 select-none">Active Admin Role</div>
              <div className="text-xs font-bold text-zinc-350">{currentUser?.email}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto w-full px-4 mt-8 space-y-6">
        {/* Navigation tabs */}
        <div className="flex space-x-1.5 p-1 bg-gray-200/50 dark:bg-zinc-900/60 rounded-2xl w-fit border border-gray-100 dark:border-zinc-900/40 font-bold text-xs">
          <button
            onClick={() => setActiveTab('stats')}
            className={`px-4 py-2.5 rounded-xl transition cursor-pointer ${
              activeTab === 'stats' 
                ? 'bg-white dark:bg-zinc-950 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                : 'text-gray-500 hover:text-gray-900 dark:hover:text-zinc-200'
            }`}
          >
            Core Stat Metrics
          </button>
          
          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2.5 rounded-xl transition cursor-pointer ${
              activeTab === 'users' 
                ? 'bg-white dark:bg-zinc-950 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                : 'text-gray-500 hover:text-gray-900 dark:hover:text-zinc-200'
            }`}
          >
            Manage Users & Coins
          </button>

          <button
            onClick={() => setActiveTab('shop')}
            className={`px-4 py-2.5 rounded-xl transition cursor-pointer ${
              activeTab === 'shop' 
                ? 'bg-white dark:bg-zinc-950 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                : 'text-gray-500 hover:text-gray-900 dark:hover:text-zinc-200'
            }`}
          >
            Moderate Shop Listings
          </button>

          <button
            onClick={() => setActiveTab('stories')}
            className={`px-4 py-2.5 rounded-xl transition cursor-pointer ${
              activeTab === 'stories' 
                ? 'bg-white dark:bg-zinc-950 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                : 'text-gray-500 hover:text-gray-900 dark:hover:text-zinc-200'
            }`}
          >
            Story Moderation
          </button>
        </div>

        {/* Tab 1: Stats & Overview */}
        {activeTab === 'stats' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white dark:bg-zinc-950 border border-gray-150/70 dark:border-zinc-900 p-5 rounded-2xl shadow-sm text-left">
                <Users className="w-5 h-5 text-indigo-500 mb-2.5" />
                <div className="text-3xl font-black text-gray-900 dark:text-white leading-none">{stats.totalUsers}</div>
                <div className="text-[10px] uppercase font-bold text-gray-400 tracking-wider mt-1.5">Registered Users</div>
              </div>

              <div className="bg-white dark:bg-zinc-950 border border-gray-150/70 dark:border-zinc-900 p-5 rounded-2xl shadow-sm text-left">
                <BookOpen className="w-5 h-5 text-emerald-500 mb-2.5" />
                <div className="text-3xl font-black text-gray-900 dark:text-white leading-none">{stats.totalStories}</div>
                <div className="text-[10px] uppercase font-bold text-gray-400 tracking-wider mt-1.5">User Stories</div>
              </div>

              <div className="bg-white dark:bg-zinc-950 border border-gray-150/70 dark:border-zinc-900 p-5 rounded-2xl shadow-sm text-left">
                <ShoppingBag className="w-5 h-5 text-violet-500 mb-2.5" />
                <div className="text-3xl font-black text-gray-900 dark:text-white leading-none">{stats.totalProducts}</div>
                <div className="text-[10px] uppercase font-bold text-gray-400 tracking-wider mt-1.5">Listed Shop Items</div>
              </div>

              <div className="bg-white dark:bg-zinc-950 border border-gray-150/70 dark:border-zinc-900 p-5 rounded-2xl shadow-sm text-left">
                <Coins className="w-5 h-5 text-amber-500 mb-2.5" />
                <div className="text-3xl font-black text-gray-900 dark:text-white leading-none">{stats.totalCoinsCirculating}</div>
                <div className="text-[10px] uppercase font-bold text-gray-400 tracking-wider mt-1.5">Circulating Coins</div>
              </div>
            </div>

            {/* Quick action tools */}
            <div className="bg-white dark:bg-zinc-950 border border-gray-100 dark:border-zinc-900 rounded-3xl p-6 space-y-4">
              <h3 className="text-base font-extrabold text-gray-950 dark:text-white">Admin Clearance Credentials</h3>
              <p className="text-xs text-gray-500 dark:text-zinc-400 leading-relaxed font-semibold">
                This diagnostic module matches the requested credentials for owners:
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
                <div className="p-4 rounded-2xl bg-indigo-50/20 dark:bg-indigo-950/25 border border-indigo-100/30 dark:border-indigo-900/30 flex items-center space-x-3 text-left">
                  <Key className="w-5 h-5 text-indigo-500 shrink-0" />
                  <div>
                    <div className="text-[10px] uppercase font-black tracking-wider text-gray-400">Owner Access 1</div>
                    <div className="text-xs font-bold text-indigo-600 dark:text-indigo-400">msojib724@gmail.com</div>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-indigo-50/20 dark:bg-indigo-950/25 border border-indigo-100/30 dark:border-indigo-900/30 flex items-center space-x-3 text-left">
                  <Key className="w-5 h-5 text-indigo-500 shrink-0" />
                  <div>
                    <div className="text-[10px] uppercase font-black tracking-wider text-gray-400">Owner Access 2</div>
                    <div className="text-xs font-bold text-indigo-600 dark:text-indigo-400">Starbad366@gmail.com</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Manage Users & distribute Coins */}
        {activeTab === 'users' && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="Search registered user name, email address, or document uid..."
                className="w-full pl-10 pr-4 py-3 bg-white dark:bg-zinc-950 border border-gray-200/80 dark:border-zinc-900/60 rounded-2xl text-xs font-bold outline-none text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 transition"
              />
            </div>

            {loading ? (
              <div className="flex flex-col items-center justify-center py-20 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-150">
                <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="text-center py-12 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-150 dark:border-zinc-900">
                <p className="text-xs text-gray-500">No matching users found.</p>
              </div>
            ) : (
              <div className="bg-white dark:bg-zinc-950 rounded-3xl border border-gray-150/70 dark:border-zinc-900 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-medium border-collapse">
                    <thead>
                      <tr className="bg-gray-50 dark:bg-zinc-900/60 text-[10px] uppercase font-black text-gray-400 tracking-wider">
                        <th className="p-4">Display User</th>
                        <th className="p-4">Security Email</th>
                        <th className="p-4 text-center">Coins Cache</th>
                        <th className="p-4 text-right">Actions Panel</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-zinc-900">
                      {filteredUsers.map((u) => (
                        <tr key={u.uid} className="hover:bg-gray-50/50 dark:hover:bg-zinc-900/25">
                          <td className="p-4">
                            <div className="font-bold text-gray-950 dark:text-white">{u.displayName || 'Wordsmith'}</div>
                            <div className="text-[10px] text-gray-400 font-mono select-all mt-0.5">{u.uid}</div>
                          </td>
                          <td className="p-4 select-all text-gray-600 dark:text-zinc-400">{u.email}</td>
                          <td className="p-4 text-center font-black text-amber-500">{u.coins ?? 500} Coins</td>
                          <td className="p-4 text-right space-x-1 whitespace-nowrap">
                            <button
                              onClick={() => {
                                setEditingUser(u);
                                setNewCoinsValue(u.coins ?? 500);
                              }}
                              className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-100/70 dark:bg-amber-950/20 dark:text-amber-400 dark:border-transparent rounded-lg font-bold text-[11px] uppercase tracking-wider transition"
                            >
                              Edit Coins
                            </button>
                            
                            {u.email !== currentUser?.email && (
                              <button
                                onClick={() => handleDeleteUser(u.uid, u.displayName)}
                                className="p-1.5 text-zinc-300 hover:text-rose-600 transition rounded-lg hover:bg-rose-50/10"
                                title="Delete account doc"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Moderate Shop Listings */}
        {activeTab === 'shop' && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                placeholder="Search shop title, technology framework tag, or publisher..."
                className="w-full pl-10 pr-4 py-3 bg-white dark:bg-zinc-950 border border-gray-200/80 dark:border-zinc-900/60 rounded-2xl text-xs font-bold outline-none text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 transition"
              />
            </div>

            {loading ? (
              <div className="flex flex-col items-center justify-center py-20 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-150">
                <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-12 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-150 dark:border-zinc-900">
                <p className="text-xs text-gray-500">No matching shop assets available.</p>
              </div>
            ) : (
              <div className="bg-white dark:bg-zinc-950 rounded-3xl border border-gray-150/70 dark:border-zinc-900 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-medium border-collapse">
                    <thead>
                      <tr className="bg-gray-50 dark:bg-zinc-900/60 text-[10px] uppercase font-black text-gray-400 tracking-wider">
                        <th className="p-4">App/Game Title</th>
                        <th className="p-4">Pricing</th>
                        <th className="p-4">Publisher Role</th>
                        <th className="p-4 text-right">Moderations</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-zinc-900">
                      {filteredProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-gray-50/50 dark:hover:bg-zinc-900/25">
                          <td className="p-4">
                            <div className="font-extrabold text-gray-950 dark:text-white">{p.title}</div>
                            <div className="text-[10px] text-gray-400 font-medium select-all mt-1 flex items-center space-x-1">
                              <span className="uppercase font-bold tracking-widest bg-gray-100 dark:bg-zinc-900 px-1.5 py-0.5 rounded text-[8px]">{p.category}</span>
                              <span className="truncate max-w-[200px] hover:text-indigo-600 cursor-pointer" title="Download Link URL" onClick={() => window.open(p.downloadUrl, '_blank')}>{p.downloadUrl}</span>
                            </div>
                          </td>
                          <td className="p-4 font-black text-amber-500">{p.price} $COINS</td>
                          <td className="p-4 text-gray-500 dark:text-zinc-400 font-medium">{p.authorName}</td>
                          <td className="p-4 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              onClick={() => {
                                setEditingProduct(p);
                                setEditTitle(p.title);
                                setEditPrice(p.price);
                                setEditDownloadUrl(p.downloadUrl);
                              }}
                              className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-gray-700 dark:text-zinc-300 rounded-lg font-bold text-[11px] uppercase tracking-wider transition"
                            >
                              Edit Entry
                            </button>
                            <button
                              onClick={() => handleDeleteStory(p.id, p.title)} // Using same generic confirm
                              className="p-1.5 text-zinc-300 hover:text-rose-600 transition rounded-lg hover:bg-rose-50/10"
                              title="Delete Listing"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Story Moderation */}
        {activeTab === 'stories' && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                value={storySearch}
                onChange={(e) => setStorySearch(e.target.value)}
                placeholder="Search active story title or author name..."
                className="w-full pl-10 pr-4 py-3 bg-white dark:bg-zinc-950 border border-gray-200/80 dark:border-zinc-900/60 rounded-2xl text-xs font-bold outline-none text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 transition"
              />
            </div>

            {loading ? (
              <div className="flex flex-col items-center justify-center py-20 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-150">
                <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
              </div>
            ) : filteredStories.length === 0 ? (
              <div className="text-center py-12 bg-white dark:bg-zinc-950 rounded-2xl border border-gray-150 dark:border-zinc-900">
                <p className="text-xs text-gray-500">No active stories matching keys.</p>
              </div>
            ) : (
              <div className="bg-white dark:bg-zinc-950 rounded-3xl border border-gray-150/70 dark:border-zinc-900 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-medium border-collapse">
                    <thead>
                      <tr className="bg-gray-50 dark:bg-zinc-900/60 text-[10px] uppercase font-black text-gray-400 tracking-wider">
                        <th className="p-4">Story Content Title</th>
                        <th className="p-4">Author Profile</th>
                        <th className="p-4 text-center">Engagement metrics</th>
                        <th className="p-4 text-right">Moderations</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-zinc-900">
                      {filteredStories.map((story) => (
                        <tr key={story.id} className="hover:bg-gray-50/50 dark:hover:bg-zinc-900/25">
                          <td className="p-4">
                            <div className="font-extrabold text-gray-950 dark:text-white flex items-center space-x-1.5">
                              <span>{story.title}</span>
                              {story.isSponsored && (
                                <span className="bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-widest">Sponsored</span>
                              )}
                            </div>
                            <div className="text-[10px] text-gray-400 select-all font-mono mt-1">{story.id}</div>
                          </td>
                          <td className="p-4 font-bold text-gray-600 dark:text-zinc-400">{story.authorName}</td>
                          <td className="p-4 text-center text-[11px] font-bold text-gray-600 dark:text-zinc-400">
                            {story.viewsCount || 0} Views • {story.likesCount || 0} Likes
                          </td>
                          <td className="p-4 text-right space-x-1 whitespace-nowrap">
                            <button
                              onClick={() => handleToggleSponsor(story)}
                              className={`px-3 py-1.5 rounded-lg font-bold text-[11px] uppercase tracking-wider transition ${
                                story.isSponsored 
                                  ? 'bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-900 dark:hover:bg-zinc-800 text-gray-600 dark:text-zinc-300' 
                                  : 'bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/20 dark:hover:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400'
                              }`}
                            >
                              {story.isSponsored ? 'Demote Ad' : 'Sponsor Ad'}
                            </button>
                            <button
                              onClick={() => handleDeleteStory(story.id, story.title)}
                              className="p-1.5 text-zinc-300 hover:text-rose-600 transition rounded-lg hover:bg-rose-50/10"
                              title="Delete from Feed"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modal: Edit Coins Dialogue */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-950 rounded-3xl p-6 max-w-sm w-full border border-gray-150 dark:border-zinc-900 shadow-2xl animate-in fade-in zoom-in duration-200 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-black text-gray-950 dark:text-white">Modify User Coin Wallet</h4>
              <button onClick={() => setEditingUser(null)} className="p-1 hover:bg-gray-50 dark:hover:bg-zinc-900 rounded-lg">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <div className="space-y-1.5 text-left text-xs">
              <p className="font-bold text-gray-500 dark:text-zinc-400">User: {editingUser.displayName}</p>
              <p className="font-mono text-gray-400">{editingUser.email}</p>
            </div>

            <div className="space-y-1 text-left">
              <label className="text-[10px] uppercase font-black text-gray-400 tracking-wider">Adjustment Total</label>
              <div className="relative">
                <Coins className="absolute left-3 top-3 w-4.5 h-4.5 text-amber-500" />
                <input 
                  type="number"
                  value={newCoinsValue}
                  onChange={(e) => setNewCoinsValue(Math.max(0, Number(e.target.value)))}
                  className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs font-black text-gray-900 dark:text-white outline-none"
                />
              </div>
            </div>

            <button
              onClick={handleUpdateCoins}
              disabled={savingCoins}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-zinc-400 text-white font-black text-xs tracking-wider uppercase rounded-xl transition"
            >
              {savingCoins ? 'Securing Distribution...' : 'Distribute Coins'}
            </button>
          </div>
        </div>
      )}

      {/* Modal: Edit Shop Listing Entry */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-zinc-950 rounded-3xl p-6 max-w-md w-full border border-gray-150 dark:border-zinc-900 shadow-2xl animate-in fade-in zoom-in duration-200 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-black text-gray-950 dark:text-white">Edit Shop Asset Listing</h4>
              <button onClick={() => setEditingProduct(null)} className="p-1 hover:bg-gray-50 dark:hover:bg-zinc-900 rounded-lg">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <div className="space-y-3.5 text-left text-xs">
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-black text-gray-400 tracking-wider">Product Display Name</label>
                <input 
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs font-bold text-gray-900 dark:text-white outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-black text-gray-400 tracking-wider">Coin Price Tags</label>
                <input 
                  type="number"
                  value={editPrice}
                  onChange={(e) => setEditPrice(Math.max(1, Number(e.target.value)))}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs font-black text-gray-900 dark:text-white outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-black text-gray-400 tracking-wider">Source code location or URL</label>
                <input 
                  type="text"
                  value={editDownloadUrl}
                  onChange={(e) => setEditDownloadUrl(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl text-xs font-bold text-gray-900 dark:text-white outline-none"
                />
              </div>
            </div>

            <button
              onClick={handleUpdateProduct}
              disabled={savingProduct}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-zinc-400 text-white font-black text-xs tracking-wider uppercase rounded-xl transition"
            >
              {savingProduct ? 'Saving properties...' : 'Save Product properties'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
