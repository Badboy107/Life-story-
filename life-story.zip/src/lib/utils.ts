import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Error handling helper for Firestore
export function handleFirestoreError(error: any, operationType: string, path: string | null = null, currentUser: any = null) {
  if (error instanceof Error && error.message.includes('Missing or insufficient permissions')) {
    const errorInfo = {
      error: error.message,
      operationType,
      path,
      authInfo: currentUser ? {
        userId: currentUser.uid,
        email: currentUser.email,
        emailVerified: currentUser.emailVerified,
        isAnonymous: currentUser.isAnonymous,
        providerInfo: currentUser.providerData
      } : null
    };
    console.error("Firestore Permission Error:", JSON.stringify(errorInfo, null, 2));
    
    // Dispatch custom event to notify UI components
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('firestore-permission-error', { detail: errorInfo }));
    }
    
    throw new Error(JSON.stringify(errorInfo));
  }
  throw error;
}

export function calculateReadingTime(content: string): number {
  const wordsPerMinute = 200;
  const words = content.trim().split(/\s+/).length;
  const time = Math.ceil(words / wordsPerMinute);
  return time;
}

export function getImgbbApiKey(): string {
  return (import.meta as any).env.VITE_IMGBB_API_KEY || "0fca5f43891bb73da28d7a1179cff273";
}

export async function compressImageToBase64(file: File, maxW = 800, maxH = 800, quality = 0.6): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;

        if (width > maxW || height > maxH) {
          if (width > height) {
            height = Math.round((height * maxW) / width);
            width = maxW;
          } else {
            width = Math.round((width * maxH) / height);
            height = maxH;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(event.target?.result as string); // fallback to original base64
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL("image/jpeg", quality);
        resolve(dataUrl);
      };
      img.onerror = (err) => {
        resolve(event.target?.result as string); // fallback to original base64
      };
    };
    reader.onerror = (err) => reject(err);
  });
}

export async function uploadImage(file: File): Promise<string> {
  const apiKey = getImgbbApiKey();
  const isDefaultKeyPlaceholder = apiKey === "your_imgbb_api_key_here";
  
  if (apiKey && !isDefaultKeyPlaceholder) {
    try {
      const formData = new FormData();
      formData.append('image', file);
      
      const response = await fetch(`https://api.imgbb.com/1/upload?key=${apiKey}`, {
        method: 'POST',
        body: formData,
      });
      
      const data = await response.json();
      if (data.success && data.data?.url) {
        return data.data.url;
      } else {
        console.warn("ImgBB upload failed, response context:", data);
      }
    } catch (err) {
      console.error("ImgBB upload error:", err);
    }
  }

  // Fallback directly to super-compressed client-side Base64
  console.log("Using compressed client-side Base64 fallback for image upload...");
  return await compressImageToBase64(file);
}

