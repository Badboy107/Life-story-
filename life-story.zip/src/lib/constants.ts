export const STORY_CATEGORIES = [
  'general',
  'memoir',
  'inspiration',
  'travel',
  'lessons',
  'relationships',
  'lifestyle',
  'fiction',
  'romantic',
  'thriller',
  'educational',
  'motivational',
  'science-fiction',
  'fantasy',
  'mystery',
  'comedy',
  'adventure',
  'history',
  'biography'
];

export const MONETIZATION_RATES = {
  PER_LIKE: 0.05,
  PER_COMMENT: 0.10,
  PER_VIEW_AD: 0.01,
  LIKES_REQUIREMENT: 100,
  STORIES_REQUIREMENT: 5
};

export const PAYOUT_METHODS = [
  { id: 'paypal', name: 'PayPal', icon: 'DollarSign' },
  { id: 'bank', name: 'Bank Transfer', icon: 'Building2' },
  { id: 'crypto', name: 'Crypto (USDT)', icon: 'Bitcoin' }
];
