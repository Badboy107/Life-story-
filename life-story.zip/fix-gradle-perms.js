import fs from 'fs';
import path from 'path';

const gradlewPath = path.resolve('android', 'gradlew');
if (fs.existsSync(gradlewPath)) {
  fs.chmodSync(gradlewPath, 0o755);
  console.log('Fixed permissions for gradlew');
} else {
  console.error('gradlew not found at', gradlewPath);
}
