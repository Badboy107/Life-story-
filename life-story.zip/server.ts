import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

const app = express();
const PORT = 3000;

// Access the GEMINI_API_KEY environment variable. 
const apiKey = process.env.GEMINI_API_KEY;

// Warn if API key is missing
if (!apiKey) {
  console.warn("WARNING: GEMINI_API_KEY environment variable is not set. Recommendation features will fail gracefully.");
}

// Lazy initialization of the SDK client mapping
let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient) {
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY model deployment variable is missing.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Body parser
app.use(express.json({ limit: '2mb' }));

// Server API Routes first
app.post("/api/suggested-stories", async (req, res) => {
  try {
    const { likedAndSaved, availableStories } = req.body;

    if (!likedAndSaved || !availableStories || !Array.isArray(availableStories)) {
      return res.status(400).json({ error: "Missing required likedAndSaved or availableStories arrays." });
    }

    if (availableStories.length === 0) {
      return res.json({ recommendedIds: [] });
    }

    // If there is no search context, just recommend top 5 available
    if (!likedAndSaved || likedAndSaved.length === 0) {
      return res.json({ 
        recommendedIds: availableStories.slice(0, 5).map(s => s.id),
        explanation: "Like or save stories to unlock personalized suggestions custom-tailored to your style." 
      });
    }

    const ai = getGeminiClient();

    const prompt = `You are an expert personalized content recommendation engine.
Analyze the user's previously liked/saved stories list to understand their interests, preferred themes, genres, and narrative categories:
${JSON.stringify(likedAndSaved)}

Based on these themes, select and prioritize up to 4 of the most relevant and appealing stories from the following available catalog of stories:
${JSON.stringify(availableStories)}

Rank your choices in descending order of recommendation strength (highest fit first). Also write a short, friendly explanation (max 12 words) explaining why these match them.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendedIds: {
              type: Type.ARRAY,
              items: {
                type: Type.STRING
              },
              description: "List of recommended story IDs matched based on interest compatibility."
            },
            explanation: {
              type: Type.STRING,
              description: "A super brief, friendly personalized description of what matches, under 12 words."
            }
          },
          required: ["recommendedIds", "explanation"]
        }
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      console.warn("Empty response from Gemini.");
      return res.json({ recommendedIds: [], explanation: "" });
    }

    try {
      const parsed = JSON.parse(textOutput.trim());
      if (parsed && Array.isArray(parsed.recommendedIds)) {
        return res.json({ 
          recommendedIds: parsed.recommendedIds, 
          explanation: parsed.explanation || "Recommended based on your reading history"
        });
      }
    } catch (e) {
      console.error("Failed to parse recommendation JSON output:", textOutput, e);
    }

    res.json({ recommendedIds: [], explanation: "" });
  } catch (err: any) {
    console.error("Gemini suggestion server error:", err);
    res.status(500).json({ error: err.message || "Failed to generate story recommendations." });
  }
});

// Setup Vite middleware / static build path
async function start() {
  if (process.env.NODE_ENV !== "production") {
    // Development server mapping with Vite
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production build static asset routing
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Life Story Server] Fullstack backend listening on http://localhost:${PORT}`);
  });
}

start().catch((err) => {
  console.error("Failed to bootstrap application:", err);
});
